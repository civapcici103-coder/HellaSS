#!/usr/bin/env bash
# Pulse Control — APK build script (no Gradle, only official Android build-tools)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

# Инструменты сборки (262 МБ) держим ВНЕ домашней папки, чтобы не засорять её.
# Восстановление: mv $ROOT/tools /tmp/pulse-tools
TOOLS=/tmp/pulse-tools
[ -x "$TOOLS/bt/android-14/aapt2" ] || TOOLS="$ROOT/tools"
BT="$TOOLS/bt/android-14"
AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"
ANDROID_JAR="$TOOLS/android.jar"
CORE_JAR="$ROOT/core/json-20240303.jar"

APK_DIR="$ROOT/apk"
BUILD="$ROOT/build"
KEYSTORE="$ROOT/keystore/pulse.jks"
KS_PASS="pulse2026"
KS_ALIAS="pulse"

rm -rf "$BUILD"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$BUILD/out"

echo "==> [1/7] aapt2 compile resources"
"$AAPT2" compile --dir "$APK_DIR/res" -o "$BUILD/out/res.zip"

echo "==> [2/7] aapt2 link (manifest + resources + R.java)"
"$AAPT2" link \
  -o "$BUILD/out/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$APK_DIR/AndroidManifest.xml" \
  --java "$BUILD/gen" \
  --min-sdk-version 26 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0 \
  --auto-add-overlay \
  -A "$APK_DIR/assets" \
  "$BUILD/out/res.zip"

echo "==> [3/7] javac"
find "$APK_DIR/src" "$BUILD/gen" -name '*.java' > "$BUILD/sources.txt"
javac -source 8 -target 8 -encoding UTF-8 -nowarn -Xlint:-options \
  -bootclasspath "$ANDROID_JAR:$BT/core-lambda-stubs.jar" -classpath "$CORE_JAR" -XDignore.symbol.file \
  -d "$BUILD/classes" @"$BUILD/sources.txt"

echo "==> [4/7] d8 (dex)"
find "$BUILD/classes" -name '*.class' > "$BUILD/classes.txt"
"$D8" --release --min-api 26 --lib "$ANDROID_JAR" \
  --output "$BUILD/dex" \
  --classpath "$CORE_JAR" \
  $(cat "$BUILD/classes.txt") "$CORE_JAR"

echo "==> [5/7] package unsigned APK"
cd "$BUILD/dex"
zip -q -X "$BUILD/out/base.apk" classes.dex
cd "$ROOT"
cp "$BUILD/out/base.apk" "$BUILD/out/unsigned.apk"

echo "==> [6/7] zipalign"
"$ZIPALIGN" -f 4 "$BUILD/out/unsigned.apk" "$BUILD/out/aligned.apk"

echo "==> [7/7] sign"
if [ ! -f "$KEYSTORE" ]; then
  mkdir -p "$ROOT/keystore"
  /usr/lib/jvm/jdk-11/bin/keytool -genkeypair -v -keystore "$KEYSTORE" -alias "$KS_ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=Pulse Control, OU=Pulse, O=Pulse, L=Home, C=NL" > /dev/null 2>&1
fi

"$APKSIGNER" sign --ks "$KEYSTORE" --ks-key-alias "$KS_ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --min-sdk-version 26 --v1-signing-enabled true --v2-signing-enabled true \
  --out "$ROOT/PulseControl.apk" "$BUILD/out/aligned.apk"

"$APKSIGNER" verify --print-certs -v "$ROOT/PulseControl.apk" | head -5
ls -lh "$ROOT/PulseControl.apk"
echo "✅ DONE: $ROOT/PulseControl.apk"
