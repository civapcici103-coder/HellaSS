package com.pulse.control;

import android.content.Context;

/**
 * Экономный режим — для тех случаев, когда другие приложения начинают лагать.
 *
 * Что отключается:
 *  - фоновый поллинг релея (остаётся только по требованию)
 *  - служба статуса (нотификация)
 *  - входящие уведомления (NotifyHook)
 *  - локальный HTTP-сервер
 *
 * Что остаётся: бот, жесты, скриншоты, все команды по запросу.
 */
public final class Eco {

    private static final String KEY = "eco_mode";

    private Eco() {}

    public static boolean on(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getBoolean(KEY, false);
    }

    public static void set(Context c, boolean on) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply();
        apply(c);
    }

    public static void apply(Context c) {
        boolean eco = on(c);
        try {
            if (eco) {
                // Релей намеренно НЕ останавливаем: одна SSE-связь почти не ест
                // батарею, зато без неё телефон недоступен — а это важнее экономии.
                StatusService.stop(c);
                WebServer.stop();
                LogStore.add("🌿 Экономный режим (релей остаётся на связи)");
            } else {
                if (Relay.enabled(c)) RelayService.start(c);
                WebServer.start(c);
                LogStore.add("⚡ Обычный режим");
            }
        } catch (Exception e) {
            LogStore.add("🌿 " + e.getMessage());
        }
    }

    public static String describe(Context c) {
        return on(c) ? "🌿 экономный" : "⚡ обычный";
    }

    /** Уровень нагрузки для отчёта. */
    public static String report(Context c) {
        StringBuilder sb = new StringBuilder("⚙️ <b>Нагрузка</b>\n\n");
        sb.append("Режим: <b>").append(describe(c)).append("</b>\n\n");
        sb.append((WebServer.isRunning() ? "✅" : "⛔")).append(" Локальный сервер\n");
        sb.append((Relay.isRunning() ? "✅" : "⛔")).append(" Релей в фоне\n");
        sb.append((BotService.isUp() ? "✅" : "⛔")).append(" Бот\n");
        sb.append((StatusService.isRunning() ? "✅" : "⛔")).append(" Служба статуса\n\n");
        if (!on(c)) sb.append("<i>Если лагают приложения — включи экономный режим: /eco</i>\n\n");
        return sb.append(Sys.footer(c)).toString();
    }
}
