package com.pulse.control;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

/** Delayed commands ("через 30 мин выключи звук"). */
public final class Sched {

    public interface Runner { void run(String cmd, String arg); }

    public static void add(Context c, int minutes, String cmd, String arg) {
        try {
            JSONArray arr = Config.schedule(c);
            long at = System.currentTimeMillis() + minutes * 60000L;
            JSONObject o = new JSONObject();
            o.put("at", at);
            o.put("cmd", cmd);
            o.put("arg", arg == null ? "" : arg);
            o.put("label", label(cmd, arg));
            arr.put(o);
            Config.scheduleSet(c, arr);
            LogStore.add("⏰ Запланировано через " + minutes + " мин: " + label(cmd, arg));
        } catch (Exception e) {
            LogStore.add("⏰ " + e.getMessage());
        }
    }

    public static String label(String cmd, String arg) {
        switch (cmd) {
            case "lock": return "блокировка";
            case "mute": return "звук выкл";
            case "unmute": return "звук вкл";
            case "home": return "домой";
            case "find": return "сирена";
            case "tts": return "озвучка: " + arg;
            default: return cmd + " " + arg;
        }
    }

    /** Returns the next due job's seconds, or -1 when nothing is due. */
    public static void tick(Context c, Runner runner) {
        try {
            JSONArray arr = Config.schedule(c);
            long now = System.currentTimeMillis();
            JSONArray keep = new JSONArray();
            boolean changed = false;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                if (o.optLong("at") <= now) {
                    changed = true;
                    String cmd = o.optString("cmd");
                    String arg = o.optString("arg");
                    LogStore.add("⏰ Выполняю: " + o.optString("label", cmd));
                    try { runner.run(cmd, arg); } catch (Exception ignored) {}
                } else {
                    keep.put(o);
                }
            }
            if (changed) Config.scheduleSet(c, keep);
        } catch (Exception ignored) {}
    }

    public static String dump(Context c) {
        StringBuilder sb = new StringBuilder();
        try {
            JSONArray arr = Config.schedule(c);
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                sb.append("• ").append(f.format(new java.util.Date(o.optLong("at"))))
                        .append(" — ").append(o.optString("label")).append('\n');
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }
}
