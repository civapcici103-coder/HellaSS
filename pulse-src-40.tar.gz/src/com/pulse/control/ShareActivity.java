package com.pulse.control;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Receives shared images/files: "Поделиться → Pulse" puts them on the wallpaper or sends to the bot. */
public class ShareActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Act.init(this);
        try {
            Intent it = getIntent();
            Uri uri = it == null ? null : (Uri) it.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null) { finish(); return; }
            byte[] data = read(uri);
            if (data == null) { Toast.makeText(this, "Не прочитал файл", Toast.LENGTH_SHORT).show(); finish(); return; }
            String type = getContentResolver().getType(uri);
            if (type != null && type.startsWith("image/")) {
                boolean ok = Tools.setWallpaper(this, data);
                Toast.makeText(this, ok ? "🖼 Обои установлены" : "Не удалось", Toast.LENGTH_SHORT).show();
            } else {
                Act.sendDoc(data, "shared.bin", "📤 Файл из «Поделиться»");
                Toast.makeText(this, "📤 Отправил в Telegram", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private byte[] read(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } catch (Exception e) { return null; }
    }
}
