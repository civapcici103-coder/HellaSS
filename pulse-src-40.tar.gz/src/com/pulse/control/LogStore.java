package com.pulse.control;

import android.os.Handler;
import android.os.Looper;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** In-memory log ring shown on the main screen. */
public final class LogStore {

    public interface Listener { void onLog(String line); }

    private static final int MAX = 250;
    private static final ArrayDeque<String> LINES = new ArrayDeque<>();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Listener listener;

    private LogStore() {}

    public static synchronized void add(String line) {
        String stamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        final String full = stamp + "  " + line;
        LINES.addLast(full);
        while (LINES.size() > MAX) LINES.removeFirst();
        final Listener l = listener;
        if (l != null) MAIN.post(() -> l.onLog(full));
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String s : LINES) sb.append(s).append('\n');
        return sb.toString();
    }

    public static void setListener(Listener l) { listener = l; }
}
