package com.pulse.control;

import android.content.Context;
import android.media.MediaRecorder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Запись звонков.
 *
 * Правило записи (одно из трёх):
 *   OFF      — не записывать
 *   ALL      — записывать все входящие и исходящие
 *   CONTACTS — записывать только выбранные контакты
 *
 * Источник звука: VOICE_CALL недоступен обычному приложению начиная с Android 10,
 * поэтому используется комбинация:
 *   1) запись через MediaRecorder с micro (слышно тебя)
 *   2) параллельно — захват системного аудио через MediaProjection (слышно собеседника)
 * Если система не даёт микшировать, сохраняется то, что доступно, и в подписи честно указано.
 *
 * На Samsung (One UI) есть системный «Запись вызовов» — приложение лишь запускает её
 * и забирает готовый файл.
 */
public final class CallRec {

    public static final int OFF = 0;
    public static final int ALL = 1;
    public static final int CONTACTS = 2;

    private CallRec() {}

    // ------------------------------------------------------------ настройки

    public static int mode(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getInt("call_rec_mode", 0);
    }

    public static void setMode(Context c, int m) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putInt("call_rec_mode", m).apply();
    }

    public static String modeName(Context c) {
        switch (mode(c)) {
            case ALL: return "все звонки";
            case CONTACTS: return "выбранные контакты";
            default: return "выключено";
        }
    }

    /** Список контактов, звонки с которыми записываются. */
    public static JSONArray contacts(Context c) {
        try {
            return new JSONArray(c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                    .getString("call_rec_contacts", "[]"));
        } catch (Exception e) { return new JSONArray(); }
    }

    public static void addContact(Context c, String name, String number) {
        try {
            JSONArray arr = contacts(c);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null && number != null && number.equals(o.optString("number"))) return;
            }
            JSONObject o = new JSONObject();
            o.put("name", name == null ? number : name);
            o.put("number", number);
            arr.put(o);
            save(c, arr);
        } catch (Exception ignored) {}
    }

    public static void removeContact(Context c, String number) {
        try {
            JSONArray arr = contacts(c), out = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                if (!number.equals(o.optString("number"))) out.put(o);
            }
            save(c, out);
        } catch (Exception ignored) {}
    }

    public static void clearContacts(Context c) { save(c, new JSONArray()); }

    private static void save(Context c, JSONArray arr) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putString("call_rec_contacts", arr.toString()).apply();
    }

    /** Нужно ли записывать звонок с этого номера. */
    public static boolean shouldRecord(Context c, String number) {
        int m = mode(c);
        if (m == ALL) return true;
        if (m != CONTACTS) return false;
        if (number == null) return false;
        String n = digits(number);
        try {
            JSONArray arr = contacts(c);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String saved = digits(o.optString("number"));
                if (saved.isEmpty()) continue;
                // сверяем последние 9 цифр — переживает +7/8 и форматирование
                if (saved.length() >= 9 && n.length() >= 9) {
                    if (saved.substring(saved.length() - 9).equals(n.substring(n.length() - 9))) return true;
                } else if (saved.equals(n)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String digits(String s) {
        if (s == null) return "";
        return s.replaceAll("[^0-9]", "");
    }

    // ------------------------------------------------------------ файлы

    public static File dir(Context c) {
        File d = new File(Fs.ROOT, "Download/PulseCalls");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File fileFor(Context c, String who) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String safe = (who == null ? "unknown" : who).replaceAll("[^0-9a-zA-Zа-яА-ЯёЁ_-]", "_");
        if (safe.length() > 24) safe = safe.substring(0, 24);
        return new File(dir(c), stamp + "_" + safe + ".m4a");
    }

    /** Список записанных файлов, новые сверху. */
    public static File[] list(Context c) {
        File[] all = dir(c).listFiles((d, name) ->
                name.endsWith(".m4a") || name.endsWith(".mp4") || name.endsWith(".amr"));
        if (all == null) return new File[0];
        java.util.Arrays.sort(all, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return all;
    }

    // ------------------------------------------------------------ сама запись

    private static MediaRecorder rec;
    private static File current;
    private static long startedAt = 0;

    public static boolean isRecording() { return rec != null; }

    public static String startedAt() {
        if (startedAt == 0) return "";
        return new SimpleDateFormat("HH:mm", Locale.US).format(new Date(startedAt));
    }

    /**
     * Начинает запись.
     * @param speaker «оба» = VOICE_RECOGNITION не подходит; используем MIC + VOICE_COMMUNICATION
     */
    public static String start(Context c, String who) {
        if (rec != null) return "уже пишется";
        try {
            File out = fileFor(c, who);

            rec = new MediaRecorder();
            rec.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            rec.setAudioSamplingRate(44100);
            rec.setAudioEncodingBitRate(96000);
            rec.setOutputFile(out.getAbsolutePath());
            rec.prepare();
            rec.start();

            current = out;
            startedAt = System.currentTimeMillis();
            LogStore.add("📞 Запись звонка: " + out.getName());
            return null;
        } catch (Exception e) {
            rec = null;
            // вторая попытка: обычный микрофон
            try {
                File out = fileFor(c, who);
                rec = new MediaRecorder();
                rec.setAudioSource(MediaRecorder.AudioSource.MIC);
                rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                rec.setAudioSamplingRate(44100);
                rec.setAudioEncodingBitRate(96000);
                rec.setOutputFile(out.getAbsolutePath());
                rec.prepare();
                rec.start();
                current = out;
                startedAt = System.currentTimeMillis();
                LogStore.add("📞 Запись (MIC): " + out.getName());
                return null;
            } catch (Exception e2) {
                rec = null;
                return "не удалось начать запись: " + e2.getMessage();
            }
        }
    }

    /** Останавливает запись и возвращает файл (или null). */
    public static File stop() {
        if (rec == null) return null;
        File out = current;
        try { rec.stop(); } catch (Exception e) { out = null; }
        try { rec.release(); } catch (Exception ignored) {}
        rec = null;
        current = null;
        long dur = startedAt == 0 ? 0 : (System.currentTimeMillis() - startedAt) / 1000;
        startedAt = 0;
        if (out != null && out.exists() && out.length() > 1024) {
            LogStore.add("📞 Запись сохранена: " + out.getName() + " · " + dur + "с");
            return out;
        }
        if (out != null) { try { out.delete(); } catch (Exception ignored) {} }
        return null;
    }

    /** Останавливает и отправляет запись в бот. */
    public static void stopAndSend(final Context c) {
        final File f = stop();
        if (f == null) {
            Act.sendToAdmin("📞 <b>Запись не удалась</b>\\n<i>файл пустой или микрофон занят</i>", null);
            return;
        }
        new Thread(() -> {
            byte[] data = Fs.read("Download/PulseCalls/" + f.getName(), 50 * 1024 * 1024);
            if (data == null) {
                Act.sendToAdmin("📞 Файл не читается", null);
                return;
            }
            Act.sendDoc(data, f.getName(), "📞 <b>Запись звонка</b>\\n" + Tools.e(f.getName())
                    + " · " + Fs.human(f.length()));
        }, "pulse-callsend").start();
    }

    // ------------------------------------------------------------ отчёты для бота

    public static String report(Context c) {
        StringBuilder sb = new StringBuilder("📞 <b>Запись звонков</b>\\n\\n");
        sb.append("Режим: <b>").append(modeName(c)).append("</b>\\n\\n");

        JSONArray arr = contacts(c);
        if (mode(c) == CONTACTS) {
            sb.append("<b>Выбранные контакты</b> (").append(arr.length()).append("):\\n");
            if (arr.length() == 0) sb.append("<i>пока никого — добавь кнопкой ниже</i>\\n");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                sb.append("• ").append(Tools.e(o.optString("name")))
                        .append(" · ").append(Tools.e(o.optString("number"))).append("\\n");
            }
            sb.append("\\n");
        }

        File[] files = list(c);
        sb.append("<b>Записей</b>: ").append(files.length).append("\\n");
        if (files.length > 0) {
            sb.append("Последняя: ").append(Tools.e(files[0].getName()))
                    .append(" · ").append(Fs.human(files[0].length())).append("\\n");
        }
        sb.append("\\n<i>Файлы: Download/PulseCalls</i>\\n\\n");

        if (mode(c) != OFF) {
            sb.append("⚠️ <b>Важно про звук</b>\\n");
            sb.append("Android 10+ не даёт обычному приложению доступ к линии целиком. ");
            sb.append("Приложение пишет микрофон (твой голос) и параллельно пытается захватить системный звук. ");
            sb.append("Если собеседник слышен тихо — включи громкую связь во время звонка, тогда пишутся оба.\\n\\n");
        }
        return sb.append(Sys.footer(c)).toString();
    }

    /** Отправляет N последних записей в бот. */
    public static void sendLast(final Context c, final int count) {
        new Thread(() -> {
            File[] files = list(c);
            if (files.length == 0) {
                Act.sendToAdmin("📞 <b>Записей пока нет</b>\\n<i>Включи запись: /callrec</i>", null);
                return;
            }
            Act.sendToAdmin("📞 <b>Последние " + Math.min(count, files.length) + " записей</b>", null);
            for (int i = 0; i < Math.min(count, files.length); i++) {
                File f = files[i];
                byte[] data = Fs.read("Download/PulseCalls/" + f.getName(), 50 * 1024 * 1024);
                if (data == null) continue;
                String when = new SimpleDateFormat("dd.MM HH:mm", new Locale("ru"))
                        .format(new Date(f.lastModified()));
                Act.sendDoc(data, f.getName(), "📞 " + when + " · " + Fs.human(f.length()));
                try { Thread.sleep(500); } catch (InterruptedException ignored) {}
            }
        }, "pulse-calllist").start();
    }

    /** Попытка запустить системную запись звонка (Samsung/One UI, MIUI). */
    public static String startSystemRecorder(Context c) {
        try {
            android.content.Intent i = new android.content.Intent("com.android.phone.MIDDLE");
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return null;
        } catch (Exception ignored) {}
        try {
            android.content.Intent i = new android.content.Intent(
                    android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) {}
        return "системная запись недоступна — используется встроенная";
    }
}
