package com.pulse.control;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Installed-app catalogue, name resolution (RU aliases + fuzzy) and launching. */
public final class Apps {

    public static final class Item {
        public final String label;
        public final String pkg;
        public Item(String label, String pkg) { this.label = label; this.pkg = pkg; }
    }

    /** Common RU/EN aliases → package. */
    private static final Map<String, String> ALIAS = new LinkedHashMap<>();
    static {
        ALIAS.put("ютуб", "com.google.android.youtube");
        ALIAS.put("ютьюб", "com.google.android.youtube");
        ALIAS.put("youtube", "com.google.android.youtube");
        ALIAS.put("телеграм", "org.telegram.messenger");
        ALIAS.put("телега", "org.telegram.messenger");
        ALIAS.put("telegram", "org.telegram.messenger");
        ALIAS.put("вотсап", "com.whatsapp");
        ALIAS.put("ватсап", "com.whatsapp");
        ALIAS.put("whatsapp", "com.whatsapp");
        ALIAS.put("инстаграм", "com.instagram.android");
        ALIAS.put("инста", "com.instagram.android");
        ALIAS.put("instagram", "com.instagram.android");
        ALIAS.put("тикток", "com.zhiliaoapp.musically");
        ALIAS.put("tik tok", "com.zhiliaoapp.musically");
        ALIAS.put("вк", "com.vkontakte.android");
        ALIAS.put("vk", "com.vkontakte.android");
        ALIAS.put("камера", "camera");
        ALIAS.put("camera", "camera");
        ALIAS.put("галерея", "gallery");
        ALIAS.put("chrome", "com.android.chrome");
        ALIAS.put("хром", "com.android.chrome");
        ALIAS.put("браузер", "browser");
        ALIAS.put("карты", "maps");
        ALIAS.put("maps", "com.google.android.apps.maps");
        ALIAS.put("gmail", "com.google.android.gm");
        ALIAS.put("почта", "com.google.android.gm");
        ALIAS.put("настройки", "settings");
        ALIAS.put("settings", "com.android.settings");
        ALIAS.put("калькулятор", "calculator");
        ALIAS.put("часы", "clock");
        ALIAS.put("spotify", "com.spotify.music");
        ALIAS.put("спотифай", "com.spotify.music");
    }

    private Apps() {}

    public static List<Item> list(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            PackageManager pm = c.getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
            for (ResolveInfo ri : ris) {
                if (ri.activityInfo == null) continue;
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName())) continue;
                CharSequence lab = ri.loadLabel(pm);
                out.add(new Item(lab == null ? pkg : lab.toString(), pkg));
            }
            Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        } catch (Exception ignored) {}
        return out;
    }

    public static String findPkg(Context c, String query) {
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return null;

        String alias = ALIAS.get(q);
        if (alias != null && !alias.contains(".")) {
            // generic alias like "camera" — resolve through PackageManager query
            String resolved = resolveGeneric(c, alias);
            if (resolved != null) return resolved;
        } else if (alias != null) {
            if (installed(c, alias)) return alias;
        }

        List<Item> all = list(c);
        // 1. exact label
        for (Item it : all) if (it.label.toLowerCase(Locale.ROOT).equals(q)) return it.pkg;
        // 2. label starts with query
        for (Item it : all) if (it.label.toLowerCase(Locale.ROOT).startsWith(q)) return it.pkg;
        // 3. contains
        for (Item it : all) if (it.label.toLowerCase(Locale.ROOT).contains(q)) return it.pkg;
        // 4. package name contains
        for (Item it : all) if (it.pkg.toLowerCase(Locale.ROOT).contains(q)) return it.pkg;
        // 5. simple fuzzy: distance <= 2
        Item best = null; int bestD = 3;
        for (Item it : all) {
            int d = dist(q, it.label.toLowerCase(Locale.ROOT));
            if (d < bestD) { bestD = d; best = it; }
        }
        return best == null ? null : best.pkg;
    }

    private static boolean installed(Context c, String pkg) {
        try {
            c.getPackageManager().getApplicationInfo(pkg, 0);
            return true;
        } catch (Exception e) { return false; }
    }

    private static String resolveGeneric(Context c, String kind) {
        try {
            PackageManager pm = c.getPackageManager();
            Intent i;
            if (kind.equals("camera")) i = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            else if (kind.equals("gallery")) {
                i = new Intent(Intent.ACTION_VIEW);
                i.setType("image/*");
            } else if (kind.equals("browser")) {
                i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://example.com"));
            } else if (kind.equals("maps")) {
                i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0"));
            } else if (kind.equals("clock")) {
                i = new Intent("android.intent.action.SHOW_ALARMS");
            } else {
                i = new Intent(kind.equals("settings")
                        ? android.provider.Settings.ACTION_SETTINGS : Intent.ACTION_MAIN);
            }
            ResolveInfo ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            return ri == null || ri.activityInfo == null ? null : ri.activityInfo.packageName;
        } catch (Exception e) { return null; }
    }

    public static boolean launch(Context c, String pkg) {
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static String labelOf(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception e) { return pkg; }
    }

    public static byte[] iconPng(Context c, String pkg) {
        try {
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            int S = 96;
            Bitmap bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            d.setBounds(0, 0, S, S);
            d.draw(canvas);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 90, bo);
            return bo.toByteArray();
        } catch (Exception e) { return null; }
    }

    private static int dist(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }
}
