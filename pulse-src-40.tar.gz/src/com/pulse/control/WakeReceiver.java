package com.pulse.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires from AlarmManager to light up the screen. */
public class WakeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                        android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                                | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP, "pulse:wake2");
                wl.acquire(6000);
                wl.release();
            }
        } catch (Exception ignored) {}
    }
}
