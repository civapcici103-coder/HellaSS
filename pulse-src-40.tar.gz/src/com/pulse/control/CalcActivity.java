package com.pulse.control;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Fully working calculator. Entering the secret code + "=" opens the control panel. */
public class CalcActivity extends Activity {

    private EditText display;
    private double acc = 0;
    private String op = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // Android 16: edge-to-edge — не даём UI уехать под панели
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        } catch (Throwable ignored) {}
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF121212);
        root.setPadding(dp(16), dp(40), dp(16), dp(24));

        display = new EditText(this);
        display.setTextSize(34);
        display.setTextColor(0xFFFFFFFF);
        display.setGravity(Gravity.END);
        display.setSingleLine(true);
        display.setBackground(null);
        display.setText("0");
        display.setInputType(0);
        root.addView(display, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(90)));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        String[] keys = {"C", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "⌫", "="};
        for (String k : keys) {
            Button btn = new Button(this);
            btn.setText(k);
            btn.setTextSize(24);
            btn.setTextColor(k.equals("=") ? 0xFF00E68A : 0xFFFFFFFF);
            btn.setBackgroundColor(k.matches("[+\\-×÷=]") ? 0xFF1B3A2A : 0xFF1E1E1E);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = dp(70);
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            btn.setLayoutParams(lp);
            btn.setOnClickListener(this::onKey);
            grid.addView(btn);
        }
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void onKey(View v) {
        String k = ((Button) v).getText().toString();
        String cur = display.getText().toString();
        try {
            switch (k) {
                case "C": display.setText("0"); acc = 0; op = ""; break;
                case "⌫": display.setText(cur.length() > 1 ? cur.substring(0, cur.length() - 1) : "0"); break;
                case "±": display.setText(cur.startsWith("-") ? cur.substring(1) : "-" + cur); break;
                case "%": display.setText(trim(parse(cur) / 100)); break;
                case "+": case "−": case "×": case "÷":
                    acc = parse(cur); op = k; display.setText("0"); break;
                case "=": {
                    // secret code check
                    String code = Config.calcCode(this);
                    if (cur.equals(code)) {
                        startActivity(new android.content.Intent(this, MainActivity.class));
                        display.setText("0");
                        return;
                    }
                    double r = calc(acc, parse(cur), op);
                    display.setText(trim(r));
                    acc = r; op = "";
                    break;
                }
                default: {
                    if (cur.equals("0") || cur.equals("-0")) display.setText(k);
                    else display.setText(cur + k);
                }
            }
        } catch (Exception e) {
            display.setText("Ошибка");
        }
    }

    private double parse(String s) { return s.isEmpty() ? 0 : Double.parseDouble(s); }

    private double calc(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "−": return a - b;
            case "×": return a * b;
            case "÷": return b == 0 ? 0 : a / b;
            default: return b;
        }
    }

    private String trim(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);
        return String.format(java.util.Locale.getDefault(), "%.8f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
