package com.pulse.control;

import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.SystemClock;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Device info + system actions shared by UI and bot. */
public final class Sys {

    private Sys() {}

    public static String deviceName() {
        String m = Build.MANUFACTURER, model = Build.MODEL;
        if (model.toLowerCase(Locale.ROOT).startsWith(m.toLowerCase(Locale.ROOT))) return cap(model);
        return cap(m) + " " + model;
    }

    private static String cap(String s) {
        if (s == null || s.isEmpty()) return "";
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
    }

    public static int batteryPercent(Context c) {
        try {
            BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
            return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Exception e) {
            try {
                Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                int level = i == null ? 0 : i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
                int scale = i == null ? 100 : i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                return scale == 0 ? 0 : (int) (100f * level / scale);
            } catch (Exception e2) { return -1; }
        }
    }

    public static boolean charging(Context c) {
        try {
            BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
            return bm.isCharging();
        } catch (Exception e) {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int s = i == null ? -1 : i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            return s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL;
        }
    }

    public static float batteryTemp(Context c) {
        try {
            Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int t = i == null ? 0 : i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            return t / 10f;
        } catch (Exception e) { return 0f; }
    }

    public static String netName(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return "офлайн";
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            if (caps == null) return "офлайн";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "LAN";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "LTE";
            return "сеть";
        } catch (Exception e) { return "—"; }
    }

    public static boolean online(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(n);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return false; }
    }

    public static String time() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    public static String uptime() {
        long ms = SystemClock.elapsedRealtime();
        long h = ms / 3600000, m = (ms % 3600000) / 60000;
        return h > 0 ? h + " ч " + m + " мин" : m + " мин";
    }

    public static String freeRam(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return String.format(Locale.getDefault(), "%.1f ГБ", mi.availMem / 1073741824.0);
        } catch (Exception e) { return "—"; }
    }

    public static String freeStorage() {
        try {
            StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
            return String.format(Locale.getDefault(), "%.0f ГБ", sf.getAvailableBytes() / 1073741824.0);
        } catch (Exception e) { return "—"; }
    }

    public static String footer(Context c) {
        int pct = batteryPercent(c);
        String charge = charging(c) ? "⚡" : "";
        String ping = BotService.lastPing >= 0 ? " · ⏱ " + BotService.lastPing + " мс" : "";
        return "🔋 <b>" + pct + "%</b>" + charge + " · 🌐 " + netName(c) + ping
                + " · 🧮 " + BotService.cmdCount;
    }

    // ------------------------------------------------------------ audio

    public static int[] musicVolume(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            return new int[]{am.getStreamVolume(AudioManager.STREAM_MUSIC),
                    Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC))};
        } catch (Exception e) { return new int[]{0, 1}; }
    }

    public static int[] ringVolume(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            return new int[]{am.getStreamVolume(AudioManager.STREAM_RING),
                    Math.max(1, am.getStreamMaxVolume(AudioManager.STREAM_RING))};
        } catch (Exception e) { return new int[]{0, 1}; }
    }

    /** steps>0 louder, <0 quieter. Returns new percentage. */
    public static int adjustMusic(Context c, int steps) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, steps > 0
                    ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
            int[] v = musicVolume(c);
            return v[0] * 100 / v[1];
        } catch (Exception e) { return -1; }
    }

    public static int adjustRing(Context c, int steps) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_RING, steps > 0
                    ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, 0);
            int[] v = ringVolume(c);
            return v[0] * 100 / v[1];
        } catch (Exception e) { return -1; }
    }

    public static void mute(Context c, boolean mute) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                    mute ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, 0);
        } catch (Exception ignored) {}
    }

    public static void volumeMax(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
            am.setStreamVolume(AudioManager.STREAM_RING, am.getStreamMaxVolume(AudioManager.STREAM_RING), 0);
        } catch (Exception ignored) {}
    }

    public static void mediaKey(Context c, int keyCode) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            long now = SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now,
                    android.view.KeyEvent.ACTION_DOWN, keyCode, 0));
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(now, now,
                    android.view.KeyEvent.ACTION_UP, keyCode, 0));
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ clipboard

    public static String clipboard(Context c) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (!cm.hasPrimaryClip()) return null;
            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return null;
            CharSequence t = clip.getItemAt(0).coerceToText(c);
            return t == null ? null : t.toString();
        } catch (Exception e) { return null; }
    }

    public static boolean setClipboard(Context c, String text) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Pulse", text));
            return true;
        } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------ brightness

    public static int brightness(Context c) {
        try {
            return android.provider.Settings.System.getInt(c.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, 128);
        } catch (Exception e) { return 128; }
    }

    public static boolean setBrightness(Context c, int percent) {
        try {
            android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE,
                    android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, Math.max(1, percent * 255 / 100));
            return true;
        } catch (Exception e) { return false; }
    }

    public static void adjustBrightness(Context c, int steps) {
        try {
            int cur = brightness(c);
            int next = Math.max(5, Math.min(255, cur + steps * 25));
            setBrightness(c, next * 100 / 255);
        } catch (Exception ignored) {}
    }

    public static boolean setBrightnessAuto(Context c) {
        try {
            android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE,
                    android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
            return true;
        } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------ location

    public interface LocCb { void ok(double lat, double lon, float acc); void err(String why); }

    public static void location(Context c, LocCb cb) {
        new Thread(() -> {
            try {
                LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER,
                        LocationManager.PASSIVE_PROVIDER}) {
                    try {
                        Location l = lm.getLastKnownLocation(p);
                        if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                    } catch (Exception ignored) {}
                }
                if (best != null) { cb.ok(best.getLatitude(), best.getLongitude(), best.getAccuracy()); return; }
                Criteria cr = new Criteria();
                cr.setAccuracy(Criteria.ACCURACY_COARSE);
                String prov = lm.getBestProvider(cr, true);
                if (prov == null) { cb.err("геолокация выключена"); return; }
                final boolean[] fired = {false};
                android.location.LocationListener ll = new android.location.LocationListener() {
                    @Override public void onLocationChanged(Location location) {
                        synchronized (fired) { if (fired[0]) return; fired[0] = true; }
                        cb.ok(location.getLatitude(), location.getLongitude(), location.getAccuracy());
                    }
                    @Override public void onStatusChanged(String s, int i, android.os.Bundle b) {}
                    @Override public void onProviderEnabled(String s) {}
                    @Override public void onProviderDisabled(String s) {}
                };
                lm.requestLocationUpdates(prov, 0, 0, ll, android.os.Looper.getMainLooper());
                Thread.sleep(20000);
                synchronized (fired) { if (!fired[0]) cb.err("не удалось получить координаты (проверьте разрешение и GPS)"); }
                try { lm.removeUpdates(ll); } catch (Exception ignored) {}
            } catch (Exception e) {
                cb.err(String.valueOf(e.getMessage()));
            }
        }, "pulse-geo").start();
    }

    // ------------------------------------------------------------ apps in foreground

    public static String foregroundApp(Context c) {
        String p = BotService.lastForegroundPkg;
        if (p == null) return null;
        return Apps.labelOf(c, p);
    }
}
