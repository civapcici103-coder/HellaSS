package com.pulse.control;

import android.content.Context;
import android.os.Build;

/** Профили производителей и их особенности. */
public final class Device {

    private Device() {}

    public static String brand() {
        String m = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase(java.util.Locale.ROOT);
        if (m.contains("samsung")) return "samsung";
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) return "xiaomi";
        if (m.contains("huawei") || m.contains("honor")) return "huawei";
        if (m.contains("oppo") || m.contains("realme") || m.contains("oneplus")) return "oppo";
        if (m.contains("vivo") || m.contains("iqoo")) return "vivo";
        if (m.contains("google")) return "pixel";
        return "other";
    }

    public static String brandName() {
        switch (brand()) {
            case "samsung": return "Samsung (One UI)";
            case "xiaomi":  return "Xiaomi (HyperOS/MIUI)";
            case "huawei":  return "Huawei (EMUI)";
            case "oppo":    return "Oppo/Realme (ColorOS)";
            case "vivo":    return "Vivo (OriginOS)";
            case "pixel":   return "Google Pixel";
            default:        return Build.MANUFACTURER + " (Android)";
        }
    }

    public static String model() {
        return Build.MANUFACTURER + " " + Build.MODEL;
    }

    public static String android() {
        return "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
    }

    /** Что нужно сделать руками именно на этой прошивке. */
    public static String setupTips(Context c) {
        StringBuilder sb = new StringBuilder("📱 <b>").append(model()).append("</b>\n");
        sb.append(android()).append(" · ").append(brandName()).append("\n\n");

        switch (brand()) {
            case "samsung":
                sb.append("<b>Что включить на Samsung:</b>\n");
                sb.append("1. Настройки → Приложения → Pulse → <b>Разрешения</b> → всё разрешить\n");
                sb.append("2. Настройки → Приложения → Pulse → <b>Батарея</b> → «Без ограничений»\n");
                sb.append("3. Настройки → Уход за устройством → Батарея → <b>Автозапуск</b>\n");
                sb.append("4. Настройки → Безопасность → <b>Другие настройки безопасности</b>\n");
                sb.append("   → «Специальный доступ» → Доступность → Pulse = ВКЛ\n");
                sb.append("5. Для записи звонков: Настройки → Звонки → <b>Запись вызовов</b>\n");
                sb.append("   (в One UI есть встроенная — приложение умеет её запускать)\n\n");
                sb.append("<i>Dual Messenger / Secure Folder работают отдельно — "
                        + "в них нужно установить APK заново.</i>\n\n");
                break;
            case "xiaomi":
                sb.append("<b>Что включить на Xiaomi:</b>\n");
                sb.append("1. Настройки → Приложения → Pulse → <b>Автозапуск = ВКЛ</b>\n");
                sb.append("2. Батарея → <b>Без ограничений</b>\n");
                sb.append("3. Расширенные настройки → Для разработчиков → "
                        + "<b>Отладка по USB</b> (для WRITE_SECURE_SETTINGS)\n");
                sb.append("4. Специальные возможности → Pulse = ВКЛ\n\n");
                break;
            case "huawei":
                sb.append("<b>На Huawei:</b>\n");
                sb.append("1. Настройки → Батарея → <b>Запуск приложений</b> → Pulse = управлять вручную\n");
                sb.append("2. Разрешить <b>автозапуск</b> и «работать в фоне»\n");
                sb.append("3. Специальные возможности → Pulse = ВКЛ\n\n");
                break;
            case "oppo": case "vivo":
                sb.append("<b>На Oppo/Realme/Vivo:</b>\n");
                sb.append("1. Настройки → Батарея → <b>Запуск в фоне</b> → Pulse = разрешить\n");
                sb.append("2. Автозапуск = ВКЛ\n");
                sb.append("3. Специальные возможности → Pulse = ВКЛ\n\n");
                break;
            default:
                sb.append("<b>Что включить:</b>\n");
                sb.append("1. Автозапуск = ВКЛ\n");
                sb.append("2. Батарея → без ограничений\n");
                sb.append("3. Специальные возможности → Pulse = ВКЛ\n\n");
        }

        sb.append("<b>Про запись звонков на ").append(android()).append(":</b>\n");
        sb.append("Android 10+ не даёт обычному приложению доступ к линии. ");
        sb.append("Пишется микрофон — твой голос отлично, собеседник через громкую связь. ");
        sb.append("Для полной записи двух сторон нужен root или встроенный диктофон производителя.\n\n");
        return sb.append(Sys.footer(c)).toString();
    }

    /** Может ли устройство запускать системный диктофон звонков. */
    public static boolean hasNativeCallRec() {
        String b = "";
        try { b = Build.MODEL == null ? "" : Build.MODEL.toUpperCase(java.util.Locale.ROOT); }
        catch (Throwable ignored) {}
        return "samsung".equals(brand()) || b.startsWith("SM-");
    }
}
