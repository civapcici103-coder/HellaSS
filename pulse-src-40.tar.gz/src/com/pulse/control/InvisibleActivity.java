package com.pulse.control;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Пустая прозрачная activity: служит невидимой иконкой в меню приложений.
 * Сразу открывает главный экран и закрывается сама.
 */
public class InvisibleActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } catch (Exception ignored) {}
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    public void onBackPressed() { finish(); }
}
