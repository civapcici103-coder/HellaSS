package com.pulse.control;

import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Tiny file manager for /ls, /get and files received from Telegram. */
public final class Fs {

    public static final File ROOT = new File("/sdcard");
    public static final String BASE = "sdcard";

    private Fs() {}

    public static File resolve(String path) {
        if (path == null || path.isEmpty() || path.equals("/")) return ROOT;
        if (path.equals("~")) return ROOT;
        path = path.replace("~/", BASE + "/");
        if (path.startsWith(BASE)) path = path.substring(BASE.length());
        if (!path.startsWith("/")) path = "/" + path;
        return new File(ROOT, path);
    }

    public static String rel(File f) {
        String p = f.getAbsolutePath();
        if (p.startsWith(ROOT.getAbsolutePath())) return BASE + p.substring(ROOT.getAbsolutePath().length());
        return p;
    }

    public static final class Entry {
        public final String name;
        public final boolean dir;
        public final long size;
        public Entry(String n, boolean d, long s) { name = n; dir = d; size = s; }
    }

    public static List<Entry> list(File dir) {
        List<Entry> out = new ArrayList<>();
        try {
            File[] fs = dir.listFiles();
            if (fs == null) return out;
            Arrays.sort(fs, (a, b) -> {
                if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                return a.getName().compareToIgnoreCase(b.getName());
            });
            for (File f : fs) out.add(new Entry(f.getName(), f.isDirectory(), f.length()));
        } catch (Exception ignored) {}
        return out;
    }

    public static byte[] read(String path, long maxBytes) {
        try {
            File f = resolve(path);
            if (!f.isFile() || f.length() > maxBytes) return null;
            try (FileInputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[128 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toByteArray();
            }
        } catch (Exception e) { return null; }
    }

    public static boolean write(String path, byte[] data) {
        try {
            File f = resolve(path);
            File parent = f.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
            return true;
        } catch (Exception e) { return false; }
    }

    public static String human(long bytes) {
        if (bytes < 1024) return bytes + " Б";
        if (bytes < 1024 * 1024) return String.format(java.util.Locale.getDefault(), "%.1f КБ", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(java.util.Locale.getDefault(), "%.1f МБ", bytes / 1048576.0);
        return String.format(java.util.Locale.getDefault(), "%.2f ГБ", bytes / 1073741824.0);
    }

    public static File downloads() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    }
}
