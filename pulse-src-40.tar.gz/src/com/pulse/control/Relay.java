package com.pulse.control;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Релей: приём команд с удалённой панели и ответы обратно.
 *
 * ГЛАВНОЕ, что здесь важно понимать (на этом сгорели 4 версии):
 *
 * ntfy.sh — публичный сервер. Если соединение «умерло» (телефон уснул,
 * Wi-Fi сменил сеть, NAT выкинул поток), то TCP этого НЕ сообщает:
 * FIN не приходит, readLine() просто висит вечно. setReadTimeout(0) в этом
 * случае = мёртвый релей, который при этом показывает «подключён ✅».
 *
 * Поэтому здесь три независимых механизма:
 *   1. ReadTimeout 25 с, а ntfy шлёт keepalive каждые ~20 с → тишина = смерть.
 *   2. ОПРОС каждые 6 секунд (since=2m) — это ОСНОВНОЙ канал доставки, а не
 *      вспомогательный. Он не зависит от SSE вообще: стрим может быть мёртв,
 *      порван, заблокирован — команда всё равно выполнится за ≤6 секунд.
 *      SSE нужен только чтобы выполнять мгновенно, когда он жив.
 *   3. Сторожевой таймер: нет сообщений/keepalive дольше 60 с → рвём и
 *      переподключаемся (сначала через 2 с, потом плавно до 30 с).
 *
 * Команды НЕ дедуплицируются по времени (часы телефонов расходятся).
 * Дедупликация по id сообщения ntfy + по «отпечатку» (cmd + ts), чтобы
 * повторная доставка из since=1h после переподключения не выполнилась дважды.
 */
public class Relay {

    private static final String BASE = "https://ntfy.sh";
    private static final String KEY_ON = "relay_on";
    private static final String KEY_CHANNEL = "relay_channel";

    /**
     * ntfy шлёт keepalive РОВНО раз в 45 секунд (замерено).
     * Если поставить меньше — стрим рвётся каждые N секунд, а после обрыва
     * уходит запрос истории, который «съедает» команды дедупом. Держим запас.
     */
    private static final int READ_TIMEOUT_MS = 120000;
    /** Столько тишины = соединение мертво, даже если TCP молчит. */
    private static final long SILENCE_LIMIT_MS = 100000L;
    /** Как часто проверять живость канала независимо от стрима. */
    private static final long PING_PERIOD_MS = 20000L;

    private static volatile boolean running = false;
    private static volatile Thread worker = null;
    private static volatile Thread pinger = null;
    static volatile long lastEvent = 0;      // последнее сообщение от панели
    static volatile long lastByte = 0;       // любой байт в стриме (keepalive)
    static volatile long lastPingOk = 0;     // последний успешный ping
    static volatile int reconnects = 0;
    static volatile String lastError = "";
    static volatile String lastCmd = "";
    /** Счётчик запросов к ntfy за последние 5 минут — лимит сервера 60. */
    static volatile int reqCount = 0;
    static volatile long reqWindow = 0;
    static volatile int last429 = 0;   // сколько раз упёрлись в лимит

    private static void countReq() {
        long now = System.currentTimeMillis();
        if (now - reqWindow > 300000L) { reqWindow = now; reqCount = 0; }
        reqCount++;
    }

    private static final List<JSONArray> pending = new ArrayList<>();

    private Relay() {}

    // ------------------------------------------------------------- канал

    public static String channel(Context c) {
        String ch = c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getString(KEY_CHANNEL, "");
        if (ch == null || ch.isEmpty()) {
            ch = "pulse_" + hash("" + System.currentTimeMillis() + Math.random()).substring(0, 16);
            c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putString(KEY_CHANNEL, ch).apply();
        }
        return ch;
    }

    public static void regenerate(Context c) {
        String ch = "pulse_" + hash("" + System.currentTimeMillis() + Math.random()).substring(0, 16);
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putString(KEY_CHANNEL, ch).apply();
        lastError = "";
    }

    public static boolean enabled(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getBoolean(KEY_ON, true);
    }

    public static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putBoolean(KEY_ON, on).apply();
        if (on) RelayService.start(c);
        else RelayService.stop(c);
    }

    // ------------------------------------------------------------- отправка

    public static void publish(Context c, String kind, String text) {
        try {
            JSONObject o = new JSONObject();
            o.put("kind", kind);
            o.put("text", text);
            o.put("ts", System.currentTimeMillis());
            if ("ack".equals(kind)) {
                o.put("battery", Sys.batteryPercent(c));
                o.put("screenOn", isScreenOn(c));
            }
            post(c, o.toString());
        } catch (Exception ignored) {}
    }

    public static void heartbeat(Context c) {
        try {
            JSONObject o = new JSONObject();
            o.put("kind", "status");
            o.put("battery", Sys.batteryPercent(c));
            o.put("charging", Sys.charging(c));
            o.put("net", online(c));
            o.put("screenOn", isScreenOn(c));
            o.put("up", android.os.SystemClock.elapsedRealtime() / 1000);
            o.put("dev", android.os.Build.DEVICE);
            o.put("model", android.os.Build.MODEL);
            o.put("brand", android.os.Build.BRAND);
            o.put("android", android.os.Build.VERSION.RELEASE);
            o.put("queue", safeQueue(c));

            // ── то, что панель показывает в «Связь и живость» ──
            o.put("relay", true);                  // слушатель команд ВКЛЮЧЁН
            o.put("relayOn", enabled(c));
            o.put("relaySvc", RelayService.isAlive());
            o.put("relayStream", isRunning());
            o.put("relayPing", lastPingOk == 0 ? -1 : (System.currentTimeMillis() - lastPingOk) / 1000);
            o.put("relayErr", lastError);
            o.put("channel", channel(c));           // панель сама запомнит канал
            o.put("tgUp", true);
            // запись звонков — чтобы блок не показывал прочерки
            try {
                o.put("callRec", CallRec.mode(c));
                o.put("callRecContacts", CallRec.contacts(c).length());
                o.put("recording", CallRec.isRecording());
            } catch (Throwable ignored) {}

            o.put("ts", System.currentTimeMillis());
            post(c, o.toString());
        } catch (Exception ignored) {}
    }

    private static int safeQueue(Context c) {
        try { return WebServer.safeQueue(c); } catch (Throwable t) { return 0; }
    }

    private static void post(Context c, String body) {
        HttpURLConnection conn = null;
        countReq();
        try {
            conn = (HttpURLConnection) new URL(BASE + "/" + channel(c)).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            conn.setRequestProperty("Cache-Control", "no-store");
            byte[] b = body.getBytes("UTF-8");
            conn.setFixedLengthStreamingMode(b.length);
            conn.getOutputStream().write(b);
            int code = conn.getResponseCode();
            if (code == 429) { last429++; count429(); }
            conn.getInputStream().close();
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** Отправить команду на телефон (используется ботом и панелью). */
    public static boolean sendCommand(Context c, String cmd) {
        try {
            JSONObject o = new JSONObject();
            o.put("kind", "cmd");
            o.put("cmd", cmd);
            o.put("ts", System.currentTimeMillis());
            o.put("from", "bot");
            post(c, o.toString());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------- приём

    /**
     * Слушатель команд.
     *
     * Стратегия — «сначала догоняем, потом висим на стриме»:
     *  - при каждом подключении сначала poll=1&since=1h — забираем всё,
     *    что пришло, пока мы спали или были без сети (до 1 часа истории);
     *  - затем открываем стрим с конечным readTimeout;
     *  - сторож рвёт соединение, если тишина дольше SILENCE_LIMIT_MS;
     *  - ping-цикл подтверждает живость канала независимо от стрима.
     */
    public static void start(final Context ctx) {
        if (running) return;
        running = true;
        final Context c = ctx.getApplicationContext();

        // ═══ сторож мёртвого соединения ═══
        Thread guard = new Thread(() -> {
            while (running) {
                try { Thread.sleep(5000); } catch (InterruptedException e) { break; }
                long now = System.currentTimeMillis();
                long lb = lastByte;
                // если байтов не было дольше лимита — поток мёртв, хоть и «подключён»
                if (lb > 0 && now - lb > SILENCE_LIMIT_MS) {
                    LogStore.add("📡 Тишина " + ((now - lb) / 1000) + " с — переподключаюсь");
                    lastByte = 0;
                    lastError = "тишина в стриме";
                    Thread w = worker;
                    if (w != null) w.interrupt();     // readLine реагирует только на таймаут
                }
            }
        }, "pulse-relay-guard");
        guard.setDaemon(true);
        guard.start();

        // ═══ ОПРОС: основной канал доставки, SSE только ускоряет ═══
        // Даже если стрим мёртв, команда выполнится максимум через 6 секунд.
        pinger = new Thread(() -> {
            while (running) {
                try {
                    boolean ok = pollOnce(c, "3m") >= 0;
                    if (ok) lastPingOk = System.currentTimeMillis();
                } catch (Exception ignored) {}
                try { Thread.sleep(PING_PERIOD_MS); } catch (InterruptedException e) { break; }
            }
        }, "pulse-relay-ping");
        pinger.setDaemon(true);
        pinger.start();

        // ═══ основной поток ═══
        worker = new Thread(() -> {
            int backoff = 2000;
            while (running) {
                HttpURLConnection conn = null;
                BufferedReader r = null;
                try {
                    // Пропущенное догоняет ping-цикл (since=5m) — здесь НЕ зовём
                    // историю: после реконнекта она вернула бы наши же команды,
                    // дедуп по id заблокировал бы их собственный cmd:fp,
                    // и команда терялась бы навсегда.

                    // встаём на стрим
                    String url = BASE + "/" + channel(c) + "/json?since=1h";
                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(READ_TIMEOUT_MS);   // ← НЕ 0!
                    conn.setRequestProperty("Accept", "application/x-ndjson");
                    conn.setRequestProperty("Cache-Control", "no-store");

                    lastByte = System.currentTimeMillis();
                    r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    backoff = 2000;
                    reconnects++;
                    LogStore.add("📡 Релей на связи · " + channel(c));

                    String line;
                    while (running && (line = r.readLine()) != null) {
                        lastByte = System.currentTimeMillis();
                        if (line.trim().isEmpty()) continue;
                        try {
                            JSONObject j = new JSONObject(line);
                            if (!"message".equals(j.optString("event"))) continue;
                            String id = j.optString("id", "");
                            if (!id.isEmpty() && !seen.add(id)) continue;
                            lastEvent = System.currentTimeMillis();
                            String msg = j.optString("message", "");
                            if (msg.trim().startsWith("{")) {
                                handle(c, new JSONObject(msg));
                            }
                        } catch (Exception ignored) {}
                    }
                } catch (Exception e) {
                    lastError = e.getClass().getSimpleName();
                    LogStore.add("📡 Поток: " + lastError + " → переподключение");
                } finally {
                    try { if (r != null) r.close(); } catch (Exception ignored) {}
                    try { if (conn != null) conn.disconnect(); } catch (Exception ignored) {}
                }
                if (!running) break;
                try { Thread.sleep(backoff); } catch (InterruptedException ie) { break; }
                backoff = Math.min(backoff * 2, 30000);
            }
            running = false;
        }, "pulse-relay");
        worker.setDaemon(true);
        worker.start();
    }

    /**
     * Один опрос (не стрим). Возвращает число новых сообщений или -1 при ошибке.
     * Используется и как ping, и как «догоняем пропущенное».
     */
    /** Упёрлись в лимит: притормозим опрос, чтобы не злить сервер сильнее. */
    private static void count429() {
        LogStore.add("⏳ ntfy: лимит запросов (60 за 5 мин)");
        try { Thread.sleep(3000); } catch (Exception ignored) {}
    }

    public static int pollOnce(Context c, String since) {
        HttpURLConnection conn = null;
        BufferedReader r = null;
        int n = 0;
        countReq();
        try {
            String url = BASE + "/" + channel(c) + "/json?poll=1&since=" + since;
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("Cache-Control", "no-store");
            r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    JSONObject j = new JSONObject(line);
                    if (!"message".equals(j.optString("event"))) continue;
                    String id = j.optString("id", "");
                    if (!id.isEmpty() && !seen.add(id)) continue;
                    lastEvent = System.currentTimeMillis();
                    String msg = j.optString("message", "");
                    if (msg.trim().startsWith("{")) {
                        n++;
                        handle(c, new JSONObject(msg));
                    }
                } catch (Exception ignored) {}
            }
            lastPingOk = System.currentTimeMillis();
            return n;
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName();
            return -1;
        } finally {
            try { if (r != null) r.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.disconnect(); } catch (Exception ignored) {}
        }
    }

    /** Старый API: полный опрос в список. */
    public static List<JSONObject> poll(Context c, String since) {
        List<JSONObject> out = new ArrayList<>();
        HttpURLConnection conn = null;
        BufferedReader r = null;
        try {
            String url = BASE + "/" + channel(c) + "/json?poll=1&since=" + since;
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    JSONObject j = new JSONObject(line);
                    if ("message".equals(j.optString("event"))) out.add(j);
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
        } finally {
            try { if (r != null) r.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.disconnect(); } catch (Exception ignored) {}
        }
        return out;
    }

    // ------------------------------------------------------------- дедуп

    private static final java.util.Set<String> seen = java.util.Collections.newSetFromMap(
            new java.util.LinkedHashMap<String, Boolean>() {
                @Override protected boolean removeEldestEntry(Map.Entry<String, Boolean> e) {
                    return size() > 600;
                }
            });

    public static void stop() {
        running = false;
        Thread w = worker, p = pinger;
        worker = null;
        pinger = null;
        if (w != null) w.interrupt();
        if (p != null) p.interrupt();
    }

    public static boolean isRunning() { return running; }

    // ------------------------------------------------------------- выполнение

    private static void handle(Context c, JSONObject ev) {
        try {
            String kind = ev.optString("kind", "");
            if ("cmd".equals(kind)) {
                String cmd = ev.optString("cmd", "");
                if (cmd.isEmpty()) return;

                // защита от повторного выполнения после переподключения
                String fp = hash(cmd + "|" + ev.optLong("ts", 0)).substring(0, 12);
                if (!seen.add("cmd:" + fp)) return;
                lastCmd = cmd;

                LogStore.add("📡 Команда: " + cmd);
                try { RelayService.refresh(c, "Выполняю: " + cmd); } catch (Exception ignored) {}

                PowerManager.WakeLock wl = null;
                try {
                    PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                    if (pm != null) {
                        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pulse:cmd");
                        wl.setReferenceCounted(false);
                        wl.acquire(30000);
                    }
                } catch (Exception ignored) {}

                String err;
                try {
                    err = WebServer.runCommand(c, cmd);
                } catch (Throwable t) {
                    err = t.getClass().getSimpleName() + ": " + t.getMessage();
                } finally {
                    try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) {}
                }

                try { RelayService.refresh(c, "Pulse Control · " + channel(c)); } catch (Exception ignored) {}
                publish(c, "ack", err == null ? "✓ " + cmd : "✕ " + cmd + " → " + err);

            } else if ("ping".equals(kind)) {
                heartbeat(c);
                publish(c, "ack", "pong");

            } else if ("hello".equals(kind) || "statusreq".equals(kind)) {
                heartbeat(c);
            }
        } catch (Exception ignored) {}
    }

    /** Отметить событие как увиденное (для внешних вызовов). */
    public static void remember(JSONObject ev) {
        String id = ev.optString("id", "");
        if (!id.isEmpty()) seen.add(id);
    }

    private static JSONArray jsonArrayOf(JSONObject o) {
        JSONArray a = new JSONArray();
        a.put(o);
        return a;
    }

    public static JSONArray recent() {
        JSONArray a = new JSONArray();
        synchronized (pending) {
            for (JSONArray x : pending) for (int i = 0; i < x.length(); i++) a.put(x.opt(i));
        }
        return a;
    }

    public static void clearRecent() {
        synchronized (pending) { pending.clear(); }
    }

    // ------------------------------------------------------------- диагностика

    public static String diag(Context c) {
        long now = System.currentTimeMillis();
        StringBuilder b = new StringBuilder();
        b.append("<b>Диагностика связи</b>\n\n");
        b.append("Канал: <code>").append(channel(c)).append("</code>\n");
        b.append("Релей включён: ").append(enabled(c) ? "да" : "нет").append("\n");
        b.append("Служба: ").append(RelayService.isAlive() ? "работает ✅" : "НЕ ЗАПУЩЕНА ❌").append("\n");
        b.append("Поток: ").append(running ? "запущен" : "остановлен ❌").append("\n");

        if (lastByte == 0) {
            b.append("Стрим: ещё не открыт ⏳\n");
        } else {
            long s = (now - lastByte) / 1000;
            b.append("Стрим: последний байт ").append(s).append(" с назад ")
             .append(s < 60 ? "✅" : "⚠️ подозрительно долго").append("\n");
        }
        b.append("Ping: ").append(lastPingOk == 0 ? "не было ⏳"
                : ((now - lastPingOk) / 1000) + " с назад "
                  + ((now - lastPingOk) < 90000 ? "✅" : "❌")).append("\n");
        b.append("Сообщений от панели: ").append(lastEvent == 0 ? "ни одного"
                : ((now - lastEvent) / 1000) + " с назад").append("\n");
        b.append("Последняя команда: <code>").append(lastCmd.isEmpty() ? "—" : lastCmd).append("</code>\n");
        b.append("Переподключений: ").append(reconnects).append("\n");
        long winLeft = 300000L - (System.currentTimeMillis() - reqWindow);
        b.append("Запросов к ntfy: ").append(reqCount).append("/60");
        if (winLeft > 0) b.append(" (окно ещё ").append(winLeft / 1000).append(" с)");
        b.append("\n");
        if (last429 > 0) b.append("Упирались в лимит: ").append(last429).append(" раз\n");
        if (!lastError.isEmpty()) b.append("Последняя ошибка: ").append(lastError).append("\n");
        b.append("Экономный режим: ").append(Eco.on(c) ? "да (релею не мешает)" : "нет").append("\n");
        b.append("Бот: ").append(BotService.isAlive() ? "работает ✅" : "не подключён ⚠️").append("\n");
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            b.append("Батарея: ").append(pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName())
                    ? "без ограничений ✅" : "ОГРАНИЧЕНА ⚠️ телефон может спать").append("\n");
        } catch (Exception ignored) {}

        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            Network n = cm.getActiveNetwork();
            NetworkCapabilities cap = n == null ? null : cm.getNetworkCapabilities(n);
            b.append("Сеть: ").append(cap == null ? "нет ❌"
                    : cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                    : cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "мобильная"
                    : "другая").append("\n");
        }

        b.append("\n<i>Если «Ping» старее 90 с — сеть мертва. Нажми /relay_restart.</i>");
        return b.toString();
    }

    /**
     * Полный самоконтроль: отправляет тестовую команду сам себе через ntfy
     * и ждёт, выполнится ли она. Это ЕДИНСТВЕННЫЙ способ честно ответить
     * «релей работает» или «релей сломан» — не по флагам, а по факту.
     */
    public static String selfTest(Context c) {
        StringBuilder b = new StringBuilder("<b>Самопроверка релея</b>\n\n");
        String ch = channel(c);

        // 1. отправка
        long t0 = System.currentTimeMillis();
        String marker = "selftest_" + t0;
        boolean sent = sendCommand(c, marker);
        b.append(sent ? "✅ Отправка в ntfy: ок" : "❌ Отправка в ntfy: не удалось").append("\n");

        // 2. слушатель
        b.append(isRunning() ? "✅ Слушатель: запущен" : "❌ Слушатель: НЕ ЗАПУЩЕН").append("\n");
        b.append(RelayService.isAlive() ? "✅ Служба: работает" : "❌ Служба: не работает").append("\n");

        // 3. ждём, пока собственная команда вернётся и выполнится
        b.append("\n⏳ Жду возврата команды через релей");
        String got = "";
        for (int i = 0; i < 20; i++) {
            try { Thread.sleep(500); } catch (Exception ignored) {}
            if (marker.equals(lastCmd)) { got = lastCmd; break; }
            b.append(".");
        }
        b.append("\n\n");

        if (marker.equals(got)) {
            long dt = System.currentTimeMillis() - t0;
            b.append("✅ <b>РЕЛЕЙ РАБОТАЕТ</b> — круг замкнулся за ").append(dt).append(" мс\n");
            b.append("Команда с панели дойдёт и выполнится.");
        } else {
            b.append("❌ <b>РЕЛЕЙ НЕ РАБОТАЕТ</b> — команда не вернулась за 10 с.\n\n");
            b.append("Причины по порядку:\n");
            if (!isRunning()) b.append("1. Слушатель не запущен — нажми /relay_restart\n");
            if (!RelayService.isAlive()) b.append("2. Служба не работает — вероятно, One UI/EMUI её убила. Разреши автозапуск.\n");
            if (lastPingOk == 0) b.append("3. Нет связи с ntfy — проверь интернет\n");
            else b.append("3. Связь с ntfy есть (ping ")
             .append((System.currentTimeMillis() - lastPingOk) / 1000).append(" с назад)\n");
            if (!lastError.isEmpty()) b.append("4. Последняя ошибка: ").append(lastError).append("\n");
        }
        return b.toString();
    }

    /**
     * Что именно панель видит про этот телефон.
     * Если тут всё ✅, а кнопки не работают — проблема в панели, не в телефоне.
     */
    public static String panelReport(Context c) {
        StringBuilder b = new StringBuilder("<b>Что видит удалённая панель</b>\n\n");
        String ch = channel(c);
        b.append("Канал: <code>").append(ch).append("</code>\n\n");

        // 1. Отправка (телефон → ntfy)
        boolean sent = sendCommand(c, "panelprobe_" + System.currentTimeMillis());
        b.append(sent ? "✅ Телефон шлёт в ntfy" : "❌ Телефон НЕ шлёт в ntfy").append("\n");

        // 2. Приём (ntfy → телефон)
        b.append(isRunning() ? "✅ Телефон слушает ntfy" : "❌ Телефон НЕ слушает ntfy").append("\n");

        // 3. Свежесть канала
        long now = System.currentTimeMillis();
        if (lastPingOk > 0) {
            b.append("✅ Связь с ntfy: ").append((now - lastPingOk) / 1000).append(" с назад\n");
        } else {
            b.append("⏳ Проверка связи ещё не проходила\n");
        }

        // 4. Что уйдёт в панель
        b.append("\n<b>Поля для панели:</b>\n");
        b.append("relayStream = ").append(isRunning()).append("\n");
        b.append("relay = true\n");
        b.append("channel = ").append(ch).append("\n");
        b.append("relaySvc = ").append(RelayService.isAlive()).append("\n");

        b.append("\n<b>Если панель пишет «релей выкл»:</b>\n");
        b.append("• открой панель заново (Ctrl+F5), старая версия не умеет команды;\n");
        b.append("• введи канал <code>").append(ch).append("</code> в настройках панели.\n");
        return b.toString();
    }

    /** Живость Telegram (используется в /diag). */
    public static String checkTelegram(Context c) {
        StringBuilder b = new StringBuilder("<b>Telegram</b>\n\n");
        try {
            TgApi api = new TgApi(Config.get(c).token);
            Http.Resp r = api.getMe();
            b.append(r.code == 200 ? "Бот на связи ✅" : "Ошибка " + r.code + " ❌");
        } catch (Exception e) {
            b.append("Нет связи с Telegram ❌ (").append(e.getClass().getSimpleName()).append(")");
        }
        return b.toString();
    }

    public static boolean isScreenOn(Context c) {
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isInteractive();
        } catch (Exception e) {
            return true;
        }
    }

    public static boolean online(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities cap = cm.getNetworkCapabilities(n);
            return cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return false;
        }
    }

    private static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return Long.toHexString(System.currentTimeMillis());
        }
    }
}
