package com.pulse.control;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Tiny shared formatting helpers. */
public final class App {
    private App() {}
    public static String timeShort() {
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
    }
}
