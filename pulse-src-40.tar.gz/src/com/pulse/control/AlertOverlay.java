package com.pulse.control;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Крупное сообщение поверх всего экрана — «Я здесь», «Позвони маме», «Верни телефон».
 * Работает через SYSTEM_ALERT_WINDOW (разрешение уже запрашивается в мастере).
 *
 * Особенности:
 *  - показывается даже на заблокированном экране (LOCKSCREEN_OVERLAY не нужен, т.к. TYPE_APPLICATION_OVERLAY)
 *  - можно задать цвет, размер текста, длительность, звук и вибрацию
 *  - кнопка «Понял» закрывает
 *  - держится поверх других приложений
 */
public final class AlertOverlay {

    private static View view;
    private static Handler handler;
    private static Runnable autoHide;

    private AlertOverlay() {}

    public static boolean canShow(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 23)
                return android.provider.Settings.canDrawOverlays(c);
            return true;
        } catch (Exception e) { return false; }
    }

    public interface Res { void done(String err); }

    /** Показывает оверлей. @param style normal | danger | success */
    public static void show(final Context c, final String text, final String title, final String style,
                            final int seconds, final boolean vibrate, final boolean speak, final Res cb) {
        // View можно создавать ТОЛЬКО в главном потоке — иначе приложение падает,
        // когда команда пришла из фонового потока релея.
        final Context app = c.getApplicationContext();
        new Handler(Looper.getMainLooper()).post(() -> showOnMain(app, text, title, style, seconds, vibrate, speak, cb));
    }

    private static void showOnMain(Context c, String text, String title, String style,
                                   int seconds, boolean vibrate, boolean speak, Res cb) {
        try {
            if (!canShow(c)) {
                if (cb != null) cb.done("нет разрешения «Поверх других окон»");
                return;
            }
            final Context ctx = c.getApplicationContext();
            final WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) { if (cb != null) cb.done("нет WindowManager"); return; }

            hide();

            int accent = parseStyle(style);
            int bg = darken(accent);

            // ---- корневой блок
            LinearLayout root = new LinearLayout(ctx);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.CENTER);
            root.setPadding(dp(ctx, 28), dp(ctx, 36), dp(ctx, 28), dp(ctx, 30));

            GradientDrawable gd = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{bg, darken(bg)});
            gd.setCornerRadius(dp(ctx, 28));
            gd.setStroke(Math.max(2, dp(ctx, 2)), accent);
            root.setBackground(gd);

            // ---- заголовок
            if (title != null && !title.isEmpty()) {
                TextView tvTitle = new TextView(ctx);
                tvTitle.setText(title);
                tvTitle.setTextSize(17);
                tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
                tvTitle.setTextColor(accent);
                tvTitle.setGravity(Gravity.CENTER);
                tvTitle.setLetterSpacing(0.08f);
                root.addView(tvTitle, lp(0, dp(ctx, 8)));
            }

            // ---- основной текст
            TextView tv = new TextView(ctx);
            tv.setText(text == null ? "" : text);
            tv.setTextSize(text != null && text.length() > 90 ? 20 : (text != null && text.length() > 40 ? 24 : 30));
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setTextColor(0xFFF2FFFA);
            tv.setGravity(Gravity.CENTER);
            tv.setLineSpacing(dp(ctx, 5), 1f);
            root.addView(tv, lp(dp(ctx, 10), 0));

            // ---- разделитель
            View line = new View(ctx);
            GradientDrawable lg = new GradientDrawable();
            lg.setColor((accent & 0x00FFFFFF) | 0x55000000);
            lg.setCornerRadius(dp(ctx, 2));
            line.setBackground(lg);
            LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx, 2));
            lineLp.setMargins(0, dp(ctx, 22), 0, dp(ctx, 18));
            root.addView(line, lineLp);

            // ---- кнопка
            TextView btn = new TextView(ctx);
            btn.setText("Понял");
            btn.setTextSize(16);
            btn.setTypeface(Typeface.DEFAULT_BOLD);
            btn.setTextColor(0xFF04110A);
            btn.setGravity(Gravity.CENTER);
            GradientDrawable bgBtn = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{accent, darken(accent)});
            bgBtn.setCornerRadius(dp(ctx, 18));
            btn.setBackground(bgBtn);
            btn.setPadding(dp(ctx, 40), dp(ctx, 16), dp(ctx, 40), dp(ctx, 16));
            btn.setOnClickListener(v -> hide());
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            root.addView(btn, btnLp);

            // ---- окно
            // Android 8+ (включая 16): только APPLICATION_OVERLAY, TYPE_PHONE удалён
            int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

            final WindowManager.LayoutParams wlp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                            | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
                    PixelFormat.TRANSLUCENT);
            wlp.gravity = Gravity.CENTER;
            wlp.x = 0;
            wlp.y = 0;

            root.setAlpha(0f);
            wm.addView(root, wlp);
            view = root;

            // анимация появления
            root.animate().alpha(1f).setDuration(260).start();

            // ---- тактильная и звуковая отдача
            if (vibrate) {
                try { Tools.vibrate(ctx, 1); } catch (Exception ignored) {}
            }
            if (speak) {
                try { Tools.say(ctx, text, "ru"); } catch (Exception ignored) {}
            }

            // ---- автоскрытие
            if (seconds > 0) {
                handler = new Handler(Looper.getMainLooper());
                autoHide = AlertOverlay::hide;
                handler.postDelayed(autoHide, seconds * 1000L);
            }

            if (cb != null) cb.done(null);
        } catch (Exception e) {
            if (cb != null) cb.done(String.valueOf(e.getMessage()));
        }
    }

    public static void hide() {
        new Handler(Looper.getMainLooper()).post(AlertOverlay::hideOnMain);
    }

    private static void hideOnMain() {
        try {
            if (handler != null && autoHide != null) handler.removeCallbacks(autoHide);
            if (view != null) {
                final View v = view;
                final Context ctx = v.getContext();
                v.animate().alpha(0f).setDuration(160).withEndAction(() -> {
                    try {
                        WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                        if (wm != null) wm.removeView(v);
                    } catch (Exception ignored) {}
                }).start();
                view = null;
            }
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ утилиты

    private static int parseStyle(String style) {
        if (style == null) return 0xFF00E68A;
        switch (style.toLowerCase(java.util.Locale.ROOT)) {
            case "danger":  return 0xFFFF6B6B;
            case "warn":    return 0xFFFFC65C;
            case "success": return 0xFF00E68A;
            case "info":    return 0xFF4EC9FF;
            default:
                try { return Color.parseColor(style); } catch (Exception e) { return 0xFF00E68A; }
        }
    }

    private static int darken(int color) {
        float f = 0.18f;
        int r = (int) (Color.red(color) * f);
        int g = (int) (Color.green(color) * f);
        int b = (int) (Color.blue(color) * f);
        return Color.rgb(Math.max(4, r), Math.max(10, g), Math.max(6, b));
    }

    private static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density);
    }

    private static LinearLayout.LayoutParams lp(int topMargin, int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = topMargin;
        p.bottomMargin = bottomMargin;
        return p;
    }
}
