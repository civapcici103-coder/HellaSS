package com.pulse.control;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Background brain of v2.1: tracking, digest, watchdog, wifi triggers, scheduled
 * commands. Started by BotService as a daemon thread.
 */
public final class Background {

    private static Thread thread;
    private static volatile boolean stop = false;
    private static long lastDigestDay = -1;
    private static long lastTrack = 0;
    private static long lastRun = 0;
    private static String lastWifi = "";

    private Background() {}

    public static void start(Context c) {
        if (thread != null && thread.isAlive()) return;
        stop = false;
        final Context ctx = c.getApplicationContext();
        thread = new Thread(() -> loop(ctx), "pulse-bg");
        thread.setDaemon(true);
        thread.start();
        LogStore.add("🧠 Фоновый мозг запущен (трекинг/дайджест/watchdog)");
    }

    public static void stop() { stop = true; }

    private static void loop(Context c) {
        while (!stop) {
            try {
                Thread.sleep(60000);
                long now = System.currentTimeMillis();

                // digest at the configured hour
                int digestHour = Config.digestHour(c);
                if (digestHour >= 0) {
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    int day = cal.get(java.util.Calendar.DAY_OF_YEAR);
                    if (cal.get(java.util.Calendar.HOUR_OF_DAY) == digestHour && lastDigestDay != day) {
                        lastDigestDay = day;
                        Act.sendToAdmin(buildDigest(c), null);
                    }
                }

                // tracking every 15 min
                if (Config.tracking(c) && now - lastTrack > 15 * 60 * 1000L) {
                    lastTrack = now;
                    sendLocationOnce(c);
                }

                // watchdog: engine died?
                if (!BotService.isUp() && BotService.isServiceOn() && now - lastRun > 5 * 60 * 1000L) {
                    lastRun = now;
                    LogStore.add("🩺 Watchdog: движок молчит, перезапускаю");
                    BotService.reload(c);
                    Act.sendToAdmin("🩺 <b>Watchdog</b>\nДвижок не отвечал — перезапустил.", null);
                }

                // wifi trigger
                checkWifiTrigger(c);

                // scheduled commands
                Sched.tick(c, (cmd, arg) -> runAction(c, cmd, arg));

            } catch (InterruptedException e) { break; }
            catch (Exception ignored) {}
        }
    }

    // ------------------------------------------------------------ tracking

    private static void sendLocationOnce(Context c) {
        Sys.location(c, new Sys.LocCb() {
            @Override public void ok(double lat, double lon, float acc) {
                new Thread(() -> Act.sendToAdmin("📍 <b>Трекинг</b>\n"
                        + "https://maps.google.com/?q=" + lat + "," + lon
                        + "\nТочность: ~" + Math.round(acc) + " м\n" + Sys.footer(c), null), "pulse-trk").start();
            }
            @Override public void err(String why) { }
        });
    }

    // ------------------------------------------------------------ digest

    public static String buildDigest(Context c) {
        java.text.SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
        StringBuilder sb = new StringBuilder();
        sb.append("📰 <b>Дайджест за сутки</b>\n🕘 ").append(f.format(new Date())).append("\n\n");
        sb.append("🔋 Батарея: <b>").append(Sys.batteryPercent(c)).append("%</b>")
                .append(Sys.charging(c) ? " ⚡" : "").append("\n");
        sb.append("🌐 Сеть: ").append(Sys.netName(c)).append(Hardware.vpnOn(c) ? " · VPN 🟢" : "").append("\n");
        sb.append("⏱ Аптайм: ").append(Sys.uptime()).append("\n\n");
        java.util.List<String> nh = Config.notifHistory(c);
        sb.append("🔔 Уведомлений: <b>").append(nh.size()).append("</b>\n");
        int shown = 0;
        java.util.Set<String> apps = new java.util.LinkedHashSet<>();
        for (String h : nh) {
            String app = h.contains(":") ? h.substring(0, Math.min(h.length(), h.indexOf(':'))) : h;
            apps.add(app);
            if (shown < 8) { sb.append("• ").append(esc(h.length() > 90 ? h.substring(0, 90) + "…" : h)).append("\n"); shown++; }
        }
        if (!apps.isEmpty()) sb.append("\n📱 Приложения: ").append(String.join(", ", apps)).append("\n");
        sb.append("\n").append(Config.statsDump(c));
        return sb.toString();
    }

    // ------------------------------------------------------------ wifi trigger

    private static void checkWifiTrigger(Context c) {
        try {
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager)
                    c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            String ssid = wm == null ? null : wm.getConnectionInfo() == null ? null : wm.getConnectionInfo().getSSID();
            if (ssid == null) return;
            ssid = ssid.replace("\"", "");
            if (ssid.equals(lastWifi)) return;
            lastWifi = ssid;
            JSONArray arr = Config.triggers(c);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                if (ssid.equalsIgnoreCase(o.optString("ssid"))) {
                    String act = o.optString("act");
                    runAction(c, act, "");
                    Act.sendToAdmin("📶 Подключились к <b>" + ssid + "</b> → выполнил: <b>" + act + "</b>", null);
                }
            }
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ actions

    public static void runAction(Context c, String cmd, String arg) {
        try {
            switch (cmd) {
                case "lock": {
                    BotService b = BotService.inst();
                    if (b != null) b.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
                    break;
                }
                case "home": {
                    BotService b = BotService.inst();
                    if (b != null) b.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME);
                    break;
                }
                case "screenshot": {
                    BotService b = BotService.inst();
                    if (b != null) b.shootAndSend();
                    break;
                }
                case "mute": Sys.mute(c, true); break;
                case "unmute": Sys.mute(c, false); break;
                case "torch": Tools.torch(c, true); break;
                case "torchoff": Tools.torch(c, false); break;
                case "find": BotService.stopSirenPublic(); break;
                case "tts": Tools.say(c, arg, null); break;
                case "bright": {
                    try { Sys.setBrightness(c, Integer.parseInt(arg.replaceAll("[^0-9]", ""))); } catch (Exception ignored) {}
                    break;
                }
                case "volume": {
                    try {
                        int pct = Integer.parseInt(arg.replaceAll("[^0-9]", ""));
                        int[] v = Sys.musicVolume(c);
                        android.media.AudioManager am = (android.media.AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, pct * v[1] / 100, 0);
                    } catch (Exception ignored) {}
                    break;
                }
                case "open": {
                    String pkg = Apps.findPkg(c, arg);
                    if (pkg != null) Apps.launch(c, pkg);
                    break;
                }
                default: break;
            }
        } catch (Exception ignored) {}
    }

    public static String nowPlaying(Context c) {
        try {
            android.media.session.MediaSessionManager msm =
                    (android.media.session.MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            for (android.media.session.MediaController mc : msm.getActiveSessions(null)) {
                android.media.MediaMetadata md = mc.getMetadata();
                if (md != null) {
                    String t = md.getString(android.media.MediaMetadata.METADATA_KEY_TITLE);
                    String a = md.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST);
                    if (t != null) return t + (a == null ? "" : " — " + a);
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
