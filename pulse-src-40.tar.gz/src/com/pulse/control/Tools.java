package com.pulse.control;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** High-level phone actions used by the bot: text input, vibration, siren, torch, TTS, charts. */
public final class Tools {

    private Tools() {}

    // ------------------------------------------------------------ text input

    public static void typeText(AccessibilityService svc, String fieldHint, String text, Cb cb) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                AccessibilityNodeInfo root = svc.getRootInActiveWindow();
                if (root == null) { cb.err("нет доступа к экрану"); return; }

                AccessibilityNodeInfo target = null;
                if (fieldHint != null && !fieldHint.isEmpty()) {
                    target = findField(root, fieldHint.toLowerCase(Locale.ROOT), 0);
                }
                if (target == null) {
                    AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                    if (focused != null && focused.isEditable()) target = focused;
                }
                if (target == null) target = firstEditable(root);

                if (target == null) {
                    cb.err("не нашёл поле ввода на экране");
                    return;
                }

                // focus it
                try {
                    AccessibilityNodeInfo p = target;
                    while (p != null && !p.isFocusable()) p = p.getParent();
                    if (p != null) p.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                    target.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                    target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                } catch (Exception ignored) {}

                final AccessibilityNodeInfo t = target;
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    boolean ok = false;
                    try {
                        android.os.Bundle args = new android.os.Bundle();
                        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
                        ok = t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
                    } catch (Exception ignored) {}
                    if (ok) cb.ok("текст введён");
                    else cb.err("поле не приняло текст");
                }, 250);
            } catch (Exception e) {
                cb.err(String.valueOf(e.getMessage()));
            }
        });
    }

    private static AccessibilityNodeInfo findField(AccessibilityNodeInfo root, String hint, int depth) {
        if (root == null || depth > 18) return null;
        try {
            if (root.isEditable()) {
                CharSequence h = root.getHintText();
                CharSequence txt = root.getText();
                CharSequence desc = root.getContentDescription();
                String all = (h == null ? "" : h.toString()) + " " + (txt == null ? "" : txt.toString())
                        + " " + (desc == null ? "" : desc.toString());
                if (all.toLowerCase(Locale.ROOT).contains(hint)) return root;
            }
            for (int i = 0; i < root.getChildCount(); i++) {
                AccessibilityNodeInfo n = findField(root.getChild(i), hint, depth + 1);
                if (n != null) return n;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo root) {
        if (root == null) return null;
        try {
            if (root.isEditable() && root.isVisibleToUser()) return root;
            for (int i = 0; i < root.getChildCount(); i++) {
                AccessibilityNodeInfo n = firstEditable(root.getChild(i));
                if (n != null) return n;
            }
        } catch (Exception ignored) {}
        return null;
    }

    public interface Cb { void ok(String msg); void err(String why); }

    public static void pressEnter(AccessibilityService svc) {
        try {
            AccessibilityNodeInfo root = svc.getRootInActiveWindow();
            if (root == null) return;
            AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (f != null) f.performAction(0x01000100); // ACTION_IME_ENTER (API 30+)
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ vibration

    private static final Handler VH = new Handler(Looper.getMainLooper());
    private static Runnable vStop;

    public static void vibrate(Context c, int seconds) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            stopVibrate();
            if (seconds <= 0) return;
            long[] pattern = new long[2 * seconds + 1];
            pattern[0] = 0;
            for (int i = 1; i < pattern.length; i++) pattern[i] = (i % 2 == 1) ? 550 : 350;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            } else {
                v.vibrate(pattern, -1);
            }
            vStop = v::cancel;
            VH.postDelayed(() -> { try { v.cancel(); } catch (Exception ignored) {} }, seconds * 1000L + 200);
        } catch (Exception ignored) {}
    }

    public static void stopVibrate() {
        try {
            Vibrator v = (Vibrator) Act.ctx().getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) v.cancel();
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ torch

    private static android.hardware.camera2.CameraManager camMan;
    private static boolean torchOn = false;

    public static boolean torch(Context c, boolean on) {
        try {
            if (camMan == null) {
                camMan = (android.hardware.camera2.CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            }
            String id = camMan.getCameraIdList()[0];
            camMan.setTorchMode(id, on);
            torchOn = on;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean torchState() { return torchOn; }

    // ------------------------------------------------------------ TTS

    private static TextToSpeech tts;

    public static void say(Context c, String text, String lang) {
        try {
            final String t = text;
            Locale loc = lang == null || lang.isEmpty() ? new Locale("ru", "RU") : Locale.forLanguageTag(lang);
            if (tts != null) { try { tts.shutdown(); } catch (Exception ignored) {} }
            tts = new TextToSpeech(c.getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    try {
                        if (tts.isLanguageAvailable(loc) >= 0) tts.setLanguage(loc);
                        else tts.setLanguage(Locale.ENGLISH);
                        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "pulse");
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    public static void ttsStop() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
    }

    /** Публичный HTML-escape для WebServer/ботов. */
    public static String e(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ------------------------------------------------------------ wake screen

    /** Wakes the display *without* unlocking (AlarmManager trick + WakeLock). */
    public static void wakeScreen(Context c) {
        try {
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) {
                android.os.PowerManager.WakeLock wl = pm.newWakeLock(
                        android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                                | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP
                                | android.os.PowerManager.ON_AFTER_RELEASE, "pulse:wake");
                wl.acquire(8000);
                wl.release();
            }
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                android.app.AlarmManager am = (android.app.AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                if (am.canScheduleExactAlarms()) {
                    android.content.Intent i = new android.content.Intent(c, WakeReceiver.class);
                    android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(c, 77, i,
                            android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
                    am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,
                            System.currentTimeMillis() + 200, pi);
                }
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationManager nm = (android.app.NotificationManager)
                        c.getSystemService(Context.NOTIFICATION_SERVICE);
                android.app.NotificationChannel ch = nm.getNotificationChannel("pulse_wake");
                if (ch == null) {
                    ch = new android.app.NotificationChannel("pulse_wake", "Пробуждение",
                            android.app.NotificationManager.IMPORTANCE_HIGH);
                    ch.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
                    nm.createNotificationChannel(ch);
                }
            }
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ wallpaper

    public static boolean setWallpaper(Context c, byte[] data) {
        try {
            java.io.File dir = new java.io.File(c.getFilesDir(), "wall");
            if (!dir.exists()) dir.mkdirs();
            java.io.File f = new java.io.File(dir, "wall.jpg");
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            out.write(data);
            out.close();
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(c);
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            wm.setStream(in);
            in.close();
            return true;
        } catch (Exception e) { return false; }
    }

    // ------------------------------------------------------------ screen keep awake

    private static android.os.PowerManager.WakeLock wake;

    public static boolean keepAwake(Context c, boolean on) {
        try {
            if (on) {
                android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
                wake = pm.newWakeLock(android.os.PowerManager.SCREEN_DIM_WAKE_LOCK | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP, "pulse:screen");
                wake.acquire(30 * 60 * 1000L);
            } else if (wake != null) {
                if (wake.isHeld()) wake.release();
                wake = null;
            }
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean lockOrientation(boolean on) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                android.provider.Settings.System.putInt(Act.ctx().getContentResolver(),
                        "accelerometer_rotation", on ? 0 : 1);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ------------------------------------------------------------ DND

    public static boolean dnd(Context c, boolean on) {
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager)
                    c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                if (!nm.isNotificationPolicyAccessGranted()) return false;
                nm.setInterruptionFilter(on
                        ? android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY
                        : android.app.NotificationManager.INTERRUPTION_FILTER_ALL);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    // ------------------------------------------------------------ battery chart

    public static byte[] batteryChart(Context c) {
        java.util.List<long[]> hist = Config.batteryHist(c);
        int W = 900, H = 320;
        Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.drawColor(Color.parseColor("#08110C"));

        Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        grid.setColor(Color.parseColor("#12331F"));
        grid.setStrokeWidth(2);
        for (int i = 0; i <= 4; i++) {
            float y = 30 + i * (H - 70) / 4f;
            cv.drawLine(50, y, W - 20, y, grid);
        }

        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setColor(Color.parseColor("#00E68A"));
        line.setStrokeWidth(7);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);

        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fill.setColor(Color.parseColor("#2200E68A"));
        fill.setStyle(Paint.Style.FILL);

        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setColor(Color.parseColor("#7FE7B7"));
        txt.setTextSize(26);

        if (hist.size() < 2) {
            txt.setTextSize(30);
            cv.drawText("Данных пока мало — включите бота и зайдите через час", 60, H / 2f, txt);
        } else {
            long t0 = hist.get(0)[0];
            long t1 = hist.get(hist.size() - 1)[0];
            Path path = new Path();
            Path area = new Path();
            float left = 50, right = W - 20, top = 30, bottom = H - 50;
            boolean first = true;
            for (long[] p : hist) {
                float x = left + (right - left) * (p[0] - t0) / Math.max(1, t1 - t0);
                float y = bottom - (bottom - top) * (p[1] / 100f);
                if (first) { path.moveTo(x, y); area.moveTo(x, bottom); area.lineTo(x, y); first = false; }
                else { path.lineTo(x, y); area.lineTo(x, y); }
            }
            area.lineTo(right, bottom);
            area.close();
            cv.drawPath(area, fill);
            cv.drawPath(path, line);

            cv.drawText("100%", 4, top + 8, txt);
            cv.drawText("0%", 20, bottom + 8, txt);
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", Locale.getDefault());
            cv.drawText(f.format(new java.util.Date(t0)), left, H - 12, txt);
            cv.drawText(f.format(new java.util.Date(t1)), right - 60, H - 12, txt);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 92, bo);
        return bo.toByteArray();
    }

    // ------------------------------------------------------------ app list cache

    private static List<Apps.Item> appCache;
    private static long appCacheAt;

    public static List<Apps.Item> appList(Context c) {
        if (appCache == null || System.currentTimeMillis() - appCacheAt > 5 * 60 * 1000) {
            appCache = Apps.list(c);
            appCacheAt = System.currentTimeMillis();
        }
        return new ArrayList<>(appCache);
    }
}
