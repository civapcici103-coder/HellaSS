package com.pulse.control;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

/** Tiny HTTP client: JSON POST + multipart upload. No external libraries. */
public final class Http {

    public static final class Resp {
        public final int code;
        public final String body;
        Resp(int code, String body) { this.code = code; this.body = body; }

        public boolean ok() {
            if (code != 200 || body == null) return false;
            try { return new JSONObject(body).optBoolean("ok", false); }
            catch (Exception e) { return false; }
        }

        public String description() {
            try { return new JSONObject(body).optString("description", "HTTP " + code); }
            catch (Exception e) { return "HTTP " + code; }
        }
    }

    private Http() {}

    public static Resp postJson(String url, JSONObject body, int readTimeoutMs) {
        try {
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            HttpURLConnection conn = open(url, readTimeoutMs);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setDoOutput(true);
            conn.setFixedLengthStreamingMode(data.length);
            try (OutputStream os = conn.getOutputStream()) { os.write(data); }
            return read(conn);
        } catch (Exception e) {
            return new Resp(-1, "{\"ok\":false,\"description\":\"" + esc(e.getClass().getSimpleName()) + "\"}");
        }
    }

    public static Resp postMultipart(String url, Map<String, String> fields,
                                     String fileField, String fileName, String mime,
                                     byte[] fileData, int readTimeoutMs) {
        String boundary = "----Pulse" + Long.toHexString(new Random().nextLong());
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(fileData.length + 4096);
            for (Map.Entry<String, String> e : fields.entrySet()) {
                bo.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
                bo.write(("Content-Disposition: form-data; name=\"" + e.getKey() + "\"\r\n\r\n")
                        .getBytes(StandardCharsets.UTF_8));
                bo.write(e.getValue().getBytes(StandardCharsets.UTF_8));
                bo.write("\r\n".getBytes(StandardCharsets.UTF_8));
            }
            bo.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(("Content-Disposition: form-data; name=\"" + fileField + "\"; filename=\"" + fileName + "\"\r\n")
                    .getBytes(StandardCharsets.UTF_8));
            bo.write(("Content-Type: " + mime + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(fileData);
            bo.write("\r\n".getBytes(StandardCharsets.UTF_8));
            bo.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

            byte[] data = bo.toByteArray();
            HttpURLConnection conn = open(url, readTimeoutMs);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setDoOutput(true);
            conn.setFixedLengthStreamingMode(data.length);
            try (OutputStream os = conn.getOutputStream()) { os.write(data); }
            return read(conn);
        } catch (Exception e) {
            return new Resp(-1, "{\"ok\":false,\"description\":\"" + esc(e.getClass().getSimpleName()) + "\"}");
        }
    }

    /** GET-загрузка файла (без POST). */
    public static byte[] download(String url, int readTimeoutMs) {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(readTimeoutMs);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            if (code >= 400) return null;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream is = conn.getInputStream()) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            }
            conn.disconnect();
            return bo.toByteArray();
        } catch (Exception e) { return null; }
    }

    /** GET последнего сообщения из ответа Telegram (для скачивания файла). */
    public static byte[] downloadTelegramFile(String token, String filePath, int readTimeoutMs) {
        return download("https://api.telegram.org/file/bot" + token + "/" + filePath, readTimeoutMs);
    }

    private static HttpURLConnection open(String url, int readTimeoutMs) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(readTimeoutMs);
        conn.setRequestMethod("POST");
        conn.setUseCaches(false);
        return conn;
    }

    private static Resp read(HttpURLConnection conn) {
        try {
            int code = conn.getResponseCode();
            InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String body = is == null ? "" : slurp(is);
            return new Resp(code, body);
        } catch (Exception e) {
            return new Resp(-1, "{\"ok\":false,\"description\":\"" + esc(e.getClass().getSimpleName()) + "\"}");
        } finally {
            conn.disconnect();
        }
    }

    private static String slurp(InputStream is) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return bo.toString("UTF-8");
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("\"", "'");
    }

    public static Map<String, String> fields() { return new LinkedHashMap<>(); }
}
