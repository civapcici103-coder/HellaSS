package com.pulse.control;

import org.json.JSONArray;
import org.json.JSONObject;

/** Telegram Bot API wrapper + tiny JSON keyboard builders. */
public final class TgApi {

    private final String token;
    private final String base;

    public TgApi(String token) {
        this.token = token;
        this.base = "https://api.telegram.org/bot" + token + "/";
    }

    // ------------------------------------------------------------------ API

    public Http.Resp getMe() { return Http.postJson(base + "getMe", obj(), 15000); }

    public Http.Resp getUpdates(long offset, int timeoutSec) {
        JSONObject b = obj();
        try {
            if (offset > 0) b.put("offset", offset);
            b.put("timeout", timeoutSec);
            b.put("limit", 20);
            b.put("allowed_updates", new JSONArray().put("message").put("callback_query"));
        } catch (Exception ignored) {}
        return Http.postJson(base + "getUpdates", b, (timeoutSec + 12) * 1000);
    }

    public Http.Resp sendMessage(long chat, String html, JSONObject kb) {
        JSONObject b = obj();
        try {
            b.put("chat_id", chat);
            b.put("text", html);
            b.put("parse_mode", "HTML");
            b.put("disable_web_page_preview", true);
            if (kb != null) b.put("reply_markup", kb);
        } catch (Exception ignored) {}
        return Http.postJson(base + "sendMessage", b, 25000);
    }

    public Http.Resp sendPhoto(long chat, byte[] jpeg, String caption, JSONObject kb) {
        java.util.Map<String, String> f = Http.fields();
        f.put("chat_id", String.valueOf(chat));
        f.put("caption", caption);
        f.put("parse_mode", "HTML");
        if (kb != null) f.put("reply_markup", kb.toString());
        return Http.postMultipart(base + "sendPhoto", f, "photo", "photo.jpg", "image/jpeg", jpeg, 90000);
    }

    public Http.Resp sendDocument(long chat, byte[] data, String filename, String caption, JSONObject kb) {
        java.util.Map<String, String> f = Http.fields();
        f.put("chat_id", String.valueOf(chat));
        f.put("caption", caption);
        f.put("parse_mode", "HTML");
        if (kb != null) f.put("reply_markup", kb.toString());
        return Http.postMultipart(base + "sendDocument", f, "document", filename,
                "application/octet-stream", data, 180000);
    }

    public Http.Resp sendVideo(long chat, byte[] data, String filename, String caption, JSONObject kb) {
        java.util.Map<String, String> f = Http.fields();
        f.put("chat_id", String.valueOf(chat));
        f.put("caption", caption);
        f.put("parse_mode", "HTML");
        f.put("supports_streaming", "true");
        if (kb != null) f.put("reply_markup", kb.toString());
        return Http.postMultipart(base + "sendVideo", f, "video", filename, "video/mp4", data, 300000);
    }

    public Http.Resp sendAudio(long chat, byte[] data, String filename, String caption, JSONObject kb) {
        java.util.Map<String, String> f = Http.fields();
        f.put("chat_id", String.valueOf(chat));
        f.put("caption", caption);
        f.put("parse_mode", "HTML");
        if (kb != null) f.put("reply_markup", kb.toString());
        return Http.postMultipart(base + "sendAudio", f, "audio", filename, "audio/mp4", data, 180000);
    }

    public Http.Resp editText(long chat, long mid, String html, JSONObject kb) {
        JSONObject b = obj();
        try {
            b.put("chat_id", chat);
            b.put("message_id", mid);
            b.put("text", html);
            b.put("parse_mode", "HTML");
            b.put("disable_web_page_preview", true);
            if (kb != null) b.put("reply_markup", kb);
        } catch (Exception ignored) {}
        return Http.postJson(base + "editMessageText", b, 25000);
    }

    public Http.Resp editCaption(long chat, long mid, String caption, JSONObject kb) {
        JSONObject b = obj();
        try {
            b.put("chat_id", chat);
            b.put("message_id", mid);
            b.put("caption", caption);
            b.put("parse_mode", "HTML");
            if (kb != null) b.put("reply_markup", kb);
        } catch (Exception ignored) {}
        return Http.postJson(base + "editMessageCaption", b, 25000);
    }

    public Http.Resp delete(long chat, long mid) {
        JSONObject b = obj();
        try {
            b.put("chat_id", chat);
            b.put("message_id", mid);
        } catch (Exception ignored) {}
        return Http.postJson(base + "deleteMessage", b, 15000);
    }

    /** Кнопка «Пульт» рядом с полем ввода → открывает WebApp. */
    public Http.Resp setMenuButton(String url, String text) {
        JSONObject b = obj();
        try {
            JSONObject wa = new JSONObject();
            wa.put("url", url);
            JSONObject mb = new JSONObject();
            mb.put("type", "web_app");
            mb.put("text", text);
            mb.put("web_app", wa);
            b.put("menu_button", mb);
        } catch (Exception ignored) {}
        return Http.postJson(base + "setChatMenuButton", b, 20000);
    }

    /** Кнопка, открывающая WebApp прямо в сообщении. */
    public Http.Resp sendWebApp(long chat, String html, String url, String btnText) {
        JSONObject kb = obj();
        try {
            JSONObject wa = new JSONObject();
            wa.put("url", url);
            JSONObject btnObj = new JSONObject();
            btnObj.put("text", btnText);
            btnObj.put("web_app", wa);
            JSONArray rows = new JSONArray();
            rows.put(new JSONArray().put(btnObj));
            kb.put("inline_keyboard", rows);
        } catch (Exception ignored) {}
        return sendMessage(chat, html, kb);
    }

    public Http.Resp getFile(String fileId) {
        JSONObject b = obj();
        try { b.put("file_id", fileId); } catch (Exception ignored) {}
        return Http.postJson(base + "getFile", b, 20000);
    }

    public Http.Resp answer(String cbId, String text) {
        JSONObject b = obj();
        try {
            b.put("callback_query_id", cbId);
            if (text != null) b.put("text", text);
        } catch (Exception ignored) {}
        return Http.postJson(base + "answerCallbackQuery", b, 15000);
    }

    // ------------------------------------------------------------- builders

    public static JSONObject obj() { return new JSONObject(); }

    public static JSONObject btn(String text, String data) {
        JSONObject b = new JSONObject();
        try { b.put("text", text).put("callback_data", data); } catch (Exception ignored) {}
        return b;
    }

    public static JSONArray row(JSONObject... buttons) {
        JSONArray r = new JSONArray();
        for (JSONObject b : buttons) r.put(b);
        return r;
    }

    public static JSONObject kb(JSONArray... rows) {
        JSONArray all = new JSONArray();
        for (JSONArray r : rows) all.put(r);
        JSONObject kb = new JSONObject();
        try { kb.put("inline_keyboard", all); } catch (Exception ignored) {}
        return kb;
    }
}
