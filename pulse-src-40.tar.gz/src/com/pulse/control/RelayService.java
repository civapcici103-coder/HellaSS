package com.pulse.control;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Постоянная foreground-служба для удалённого управления.
 *
 * Зачем отдельно от BotService:
 *  - BotService — это служба доступности, её Android может приостановить
 *    вместе с процессом при выключенном экране.
 *  - Здесь — обычная foreground-служба с постоянным уведомлением и WakeLock,
 *    которую система не убивает: телефон дома, экран погас, а команды из гостей
 *    всё равно доходят и выполняются.
 *
 * Держит:
 *   - SSE-стрим релея (мгновенная доставка команд)
 *   - короткий частичный WakeLock на время выполнения команды
 *   - Wi-Fi lock, чтобы не отваливаться в сон
 */
public class RelayService extends Service {

    public static final String CHANNEL = "pulse_relay";
    public static final int NID = 303;
    public static final String A_STOP = "stop";
    public static final String A_RESTART = "restart";

    private static volatile boolean alive = false;
    private android.net.wifi.WifiManager.WifiLock wifiLock;

    public static boolean isAlive() { return alive; }

    /**
     * Запуск службы. ВАЖНО: молча глотать ошибку нельзя — если система
     * не дала поднять foreground-службу (Huawei/EMUI, ограничения батареи,
     * запрет автозапуска), то релей просто не работает, а снаружи это
     * выглядит как «статус есть, команды не выполняются».
     */
    public static boolean start(Context c) {
        Intent i = new Intent(c, RelayService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
            LogStore.add("📡 RelayService: старт принят");
            return true;
        } catch (Exception e) {
            // отказ системы: записываем причину и пробуем обычный startService
            LogStore.add("📡 RelayService отказ FGS: " + e.getClass().getSimpleName()
                    + ": " + e.getMessage());
            try {
                c.startService(i);
                LogStore.add("📡 RelayService: поднят обычным startService");
                return true;
            } catch (Exception e2) {
                LogStore.add("📡 RelayService не поднялся: " + e2.getMessage());
                return false;
            }
        }
    }

    /** Почему служба может не работать — понятным языком. */
    public static String why(Context c) {
        StringBuilder b = new StringBuilder();
        if (isAlive()) return "работает";
        try {
            android.os.PowerManager pm = (android.os.PowerManager)
                    c.getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(c.getPackageName()))
                b.append("ограничение батареи включено; ");
        } catch (Exception ignored) {}
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager)
                    c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled())
                b.append("уведомления запрещены (foreground-служба без них не работает); ");
        } catch (Exception ignored) {}
        if (b.length() == 0) b.append("не запущена — нажми /relay_restart");
        return b.toString();
    }

    public static void stop(Context c) {
        try {
            Intent i = new Intent(c, RelayService.class).putExtra(A_STOP, true);
            c.startService(i);
        } catch (Exception ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();
        alive = true;
        createChannel();
        startForeground(NID, build());
        try {
            Relay.start(this);
            PhoneWatcher.start(this);
        } catch (Exception ignored) {}
        acquireWifi();
        LogStore.add("📡 Служба релея запущена");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getBooleanExtra(A_STOP, false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        // поднимаем релей, если почему-то упал
        try {
            if (!Relay.isRunning()) Relay.start(this);
        } catch (Exception e) {
            LogStore.add("📡 Релей не стартовал в службе: " + e.getMessage());
        }
        // и планируем проверку через минуту: если поток умер — поднимем заново
        try {
            android.app.AlarmManager am = (android.app.AlarmManager)
                    getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(this, RelayService.class);
            android.app.PendingIntent pi = android.app.PendingIntent.getService(this, 7, i,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT
                            | android.app.PendingIntent.FLAG_IMMUTABLE);
            if (am != null) am.set(android.app.AlarmManager.RTC, System.currentTimeMillis() + 60000, pi);
        } catch (Exception ignored) {}
        return START_STICKY;   // система перезапустит после убийства
    }

    @Override
    public void onDestroy() {
        alive = false;
        try { Relay.stop(); } catch (Exception ignored) {}
        releaseWifi();
        LogStore.add("📡 Служба релея остановлена");
        // если нас убили не по команде — пробуем вернуться
        if (Relay.enabled(this) && !Eco.on(this)) {
            try {
                android.app.AlarmManager am = (android.app.AlarmManager)
                        getSystemService(Context.ALARM_SERVICE);
                Intent i = new Intent(this, RelayService.class);
                android.app.PendingIntent pi = android.app.PendingIntent.getService(this, 9, i,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT
                                | android.app.PendingIntent.FLAG_IMMUTABLE);
                am.set(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5000, pi);
            } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    // ------------------------------------------------------------ wifi lock

    private void acquireWifi() {
        try {
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager)
                    getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiLock = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                        "pulse:wifi");
                wifiLock.setReferenceCounted(false);
                wifiLock.acquire();
            }
        } catch (Exception ignored) {}
    }

    private void releaseWifi() {
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) {}
        wifiLock = null;
    }

    // ------------------------------------------------------------ notification

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            android.app.NotificationChannel ch = new android.app.NotificationChannel(CHANNEL,
                    "Pulse Control", android.app.NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Удалённое управление");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    private android.app.Notification build() {
        Intent open = new Intent(this, MainActivity.class);
        android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 0, open,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
                        | android.app.PendingIntent.FLAG_IMMUTABLE);

        String title = "Pulse Control";
        String sub = "Удалённое управление готово · " + Relay.channel(this);

        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new android.app.Notification.Builder(this, CHANNEL)
                : new android.app.Notification.Builder(this);
        b.setContentTitle(title)
                .setContentText(sub)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true);
        if (Build.VERSION.SDK_INT >= 21) b.setColor(0xFF00E68A);
        return b.build();
    }

    /** Обновить текст уведомления (например, «выполняю: torch»). */
    public static void refresh(Context c, String status) {
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager)
                    c.getSystemService(Context.NOTIFICATION_SERVICE);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(c, CHANNEL)
                    : new android.app.Notification.Builder(c);
            b.setContentTitle("Pulse Control")
                    .setContentText(status)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setOngoing(true)
                    .setShowWhen(false)
                    .setOnlyAlertOnce(true);
            if (Build.VERSION.SDK_INT >= 21) b.setColor(0xFF00E68A);
            nm.notify(NID, b.build());
        } catch (Exception ignored) {}
    }
}
