package com.pulse.control;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * Small foreground service: keeps the process (and therefore the accessibility
 * service + bot loop) alive in the background and shows a live status card.
 */
public class StatusService extends Service {

    public static final String CHANNEL = "pulse_status";
    public static final int NOTIF_ID = 101;
    public static final String EXTRA_STOP = "stop";

    private final Handler h = new Handler(Looper.getMainLooper());
    private long lastRefresh = 0;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            // Уведомление обновляем раз в минуту — раньше было каждые 10 сек (лишняя нагрузка)
            if (System.currentTimeMillis() - lastRefresh > 60000) {
                lastRefresh = System.currentTimeMillis();
                refresh();
            }
            tickRelay();
            h.postDelayed(this, 30000);
        }
    };

    private static volatile boolean alive = false;

    public static boolean isRunning() { return alive; }

    public static void start(Context c) {
        Intent i = new Intent(c, StatusService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    public static void stop(Context c) {
        c.stopService(new Intent(c, StatusService.class));
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIF_ID, build());
        alive = true;
        h.post(tick);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getBooleanExtra(EXTRA_STOP, false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        refresh();
        tickRelay();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        alive = false;
        h.removeCallbacks(tick);
        super.onDestroy();
    }

    private void refresh() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, build());
        } catch (Exception ignored) {}
    }

    private long lastBeat = 0;

    private void tickRelay() {
        try {
            if (System.currentTimeMillis() - lastBeat > 90000L) {
                lastBeat = System.currentTimeMillis();
                if (Relay.enabled(this) && !RelayService.isAlive()) {
                    Relay.heartbeat(this);
                    // РЕЗЕРВ: службы релея нет, но этого сервиса система не убивает.
                    // Поднимаем слушатель здесь — иначе статус уходит, а команды нет.
                    if (!Relay.isRunning()) {
                        Relay.start(this);
                        LogStore.add("📡 Резерв: слушатель поднят в StatusService");
                    }
                    // и пробуем вернуть саму службу
                    RelayService.start(this);
                }
            }
        } catch (Exception ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            boolean quiet = Config.quiet(this);
            NotificationChannel ch = new NotificationChannel(CHANNEL,
                    quiet ? "Сервисы системы" : "Pulse Control",
                    quiet ? NotificationManager.IMPORTANCE_MIN : NotificationManager.IMPORTANCE_LOW);
            ch.setDescription(quiet ? "Системная служба" : "Статус пульта");
            ch.setShowBadge(!quiet);
            if (quiet) ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    private Notification build() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        boolean quiet = Config.quiet(this);
        boolean up = BotService.isUp();
        boolean svc = BotService.isServiceOn();
        String title, sub;
        if (quiet) {
            title = "Сервисы системы";
            sub = "Синхронизация активна";
        } else {
            title = up ? "Pulse Control работает" : (svc ? "Pulse Control: запуск…" : "Pulse Control");
            sub = up
                    ? "@" + BotService.username() + " · 🔋 " + Sys.batteryPercent(this) + "% · " + Sys.netName(this)
                    : (svc ? "Бот подключается…" : "Включите службу доступа в приложении");
        }

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setContentTitle(title)
                .setContentText(sub)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true);
        if (Build.VERSION.SDK_INT >= 21) b.setColor(0xFF2AABEE);
        return b.build();
    }
}
