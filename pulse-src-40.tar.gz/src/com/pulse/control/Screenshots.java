package com.pulse.control;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;

import java.io.ByteArrayOutputStream;

/**
 * Screenshot capture through AccessibilityService.takeScreenshot (Android 11+).
 * Isolated in its own class so older devices never load API 30 symbols.
 */
public final class Screenshots {

    public interface Callback {
        void onShot(byte[] jpeg);
        void onError(String reason);
    }

    private static final int MAX_SIDE = 2560;

    private Screenshots() {}

    public static void capture(AccessibilityService svc, Callback cb) {
        if (Build.VERSION.SDK_INT < 30) {
            cb.onError("нужен Android 11 или новее");
            return;
        }
        new Handler(Looper.getMainLooper()).post(() -> Api30.take(svc, cb));
    }

    static String failText(int code) {
        switch (code) {
            case 1: return "снимок запрещён (защищённый экран)";
            case 2: return "снимок пока недоступен, попробуйте ещё раз";
            case 3: return "таймаут снимка";
            case 4: return "внутренняя ошибка";
            default: return "ошибка " + code;
        }
    }

    private static final class Api30 {
        static void take(AccessibilityService svc, Callback cb) {
            try {
                svc.takeScreenshot(Display.DEFAULT_DISPLAY,
                        svc.getMainExecutor(),
                        new AccessibilityService.TakeScreenshotCallback() {
                            @Override public void onSuccess(AccessibilityService.ScreenshotResult result) {
                                try {
                                    HardwareBuffer buf = result.getHardwareBuffer();
                                    Bitmap raw = Bitmap.wrapHardwareBuffer(buf, result.getColorSpace());
                                    Bitmap soft = raw == null ? null : raw.copy(Bitmap.Config.ARGB_8888, false);
                                    try { buf.close(); } catch (Exception ignored) {}
                                    if (soft == null) { cb.onError("не удалось прочитать кадр"); return; }
                                    int w = soft.getWidth(), h = soft.getHeight();
                                    float k = Math.min(1f, MAX_SIDE / (float) Math.max(w, h));
                                    if (k < 1f) soft = Bitmap.createScaledBitmap(soft,
                                            Math.round(w * k), Math.round(h * k), true);
                                    ByteArrayOutputStream bo = new ByteArrayOutputStream(1 << 20);
                                    soft.compress(Bitmap.CompressFormat.JPEG, 90, bo);
                                    cb.onShot(bo.toByteArray());
                                } catch (Throwable t) {
                                    cb.onError("сбой обработки: " + t.getMessage());
                                }
                            }

                            @Override public void onFailure(int errorCode) {
                                cb.onError(failText(errorCode));
                            }
                        });
            } catch (Throwable t) {
                cb.onError("takeScreenshot: " + t.getMessage());
            }
        }
    }
}
