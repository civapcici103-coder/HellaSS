package com.pulse.control;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;

/** Простое окно ввода, показываемое на самом телефоне (для команд из WebApp). */
public final class ModalText {

    public interface Done { void run(String text); }

    private ModalText() {}

    public static void show(Context c, String title, String prefill, String okText, Done done, Runnable cancel) {
        try {
            EditText et = new EditText(c);
            et.setHint(title);
            et.setText(prefill == null ? "" : prefill);
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            et.setSelectAllOnFocus(true);

            LinearLayout box = new LinearLayout(c);
            int p = (int) (18 * c.getResources().getDisplayMetrics().density);
            box.setPadding(p, p / 2, p, 0);
            box.addView(et, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            new AlertDialog.Builder(c)
                    .setTitle(title)
                    .setView(box)
                    .setPositiveButton(okText, (d, w) -> {
                        String t = et.getText().toString().trim();
                        if (!t.isEmpty()) done.run(t);
                    })
                    .setNegativeButton("Отмена", (d, w) -> { if (cancel != null) cancel.run(); })
                    .show();
        } catch (Exception e) {
            Act.sendToAdmin("⚠️ Окно ввода: " + e.getMessage(), null);
        }
    }
}
