package com.pulse.control;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

/** Touch gestures: D-pad remote, tap-by-text, grid taps, scrolling. */
public final class Gestures {

    public interface Cb { void ok(); void err(String why); }

    private Gestures() {}

    // ------------------------------------------------------------ helpers

    public static int[] screenSize(android.content.Context c) {
        try {
            WindowManager wm = (WindowManager) c.getSystemService(android.content.Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            return new int[]{dm.widthPixels, dm.heightPixels};
        } catch (Exception e) { return new int[]{1080, 1920}; }
    }

    public static void tap(AccessibilityService svc, float x, float y, Cb cb) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 60))
                .build();
        dispatch(svc, g, cb);
    }

    public static void swipe(AccessibilityService svc, float x1, float y1, float x2, float y2, long ms, Cb cb) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(60, ms)))
                .build();
        dispatch(svc, g, cb);
    }

    private static void dispatch(AccessibilityService svc, GestureDescription g, Cb cb) {
        try {
            boolean ok = svc.dispatchGesture(g, new AccessibilityService.GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { if (cb != null) cb.ok(); }
                @Override public void onCancelled(GestureDescription d) { if (cb != null) cb.err("жест отменён"); }
            }, new Handler(Looper.getMainLooper()));
            if (!ok && cb != null) cb.err("не удалось выполнить жест");
        } catch (Exception e) {
            if (cb != null) cb.err(String.valueOf(e.getMessage()));
        }
    }

    // ------------------------------------------------------------ D-pad

    /** dir: up, down, left, right, ok, back */
    public static void dpad(AccessibilityService svc, String dir, Cb cb) {
        int[] s = screenSize(svc);
        float cx = s[0] / 2f, cy = s[1] / 2f;
        switch (dir) {
            case "up": swipe(svc, cx, cy + 250, cx, cy - 250, 220, cb); break;
            case "down": swipe(svc, cx, cy - 250, cx, cy + 250, 220, cb); break;
            case "left": swipe(svc, cx + 300, cy, cx - 300, cy, 220, cb); break;
            case "right": swipe(svc, cx - 300, cy, cx + 300, cy, 220, cb); break;
            case "ok": tap(svc, cx, cy, cb); break;
            case "back": svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); if (cb != null) cb.ok(); break;
            default: if (cb != null) cb.err("неизвестное направление");
        }
    }

    public static void scroll(AccessibilityService svc, boolean down, Cb cb) {
        int[] s = screenSize(svc);
        float cx = s[0] / 2f;
        if (down) swipe(svc, cx, s[1] * 0.75f, cx, s[1] * 0.25f, 400, cb);
        else swipe(svc, cx, s[1] * 0.25f, cx, s[1] * 0.75f, 400, cb);
    }

    // ------------------------------------------------------------ tap by text

    public static boolean tapByText(AccessibilityService svc, String query, Cb cb) {
        try {
            android.view.accessibility.AccessibilityNodeInfo root = svc.getRootInActiveWindow();
            if (root == null) { if (cb != null) cb.err("нет доступа к экрану"); return false; }
            List<android.view.accessibility.AccessibilityNodeInfo> found = new ArrayList<>();
            collect(root, query.toLowerCase(java.util.Locale.ROOT), found, 0);
            if (found.isEmpty()) { if (cb != null) cb.err("текст «" + query + "» не найден"); return false; }
            android.view.accessibility.AccessibilityNodeInfo target = found.get(0);
            // prefer clickable parent
            android.view.accessibility.AccessibilityNodeInfo click = target;
            for (int i = 0; i < 4 && click != null; i++) {
                if (click.isClickable()) break;
                click = click.getParent();
            }
            if (click != null && click.isClickable() && click.performAction(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)) {
                if (cb != null) cb.ok();
                return true;
            }
            // fallback: tap centre of bounds
            Rect r = new Rect();
            target.getBoundsInScreen(r);
            if (r.width() > 0 && r.height() > 0) {
                tap(svc, r.centerX(), r.centerY(), cb);
                return true;
            }
            if (cb != null) cb.err("элемент не нажимается");
            return false;
        } catch (Exception e) {
            if (cb != null) cb.err(String.valueOf(e.getMessage()));
            return false;
        }
    }

    private static void collect(android.view.accessibility.AccessibilityNodeInfo n, String q,
                                List<android.view.accessibility.AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 20 || out.size() > 40) return;
        try {
            CharSequence txt = n.getText();
            CharSequence desc = n.getContentDescription();
            String all = (txt == null ? "" : txt.toString()) + " " + (desc == null ? "" : desc.toString());
            if (n.isVisibleToUser() && all.toLowerCase(java.util.Locale.ROOT).contains(q)) out.add(n);
            for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), q, out, depth + 1);
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------ grid tap

    /** cell like "A1".."C3" on a 3x3 grid. */
    /** Мультитап: несколько быстрых нажатий подряд. */
    public static void multiTap(final AccessibilityService svc, final float x, final float y,
                                final int times, final Cb cb) {
        new Thread(() -> {
            try {
                for (int i = 0; i < Math.max(1, Math.min(times, 5)); i++) {
                    final int idx = i;
                    svc.getMainExecutor().execute(() -> {
                        android.accessibilityservice.GestureDescription.Builder b =
                                new android.accessibilityservice.GestureDescription.Builder();
                        b.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(
                                android.graphics.Path.class.cast(path(x, y)), 0, 50));
                        svc.dispatchGesture(b.build(), null, null);
                    });
                    Thread.sleep(120);
                }
            } catch (Exception ignored) { }
            if (cb != null) cb.ok();
        }, "pulse-multitap").start();
    }

    /** Долгое нажатие в точке. */
    public static void longPress(AccessibilityService svc, float x, float y, long ms, Cb cb) {
        android.accessibilityservice.GestureDescription.Builder b =
                new android.accessibilityservice.GestureDescription.Builder();
        b.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(path(x, y), 0, Math.max(600, ms)));
        dispatch(svc, b.build(), cb);
    }

    /** Пинч двумя пальцами (зум). */
    public static void pinch(final AccessibilityService svc, final float cx, final float cy,
                             final boolean zoomIn, final Cb cb) {
        final float start = 120f, end = zoomIn ? 420f : 40f;
        android.accessibilityservice.GestureDescription.Builder b =
                new android.accessibilityservice.GestureDescription.Builder();
        android.graphics.Path p1 = new android.graphics.Path();
        p1.moveTo(cx - start / 2, cy);
        p1.lineTo(cx - end / 2, cy);
        android.graphics.Path p2 = new android.graphics.Path();
        p2.moveTo(cx + start / 2, cy);
        p2.lineTo(cx + end / 2, cy);
        b.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(p1, 0, 400));
        b.addStroke(new android.accessibilityservice.GestureDescription.StrokeDescription(p2, 0, 400));
        dispatch(svc, b.build(), cb);
    }

    /** Тап по центру ячейки сетки N×N (N = 3 или 5). */
    public static boolean tapCellN(AccessibilityService svc, String cell, int n, Cb cb) {
        try {
            String c = cell.trim().toUpperCase(java.util.Locale.ROOT);
            if (c.length() < 2) return false;
            int col = c.charAt(0) - 'A';
            int row = Integer.parseInt(c.substring(1)) - 1;
            if (col < 0 || col >= n || row < 0 || row >= n) return false;
            int[] sz = screenSize(svc);
            float x = sz[0] * (col + 0.5f) / n;
            float y = sz[1] * (row + 0.5f) / n;
            tap(svc, x, y, cb);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Тап по элементу с указанным view-id (например com.app:id/button). */
    public static boolean tapById(AccessibilityService svc, String viewId, Cb cb) {
        try {
            android.view.accessibility.AccessibilityNodeInfo root = svc.getRootInActiveWindow();
            if (root == null) return false;
            java.util.List<android.view.accessibility.AccessibilityNodeInfo> list =
                    root.findAccessibilityNodeInfosByViewId(viewId);
            if (list == null || list.isEmpty()) {
                // пробуем найти по частичному совпадению через обход
                list = new java.util.ArrayList<>();
                collectById(root, viewId, list, 0);
            }
            if (list.isEmpty()) return false;
            android.view.accessibility.AccessibilityNodeInfo n = list.get(0);
            android.graphics.Rect r = new android.graphics.Rect();
            n.getBoundsInScreen(r);
            tap(svc, r.centerX(), r.centerY(), cb);
            return true;
        } catch (Exception e) { return false; }
    }

    private static void collectById(android.view.accessibility.AccessibilityNodeInfo n, String id,
                                    java.util.List<android.view.accessibility.AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 12 || out.size() > 3) return;
        CharSequence vid = n.getViewIdResourceName();
        if (vid != null && vid.toString().toLowerCase(java.util.Locale.ROOT)
                .contains(id.toLowerCase(java.util.Locale.ROOT))) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collectById(n.getChild(i), id, out, depth + 1);
    }

    private static android.graphics.Path path(float x, float y) {
        android.graphics.Path p = new android.graphics.Path();
        p.moveTo(x, y);
        p.lineTo(x + 1, y);
        return p;
    }

    public static boolean tapCell(AccessibilityService svc, String cell, Cb cb) {
        try {
            if (cell == null || cell.length() < 2) { if (cb != null) cb.err("плохая ячейка"); return false; }
            char col = Character.toUpperCase(cell.charAt(0));
            int row = Integer.parseInt(cell.substring(1)) - 1;
            int ci = col - 'A';
            if (ci < 0 || ci > 2 || row < 0 || row > 2) { if (cb != null) cb.err("ячейка вне сетки"); return false; }
            int[] s = screenSize(svc);
            float x = s[0] * (ci * 2 + 1) / 6f;
            float y = s[1] * (row * 2 + 1) / 6f;
            tap(svc, x, y, cb);
            return true;
        } catch (Exception e) {
            if (cb != null) cb.err(String.valueOf(e.getMessage()));
            return false;
        }
    }
}
