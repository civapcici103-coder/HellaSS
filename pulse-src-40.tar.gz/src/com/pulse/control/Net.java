package com.pulse.control;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Живучесть связи.
 *
 *  1) Проверяет доступность Telegram API (VPN/блокировка/подписка).
 *  2) Если Telegram лежит — команды идут через релей ntfy, а не теряются.
 *  3) Копит неотправленное в оффлайн-очередь и досылает, когда сеть вернулась.
 *  4) Знает про резервные каналы и умеет ими пользоваться.
 */
public final class Net {

    private static final String KEY_QUEUE = "offline_queue";
    private static final String KEY_LAST_OK = "tg_last_ok";
    private static final String KEY_TG_UP = "tg_up";

    private Net() {}

    // ------------------------------------------------------------ состояние Telegram

    public static boolean tgUp(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getBoolean(KEY_TG_UP, true);
    }

    public static long lastOk(Context c) {
        return c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getLong(KEY_LAST_OK, 0);
    }

    private static void setTg(Context c, boolean up) {
        android.content.SharedPreferences.Editor e =
                c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit();
        e.putBoolean(KEY_TG_UP, up);
        if (up) e.putLong(KEY_LAST_OK, System.currentTimeMillis());
        e.apply();
    }

    /**
     * Проверяет Telegram и переключает режим.
     * @return true — Telegram доступен.
     */
    public static boolean probe(Context c) {
        boolean up = false;
        try {
            Http.Resp r = new TgApi(Config.get(c).token).getMe();
            up = r != null && r.ok();
        } catch (Exception ignored) {}
        boolean was = tgUp(c);
        setTg(c, up);
        if (was != up) {
            LogStore.add(up ? "✅ Telegram снова доступен" : "⚠️ Telegram недоступен → режим релея");
            if (!up) RelayService.start(c);
        }
        if (!up) flush(c);
        return up;
    }

    // ------------------------------------------------------------ оффлайн-очередь

    /** Кладёт действие в очередь на досылку. */
    public static void queue(Context c, String cmd) {
        try {
            JSONArray q = queueOf(c);
            JSONObject o = new JSONObject();
            o.put("cmd", cmd);
            o.put("ts", System.currentTimeMillis());
            q.put(o);
            save(c, q);
            LogStore.add("📥 В очередь: " + cmd);
        } catch (Exception ignored) {}
    }

    public static JSONArray queueOf(Context c) {
        try {
            String s = c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getString(KEY_QUEUE, "[]");
            return new JSONArray(s);
        } catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray q) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE)
                .edit().putString(KEY_QUEUE, q.toString()).apply();
    }

    public static int queueSize(Context c) { return queueOf(c).length(); }

    public static void clearQueue(Context c) { save(c, new JSONArray()); }

    /** Досылает накопленное, когда сеть вернулась. */
    public static void flush(Context c) {
        JSONArray q = queueOf(c);
        if (q.length() == 0) return;
        List<Integer> done = new ArrayList<>();
        for (int i = 0; i < q.length(); i++) {
            JSONObject o = q.optJSONObject(i);
            if (o == null) { done.add(i); continue; }
            try {
                String cmd = o.optString("cmd");
                String err = WebServer.runCommand(c, cmd);
                Relay.publish(c, "ack", err == null ? "✓ " + cmd + " (из очереди)" : "✕ " + cmd);
                done.add(i);
            } catch (Exception ignored) { break; }
        }
        if (!done.isEmpty()) {
            JSONArray rest = new JSONArray();
            for (int i = 0; i < q.length(); i++)
                if (!done.contains(i)) rest.put(q.optJSONObject(i));
            save(c, rest);
            LogStore.add("📤 Дослано из очереди: " + done.size());
        }
    }

    // ------------------------------------------------------------ выбор канала

    /**
     * Умная отправка: если Telegram доступен — идём туда,
     * иначе публикуем в релей и ставим в очередь.
     */
    public static void send(Context c, String cmd) {
        if (tgUp(c)) {
            try {
                String err = WebServer.runCommand(c, cmd);
                if (err != null) Relay.publish(c, "ack", "✕ " + cmd + ": " + err);
                return;
            } catch (Exception ignored) {}
        }
        // Telegram недоступен — релей + очередь
        Relay.sendCommand(c, cmd);
        Relay.publish(c, "ack", "⏳ в очереди: " + cmd);
    }

    // ------------------------------------------------------------ резервные каналы

    /** Список всех каналов связи с состоянием. */
    public static String channelsReport(Context c) {
        StringBuilder sb = new StringBuilder("📡 <b>Каналы связи</b>\n\n");

        boolean tg = tgUp(c);
        long last = lastOk(c);
        sb.append(tg ? "✅" : "❌").append(" <b>Telegram</b>");
        if (last > 0) {
            long ago = (System.currentTimeMillis() - last) / 1000;
            sb.append(" · ").append(ago < 60 ? "только что"
                    : ago < 3600 ? (ago / 60) + " мин назад"
                    : (ago / 3600) + " ч назад");
        }
        sb.append("\n");

        boolean relay = Relay.enabled(c);
        sb.append(relay ? "✅" : "⛔").append(" <b>Релей ntfy</b> · <code>")
                .append(Relay.channel(c)).append("</code>\n");

        int q = queueSize(c);
        sb.append(q > 0 ? "⏳" : "✅").append(" <b>Очередь</b>: ").append(q).append(" шт\n");

        boolean web = WebServer.isRunning();
        sb.append(web ? "✅" : "❌").append(" <b>Локальный сервер</b>");
        if (web) sb.append(" · порт ").append(WebServer.port());
        sb.append("\n");

        sb.append("\n<i>Если Telegram недоступен — команды идут через релей, "
                + "а действия выполняются и встают в очередь.</i>\n\n");
        sb.append(Sys.footer(c));
        return sb.toString();
    }

    /** Отчёт «что делать, если бот молчит». */
    public static String rescueGuide(Context c) {
        return "🆘 <b>Если бот не отвечает</b>\n\n"
                + "1️⃣ <b>VPN</b> — Telegram в РФ блокирован.\n"
                + "   Включи VPN на телефоне или проверь подписку.\n\n"
                + "2️⃣ <b>Интернет</b> — проверь Wi-Fi/мобильные данные.\n\n"
                + "3️⃣ <b>Релей</b> — даже без Telegram команды дойдут:\n"
                + "   канал <code>" + Relay.channel(c) + "</code>\n\n"
                + "4️⃣ <b>Очередь</b> — сейчас " + queueSize(c) + " невыполненных.\n\n"
                + "5️⃣ <b>Служба доступности</b> — " + (BotService.isServiceOn() ? "включена ✅" : "выключена ❌") + "\n\n"
                + "6️⃣ <b>Автозапуск</b> — Настройки → Приложения → Pulse → Автозапуск ВКЛ\n\n"
                + "7️⃣ <b>Локальная панель</b> — http://127.0.0.1:8765\n"
                + "   работает без интернета вообще\n\n"
                + Sys.footer(c);
    }

    public static boolean isOnline(Context c) {
        try { return Sys.online(c); } catch (Exception e) { return false; }
    }
}
