package com.pulse.control;

import android.app.Notification;
import android.app.NotificationManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Relays phone notifications to Telegram.
 *
 * Anti-spam (fixes VPN "Happ" style services that repost an ongoing notification
 * every couple of minutes):
 *  • dedupe: identical (app|title|text) is forwarded at most once per 15 minutes
 *  • ongoing/status/media/progress notifications only go through once
 *  • rate limit: max 10 messages per minute, then a single summary
 *  • per-message "mute this app" button
 */
public class NotifyHook extends NotificationListenerService {

    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Map<String, Long> SEEN = new HashMap<>();
    private static long windowStart = 0;
    private static int windowCount = 0;

    public static volatile boolean connected = false;

    @Override
    public void onCreate() {
        super.onCreate();
        Act.init(this);
    }

    @Override
    public void onListenerConnected() {
        connected = true;
        LogStore.add("🔔 Доступ к уведомлениям подключён");
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
        LogStore.add("🔔 Доступ к уведомлениям отключён");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (!Config.notifOn(this)) return;
            if (sbn == null || sbn.getNotification() == null) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals(getPackageName())) return;
            if (Config.notifIgnore(this).contains(pkg)) return;

            Notification n = sbn.getNotification();
            Bundle x = n.extras;
            if (x == null) return;

            CharSequence title = x.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = x.getCharSequence(Notification.EXTRA_TEXT);
            if (text == null) text = x.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (title == null && text == null) return;

            String t = title == null ? "" : title.toString().trim();
            String body = text == null ? "" : text.toString().trim();

            // -------- dedupe (15 min) --------
            String key = pkg + "|" + t + "|" + body;
            long now = System.currentTimeMillis();
            Long seenAt;
            synchronized (SEEN) {
                seenAt = SEEN.get(key);
                if (seenAt == null || now - seenAt > 15 * 60 * 1000L) SEEN.put(key, now);
                if (SEEN.size() > 400) SEEN.clear();
            }
            if (seenAt != null && now - seenAt <= 15 * 60 * 1000L) return;

            // -------- structured filtering --------
            boolean important = (n.flags & Notification.FLAG_ONGOING_EVENT) == 0
                    && (n.flags & Notification.FLAG_GROUP_SUMMARY) == 0
                    && n.priority >= Notification.PRIORITY_LOW
                    && !"progress".equals(n.category);
            if ("important".equals(Config.notifMode(this)) && !important) return;

            // -------- rate limit: 10 per minute --------
            synchronized (SEEN) {
                if (now - windowStart > 60_000) { windowStart = now; windowCount = 0; }
                windowCount++;
            }
            if (windowCount > 10) {
                if (windowCount == 11) {
                    Act.sendToAdmin("⏸ <b>Слишком много уведомлений</b> (>10/мин)\n"
                            + "Пересылаю только новые — остальные пропускаю.", null);
                }
                return;
            }

            final String app = Apps.labelOf(this, pkg);
            final String html = "🔔 <b>" + esc(app) + "</b>\n"
                    + (t.isEmpty() ? "" : "<i>" + esc(t) + "</i>\n")
                    + esc(body);

            Config.pushNotifHistory(this, App.timeShort() + " " + app + ": " + t + " — " + body);
            Config.count(this, "na");

            JSONObject kb = TgApi.kb(
                    TgApi.row(
                            TgApi.btn("🚫 Не присылать: " + shortApp(app), "nm:" + pkg),
                            TgApi.btn("🔕 Выкл. все", "m:ntog")
                    )
            );

            POOL.execute(() -> {
                try {
                    long admin = Config.get(this).adminId();
                    if (admin == 0) return;
                    new TgApi(Config.get(this).token).sendMessage(admin, html, kb);
                } catch (Exception ignored) {}
            });
        } catch (Exception e) {
            LogStore.add("🔔 " + e.getMessage());
        }
    }

    private static String shortApp(String s) {
        return s.length() > 14 ? s.substring(0, 13) + "…" : s;
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
