package com.pulse.control;

import android.app.Application;

/** Application entry: one global context for bot/engine helpers. */
public class Core extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Act.init(this);
        LogStore.add("⚡ Pulse Control запущен");
        try { WebServer.start(this); } catch (Exception e) { LogStore.add("🌐 " + e.getMessage()); }
        try { if (Relay.enabled(this)) RelayService.start(this); } catch (Exception ignored) {}
    }
}
