package com.pulse.control;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.telephony.TelephonyManager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** CPU / RAM / network / signal reports. */
public final class Hardware {

    private Hardware() {}

    public static class Mem {
        public long total, avail;
    }

    public static Mem mem() {
        Mem m = new Mem();
        try {
            android.app.ActivityManager am = (android.app.ActivityManager)
                    Act.ctx().getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            m.avail = mi.availMem;
            m.total = mi.totalMem;
        } catch (Exception ignored) {}
        return m;
    }

    public static String memReport(Context c) {
        Mem m = mem();
        return "🧠 <b>Память</b>\n"
                + "Всего: " + Fs.human(m.total) + "\n"
                + "Свободно: " + Fs.human(m.avail) + "\n"
                + "Занято: " + Fs.human(m.total - m.avail);
    }

    public static String cpuReport() {
        StringBuilder sb = new StringBuilder("🖥 <b>Процессор</b>\n");
        try {
            int cores = Runtime.getRuntime().availableProcessors();
            sb.append("Ядер: ").append(cores).append("\n");
            String freq = readFirst("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
            if (freq != null) {
                try { sb.append("Макс. частота: ").append(Long.parseLong(freq.trim()) / 1000000).append(" ГГц\n"); }
                catch (Exception ignored) {}
            }
            String load = readFirst("/proc/loadavg");
            if (load != null) sb.append("Load avg: <code>").append(load.trim()).append("</code>\n");
            sb.append("Модель: ").append(android.os.Build.HARDWARE).append("\n");
        } catch (Exception ignored) {}
        return sb.toString();
    }

    private static String readFirst(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            return r.readLine();
        } catch (Exception e) { return null; }
    }

    public static String netReport(Context c) {
        StringBuilder sb = new StringBuilder("🌐 <b>Сеть</b>\n");
        try {
            sb.append("Интерфейс: ").append(Sys.netName(c)).append("\n");
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                String op = tm.getNetworkOperatorName();
                if (op != null && !op.isEmpty()) sb.append("Оператор: ").append(op).append("\n");
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    try { sb.append("Тип: ").append(tm.getDataNetworkType()).append("\n"); } catch (Exception ignored) {}
                }
            }
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n != null) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null) {
                    int down = caps.getLinkDownstreamBandwidthKbps();
                    sb.append("Канал: ").append(down / 1000).append(" Мбит/с (оценка)\n");
                }
            }
            sb.append("VPN: ").append(vpnOn(c) ? "🟢 да" : "нет").append("\n");
        } catch (Exception ignored) {}
        return sb.toString();
    }

    public static boolean vpnOn(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static String batteryReport(Context c) {
        StringBuilder sb = new StringBuilder("🔋 <b>Батарея</b>\n");
        sb.append("Уровень: <b>").append(Sys.batteryPercent(c)).append("%</b>\n");
        sb.append("Зарядка: ").append(Sys.charging(c) ? "да ⚡" : "нет").append("\n");
        sb.append("Температура: ").append(String.format(Locale.getDefault(), "%.1f", Sys.batteryTemp(c))).append("°C\n");
        try {
            android.content.Intent i = c.registerReceiver(null,
                    new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
                sb.append("Напряжение: ").append(v).append(" мВ\n");
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    /** Very rough speed test: latency + HTTPS download of a 1 MB file. */
    public static String speedTest(Context c) {
        try {
            long t0 = System.currentTimeMillis();
            Http.Resp r = Http.postJson("https://api.telegram.org/bot" + Config.get(c).token + "/getMe",
                    TgApi.obj(), 15000);
            long ping = System.currentTimeMillis() - t0;
            long t1 = System.currentTimeMillis();
            byte[] data = Http.download("https://speed.cloudflare.com/__down?bytes=1000000", 40000);
            long dt = System.currentTimeMillis() - t1;
            double mbps = data == null || dt == 0 ? 0 : (data.length / 1048576.0) / (dt / 1000.0);
            return "🚀 <b>Speedtest</b>\n\n"
                    + "📶 Пинг до Telegram: <b>" + ping + " мс</b>\n"
                    + "⬇️ Скачивание: <b>" + String.format(Locale.getDefault(), "%.1f", mbps) + " Мбит/с</b>\n"
                    + "Размер теста: " + (data == null ? "—" : Fs.human(data.length)) + " за " + dt + " мс";
        } catch (Exception e) {
            return "🚀 Ошибка теста: " + e.getMessage();
        }
    }
}
