package com.pulse.control;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;

/** Calls, SMS, contacts. */
public final class Dial {

    private Dial() {}

    public static boolean call(Context c, String number) {
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number.replaceAll("[^+0-9]", "")));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean dial(Context c, String number) {
        try {
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number.replaceAll("[^+0-9]", "")));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean sms(Context c, String number, String text) {
        try {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number.replaceAll("[^+0-9]", "")));
            i.putExtra("sms_body", text);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean endCall(Context c) {
        try {
            android.telecom.TelecomManager tm = (android.telecom.TelecomManager)
                    c.getSystemService(Context.TELECOM_SERVICE);
            if (tm == null) return false;
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                tm.endCall();
                return true;
            }
            return false;
        } catch (Exception e) { return false; }
    }

    public static java.util.List<String[]> contacts(Context c, String query, int limit) {
        java.util.List<String[]> out = new java.util.ArrayList<>();
        try {
            android.database.Cursor cur = c.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{"%" + (query == null ? "" : query) + "%"},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cur != null) {
                while (cur.moveToNext() && out.size() < limit) {
                    out.add(new String[]{cur.getString(0), cur.getString(1)});
                }
                cur.close();
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static boolean alarm(Context c, int hour, int minute, String label) {
        try {
            Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM);
            i.putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute);
            i.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label);
            i.putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static boolean timer(Context c, int seconds) {
        try {
            Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_TIMER);
            i.putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }
}
