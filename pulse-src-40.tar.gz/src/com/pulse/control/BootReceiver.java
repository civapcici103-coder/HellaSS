package com.pulse.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restarts the status card after reboot (when autostart is enabled). */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent == null ? "" : intent.getAction();
        if (a == null) return;
        if (!a.equals(Intent.ACTION_BOOT_COMPLETED) && !a.equals(Intent.ACTION_LOCKED_BOOT_COMPLETED)) return;

        Config cfg = Config.get(context);
        if (!cfg.autostart) return;

        LogStore.add("🔁 Автозапуск после перезагрузки");
        try { StatusService.start(context); } catch (Exception ignored) {}
        // Релей — самое важное после ребута: телефон может быть дома без тебя
        try {
            if (Relay.enabled(context) && !Eco.on(context)) RelayService.start(context);
        } catch (Exception ignored) {}
        try {
            if (!Eco.on(context)) WebServer.start(context);
        } catch (Exception ignored) {}
        // The accessibility service (and with it the bot) comes back automatically
        // once the system re-enables it; nothing else to do here.
    }
}
