package com.pulse.control;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

/**
 * Translucent one-tap consent screen for screen capturing.
 * Android 14+ requires fresh consent for every projection session, so this
 * activity pops up, asks "Start recording?" and immediately continues.
 */
public class ScreenCapActivity extends Activity {

    public static final String EXTRA_MODE = "mode";       // record | live
    public static final String EXTRA_SECONDS = "secs";
    private static final int REQ = 4242;

    public static void request(Context c, String mode, int seconds) {
        Intent i = new Intent(c, ScreenCapActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra(EXTRA_MODE, mode);
        i.putExtra(EXTRA_SECONDS, seconds);
        try { c.startActivity(i); } catch (Exception ignored) {}
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        try {
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ);
        } catch (Exception e) {
            LogStore.add("🎥 Не удалось открыть окно разрешения экрана");
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ) {
            if (res == RESULT_OK && data != null) {
                Config.saveProjection(this, res, data.toUri(Intent.URI_INTENT_SCHEME));
                String mode = getIntent().getStringExtra(EXTRA_MODE);
                int secs = getIntent().getIntExtra(EXTRA_SECONDS, 15);
                LogStore.add("🎥 Разрешение на экран получено");
                ScreenCapService.start(this, mode, secs);
            } else {
                LogStore.add("🎥 Пользователь отклонил захват экрана");
            }
        }
        finish();
    }
}
