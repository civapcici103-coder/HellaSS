package com.pulse.control;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.view.KeyEvent;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Набор надёжных функций, доступных обычному (не-root) APK.
 * Каждый метод рассчитан на работу на HyperOS/MIUI без ADB.
 */
public final class Extras {

    private Extras() {}

    /** Результат операции: null = успех, иначе текст ошибки. */
    public interface Res { void done(String err); }

    // ================================================================ ЭКРАН

    /** Поворот экрана через системные настройки (работает на большинстве прошивок). */
    public static String rotate(Context c, int degrees) {
        try {
            if (degrees == 0) {
                android.provider.Settings.System.putInt(c.getContentResolver(),
                        android.provider.Settings.System.ACCELEROMETER_ROTATION, 1);
                return null;
            }
            int rot = degrees == 90 ? 1 : degrees == 180 ? 2 : degrees == 270 ? 3 : 0;
            android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.USER_ROTATION, rot);
            android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.ACCELEROMETER_ROTATION, 0);
            return null;
        } catch (Exception e) {
            return "нет доступа (нужно разрешение WRITE_SETTINGS): " + e.getMessage();
        }
    }

    /** Точная установка яркости 0..100. */
    public static String brightnessPct(Context c, int pct) {
        try {
            pct = Math.max(1, Math.min(100, pct));
            int raw = pct * 255 / 100;
            boolean ok = android.provider.Settings.System.putInt(c.getContentResolver(),
                    android.provider.Settings.System.SCREEN_BRIGHTNESS, raw);
            Sys.setBrightness(c, pct);
            return ok ? null : "нет WRITE_SETTINGS";
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }

    /** Время до отключения экрана меняем через экран настроек (без root нельзя напрямую). */
    public static String openScreenTimeout(Context c) {
        return openSettings(c, android.provider.Settings.ACTION_DISPLAY_SETTINGS);
    }

    public static String openSettings(Context c, String action) {
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return null;
        } catch (Exception e) {
            return "не удалось открыть настройки";
        }
    }

    /** Выключить экран (через службу доступа GLOBAL_ACTION_LOCK_SCREEN). */
    public static String screenOff(Context c) {
        try {
            BotService bs = BotService.inst();
            if (bs == null) return "служба доступа выключена";
            bs.doGlobal(8);
            return null;
        } catch (Exception e) {
            return String.valueOf(e.getMessage());
        }
    }

    /** Инверсия цветов. */
    public static String invertColors(Context c) {
        try {
            int cur = android.provider.Settings.Secure.getInt(c.getContentResolver(),
                    android.provider.Settings.Secure.ACCESSIBILITY_DISPLAY_INVERSION_ENABLED, 0);
            return toggleSecure(c, android.provider.Settings.Secure.ACCESSIBILITY_DISPLAY_INVERSION_ENABLED, cur);
        } catch (Exception e) {
            return "нет доступа: " + e.getMessage();
        }
    }

    /** Крупный шрифт (масштаб 1.3). */
    public static String largeFont(Context c) {
        try {
            android.provider.Settings.System.putFloat(c.getContentResolver(),
                    android.provider.Settings.System.FONT_SCALE, 1.3f);
            return null;
        } catch (Exception e) {
            return "нет WRITE_SETTINGS";
        }
    }

    /** Обычный шрифт. */
    public static String normalFont(Context c) {
        try {
            android.provider.Settings.System.putFloat(c.getContentResolver(),
                    android.provider.Settings.System.FONT_SCALE, 1.0f);
            return null;
        } catch (Exception e) {
            return "нет WRITE_SETTINGS";
        }
    }

    private static String toggleSecure(Context c, String key, int cur) {
        boolean ok = android.provider.Settings.Secure.putInt(c.getContentResolver(), key, cur == 1 ? 0 : 1);
        return ok ? null : "нет WRITE_SECURE_SETTINGS";
    }

    /** Ночной режим — системная настройка «Защита зрения» (MIUI) / Night Light. */
    public static String dimScreen(Context c, boolean on) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                int cur = android.provider.Settings.Secure.getInt(c.getContentResolver(),
                        "night_display_activated", 0);
                android.provider.Settings.Secure.putInt(c.getContentResolver(),
                        "night_display_activated", on ? 1 : (cur == 1 ? 0 : 1));
                return null;
            }
            return openSettings(c, "android.settings.NIGHT_DISPLAY_SETTINGS");
        } catch (Exception e) {
            return "нет WRITE_SECURE_SETTINGS — откройте через настройки";
        }
    }

    // ================================================================ ЖЕСТЫ

    /** Мультитап по центру. */
    public static String multiTap(Context c, int times) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        int[] sz = Gestures.screenSize(c);
        Gestures.multiTap(bs, sz[0] / 2f, sz[1] / 2f, times, null);
        return null;
    }

    public static String longPress(Context c) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        int[] sz = Gestures.screenSize(c);
        Gestures.longPress(bs, sz[0] / 2f, sz[1] / 2f, 800, null);
        return null;
    }

    public static String doubleTap(Context c) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        int[] sz = Gestures.screenSize(c);
        Gestures.multiTap(bs, sz[0] / 2f, sz[1] / 2f, 2, null);
        return null;
    }

    /** Пинч (зум) — двумя пальцами. */
    public static String pinch(Context c, boolean zoomIn) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        int[] sz = Gestures.screenSize(c);
        Gestures.pinch(bs, sz[0] / 2f, sz[1] / 2f, zoomIn, null);
        return null;
    }

    /** Тап по сетке 5×5. */
    public static String grid25(Context c, String cell) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        return Gestures.tapCellN(bs, cell, 5, null) ? null : "ячейка вне сетки";
    }

    /** Тап по элементу с определённым view-id. */
    public static String tapById(Context c, String viewId) {
        BotService bs = BotService.inst();
        if (bs == null) return "служба доступа выключена";
        return Gestures.tapById(bs, viewId, null) ? null : "элемент не найден";
    }

    // ================================================================ СИСТЕМА

    public static String powerSave(Context c) {
        return openSettings(c, "android.settings.BATTERY_SAVER_SETTINGS");
    }

    public static String darkTheme(Context c) {
        try {
            int cur = android.provider.Settings.Secure.getInt(c.getContentResolver(),
                    "ui_night_mode", 0);
            android.provider.Settings.Secure.putInt(c.getContentResolver(),
                    "ui_night_mode", cur == 2 ? 1 : 2);
            return null;
        } catch (Exception e) {
            return "нет WRITE_SECURE_SETTINGS — откройте через настройки";
        }
    }

    /** Список энергоёмких приложений (приблизительно, по числу wake-локов недоступно — показываем топ по расходу). */
    public static String batteryUsers(Context c) {
        try {
            StringBuilder sb = new StringBuilder("🔋 <b>Расход батареи</b>\n\n");
            android.os.BatteryManager bm = (android.os.BatteryManager)
                    c.getSystemService(Context.BATTERY_SERVICE);
            sb.append("Уровень: ").append(Sys.batteryPercent(c)).append("%\n");
            sb.append("Температура: ").append(Sys.batteryTemp(c)).append("°C\n");
            sb.append("Зарядка: ").append(Sys.charging(c) ? "да" : "нет").append("\n");
            if (bm != null) {
                sb.append("Напряжение: ").append(bm.getIntProperty(
                        4)).append(" мВ\n");
                sb.append("Ток: ").append(bm.getIntProperty(
                        2) / 1000).append(" мА\n");
                sb.append("Ёмкость: ").append(bm.getIntProperty(
                        1) / 1000).append(" мА·ч\n");
            } else {
                sb.append("Данные батареи недоступны\n");
            }
            sb.append("\n").append(Sys.footer(c));
            return sb.toString();
        } catch (Exception e) {
            return "🔋 Ошибка: " + e.getMessage();
        }
    }

    // ================================================================ СЕТЬ (безопасно)

    /** Список сохранённых Wi-Fi (через экран настроек — без root недоступен прямой скан). */
    public static String openWifi(Context c) { return openSettings(c, android.provider.Settings.ACTION_WIFI_SETTINGS); }
    public static String openBluetooth(Context c) { return openSettings(c, android.provider.Settings.ACTION_BLUETOOTH_SETTINGS); }
    public static String openData(Context c) { return openSettings(c, android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS); }
    public static String openAirplane(Context c) { return openSettings(c, android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS); }
    public static String openHotspot(Context c) { return openSettings(c, "android.settings.TETHER_SETTINGS"); }
    public static String openNfc(Context c) { return openSettings(c, "android.settings.NFC_SETTINGS"); }

    /** Режим полёта попыткой быстрой настройки (на части прошивок работает). */
    public static String airplane(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 17) {
                boolean cur = android.provider.Settings.Global.getInt(c.getContentResolver(),
                        android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
                android.provider.Settings.Global.putInt(c.getContentResolver(),
                        android.provider.Settings.Global.AIRPLANE_MODE_ON, cur ? 0 : 1);
                return null;
            }
        } catch (Exception ignored) {}
        return openSettings(c, android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS);
    }

    // ================================================================ ПРИЛОЖЕНИЯ

    public static String appInfo(Context c, String pkg) {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return null;
        } catch (Exception e) { return "не удалось открыть"; }
    }

    /** Размер приложения и дата установки. */
    public static String appSize(Context c, String pkg) {
        try {
            android.content.pm.PackageManager pm = c.getPackageManager();
            android.content.pm.ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            long apk = new File(ai.sourceDir).length();
            long data = dirSize(new File(ai.dataDir));
            android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, 0);
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", new java.util.Locale("ru"));
            return "📦 <b>" + Tools.e(pm.getApplicationLabel(ai).toString()) + "</b>\n"
                    + "APK: " + Fs.human(apk) + "\nДанные: " + Fs.human(data) + "\n"
                    + "Версия: " + pi.versionName + "\nУстановлено: " + f.format(new java.util.Date(pi.firstInstallTime))
                    + "\n\n" + Sys.footer(c);
        } catch (Exception e) { return "нет данных о приложении"; }
    }

    private static long dirSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long s = 0;
        File[] list = f.listFiles();
        if (list == null) return 0;
        for (File x : list) s += dirSize(x);
        return s;
    }

    public static String uninstall(Context c, String pkg) {
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return null;
        } catch (Exception e) { return "не удалось"; }
    }

    public static String appPerms(Context c, String pkg) {
        try {
            android.content.pm.PackageInfo pi = c.getPackageManager()
                    .getPackageInfo(pkg, android.content.pm.PackageManager.GET_PERMISSIONS);
            StringBuilder sb = new StringBuilder("🔐 <b>Разрешения</b>\n");
            if (pi.requestedPermissions != null)
                for (String p : pi.requestedPermissions)
                    sb.append("• ").append(p.replace("android.permission.", "")).append("\n");
            return sb.toString();
        } catch (Exception e) { return "нет данных"; }
    }

    // ================================================================ МЕДИА

    /** Управление громкостью отдельного потока. */
    public static String setStream(Context c, int stream, int pct) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(stream);
            am.setStreamVolume(stream, Math.max(0, Math.min(max, pct * max / 100)), 0);
            return null;
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    public static String streamsReport(Context c) {
        try {
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            String[] names = {"Звонок", "Система", "Музыка", "Будильник", "Уведомления", "Входящий звонок"};
            int[] streams = {AudioManager.STREAM_RING, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_MUSIC,
                    AudioManager.STREAM_ALARM, AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL};
            StringBuilder sb = new StringBuilder("🔊 <b>Громкости</b>\n\n");
            for (int i = 0; i < streams.length; i++) {
                int cur = am.getStreamVolume(streams[i]), max = am.getStreamMaxVolume(streams[i]);
                sb.append(names[i]).append(": <b>").append(cur * 100 / Math.max(1, max)).append("%</b>\n");
            }
            return sb.toString();
        } catch (Exception e) { return "🔊 Ошибка"; }
    }

    // ================================================================ ЗДОРОВЬЕ

    public static String cpuHealth() {
        try {
            StringBuilder sb = new StringBuilder("🧠 <b>Процессор</b>\n\n");
            sb.append("Ядер: ").append(Runtime.getRuntime().availableProcessors()).append("\n");
            sb.append("Архитектура: ").append(System.getProperty("os.arch")).append("\n");
            for (int i = 0; i < Runtime.getRuntime().availableProcessors(); i++) {
                try {
                    java.io.BufferedReader r = new java.io.BufferedReader(
                            new java.io.FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"));
                    String line = r.readLine();
                    r.close();
                    if (line != null)
                        sb.append("CPU").append(i).append(": ").append(Long.parseLong(line.trim()) / 1000).append(" МГц\n");
                } catch (Exception ignored) {}
            }
            return sb.toString();
        } catch (Exception e) { return "🧠 Ошибка"; }
    }

    public static String diskHealth() {
        try {
            StringBuilder sb = new StringBuilder("💾 <b>Хранилище</b>\n\n");
            StatFs d = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long free = d.getAvailableBytes(), total = d.getTotalBytes();
            sb.append("Внутреннее: ").append(Fs.human(free)).append(" из ").append(Fs.human(total)).append("\n");
            sb.append("Заполнено: ").append((total - free) * 100 / Math.max(1, total)).append("%\n");
            try {
                StatFs e = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
                sb.append("SD/внешнее: ").append(Fs.human(e.getAvailableBytes())).append(" свободно\n");
            } catch (Exception ignored) {}
            sb.append("\n").append(Sys.footer(null));
            return sb.toString();
        } catch (Exception e) { return "💾 Ошибка"; }
    }

    public static String sensors(Context c) {
        try {
            android.hardware.SensorManager sm = (android.hardware.SensorManager)
                    c.getSystemService(Context.SENSOR_SERVICE);
            List<android.hardware.Sensor> all = sm.getSensorList(android.hardware.Sensor.TYPE_ALL);
            StringBuilder sb = new StringBuilder("📡 <b>Сенсоры</b> (" + all.size() + ")\n\n");
            for (int i = 0; i < Math.min(all.size(), 20); i++)
                sb.append("• ").append(Tools.e(all.get(i).getName())).append("\n");
            return sb.toString();
        } catch (Exception e) { return "📡 Ошибка"; }
    }

    public static String uptime() {
        long ms = android.os.SystemClock.elapsedRealtime();
        long d = ms / 86400000, h = (ms % 86400000) / 3600000, m = (ms % 3600000) / 60000;
        return "⏱ <b>Аптайм</b>\n\n" + d + " д " + h + " ч " + m + " мин\n\n🕐 " + Sys.time();
    }

    public static String rootCheck() {
        String[] paths = {"/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su",
                "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/data/local/su", "/su/bin/su"};
        StringBuilder sb = new StringBuilder("🔍 <b>Проверка root</b>\n\n");
        boolean found = false;
        for (String p : paths) if (new File(p).exists()) { sb.append("⚠️ ").append(p).append("\n"); found = true; }
        sb.append(found ? "\n<b>Устройство с root</b>" : "\n✅ Root не обнаружен");
        return sb.toString();
    }

    // ================================================================ ФАЙЛЫ

    public static String mkdir(Context c, String path) {
        File f = Fs.resolve(path);
        return f != null && f.mkdirs() ? null : "не удалось создать";
    }

    public static String delete(Context c, String path) {
        File f = Fs.resolve(path);
        if (f == null || f.equals(Fs.ROOT)) return "неверный путь";
        return deleteRec(f) ? null : "не удалось удалить";
    }

    private static boolean deleteRec(File f) {
        if (f.isDirectory()) {
            File[] list = f.listFiles();
            if (list != null) for (File x : list) deleteRec(x);
        }
        return f.delete();
    }

    public static String rename(Context c, String from, String to) {
        File a = Fs.resolve(from), b = Fs.resolve(to);
        return a != null && b != null && a.renameTo(b) ? null : "не удалось переименовать";
    }

    public static String copy(Context c, String from, String to) {
        try {
            File a = Fs.resolve(from), b = Fs.resolve(to);
            if (a == null || b == null || !a.isFile()) return "нет файла";
            byte[] data = Fs.read(from, 100 * 1024 * 1024);
            return data != null && Fs.write(to, data) ? null : "не удалось";
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    public static String search(Context c, String query) {
        try {
            List<File> out = new ArrayList<>();
            searchRec(Environment.getExternalStorageDirectory(), query.toLowerCase(), out, 0);
            StringBuilder sb = new StringBuilder("🔎 <b>Найдено</b>: " + out.size() + "\n\n");
            for (int i = 0; i < Math.min(out.size(), 25); i++)
                sb.append("• ").append(Tools.e(Fs.rel(out.get(i)))).append("\n");
            return out.isEmpty() ? "🔎 Ничего не найдено" : sb.toString();
        } catch (Exception e) { return "🔎 Ошибка"; }
    }

    private static void searchRec(File dir, String q, List<File> out, int depth) {
        if (depth > 5 || out.size() > 80 || dir == null) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        for (File f : list) {
            if (f.getName().toLowerCase().contains(q)) out.add(f);
            if (f.isDirectory() && !f.getName().startsWith(".")) searchRec(f, q, out, depth + 1);
        }
    }

    // ================================================================ УВЕДОМЛЕНИЯ

    public static String activeNotifs(Context c) {
        try {
            android.app.NotificationManager nm = c.getSystemService(android.app.NotificationManager.class);
            android.service.notification.StatusBarNotification[] arr = nm.getActiveNotifications();
            if (arr == null || arr.length == 0) return "🔔 Активных уведомлений нет";
            StringBuilder sb = new StringBuilder("🔔 <b>Активных: " + arr.length + "</b>\n\n");
            for (int i = 0; i < Math.min(arr.length, 20); i++) {
                android.os.Bundle ex = arr[i].getNotification().extras;
                String title = ex.getCharSequence("android.title") == null ? "" : ex.getCharSequence("android.title").toString();
                String text = ex.getCharSequence("android.text") == null ? "" : ex.getCharSequence("android.text").toString();
                sb.append("• <b>").append(Tools.e(title)).append("</b>\n  ").append(Tools.e(text)).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "🔔 Нет доступа к уведомлениям (включите службу)";
        }
    }

    public static String clearAllNotifs(Context c) {
        try {
            if (BotService.inst() != null) { BotService.inst().cancelAllNotifs(); return null; }
            return "служба доступа выключена";
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    // ================================================================ ТЕЛЕФОНИЯ

    public static String callLog(Context c) {
        try {
            StringBuilder sb = new StringBuilder("📞 <b>Журнал вызовов</b>\n\n");
            android.database.Cursor cur = c.getContentResolver().query(
                    android.provider.CallLog.Calls.CONTENT_URI,
                    new String[]{android.provider.CallLog.Calls.NUMBER,
                            android.provider.CallLog.Calls.TYPE,
                            android.provider.CallLog.Calls.DATE,
                            android.provider.CallLog.Calls.DURATION},
                    null, null, android.provider.CallLog.Calls.DATE + " DESC");
            int n = 0;
            if (cur != null) {
                while (cur.moveToNext() && n < 20) {
                    String num = cur.getString(0);
                    int type = cur.getInt(1);
                    long dur = cur.getLong(3);
                    String icon = type == android.provider.CallLog.Calls.INCOMING_TYPE ? "📥"
                            : type == android.provider.CallLog.Calls.OUTGOING_TYPE ? "📤" : "❌";
                    sb.append(icon).append(" ").append(Tools.e(num))
                            .append(" · ").append(dur).append("с\n");
                    n++;
                }
                cur.close();
            }
            return n == 0 ? "📞 Журнал пуст" : sb.toString();
        } catch (Exception e) {
            return "📞 Нет разрешения READ_CALL_LOG";
        }
    }

    public static String missedCalls(Context c) {
        try {
            android.database.Cursor cur = c.getContentResolver().query(
                    android.provider.CallLog.Calls.CONTENT_URI,
                    new String[]{android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.DATE},
                    android.provider.CallLog.Calls.TYPE + "=?",
                    new String[]{String.valueOf(android.provider.CallLog.Calls.MISSED_TYPE)},
                    android.provider.CallLog.Calls.DATE + " DESC");
            StringBuilder sb = new StringBuilder("📵 <b>Пропущенные</b>\n\n");
            int n = 0;
            if (cur != null) {
                while (cur.moveToNext() && n < 15) {
                    sb.append("• ").append(Tools.e(cur.getString(0))).append("\n");
                    n++;
                }
                cur.close();
            }
            return n == 0 ? "📵 Пропущенных нет" : sb.toString();
        } catch (Exception e) {
            return "📵 Нет разрешения READ_CALL_LOG";
        }
    }

    public static String answerCall(Context c) {
        try {
            android.telecom.TelecomManager tm = (android.telecom.TelecomManager)
                    c.getSystemService(Context.TELECOM_SERVICE);
            if (tm == null) return "нет доступа к звонкам";
            if (Build.VERSION.SDK_INT >= 26) {
                tm.acceptRingingCall();
                return null;
            }
            return "требуется Android 8+";
        } catch (Exception e) { return "нет разрешения ANSWER_PHONE_CALLS"; }
    }

    public static String rejectCall(Context c) {
        try {
            android.telecom.TelecomManager tm = (android.telecom.TelecomManager)
                    c.getSystemService(Context.TELECOM_SERVICE);
            if (tm == null) return "нет доступа";
            if (Build.VERSION.SDK_INT >= 28) {
                tm.endCall();
                return null;
            }
            return "требуется Android 9+";
        } catch (Exception e) { return "нет разрешения ANSWER_PHONE_CALLS"; }
    }

    // ================================================================ ЗАМЕТКИ / TTS

    public static String ttsStop() {
        try { Tools.ttsStop(); return null; } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    public static String speakFile(Context c, String path) {
        try {
            byte[] data = Fs.read(path, 200 * 1024);
            if (data == null) return "файл не найден";
            String text = new String(data, "UTF-8");
            Tools.say(c, text.length() > 3000 ? text.substring(0, 3000) : text, "ru");
            return null;
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    // ================================================================ СИСТЕМНЫЕ ЭКРАНЫ

    public static String openDevOptions(Context c) { return openSettings(c, android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS); }
    public static String openBatterySettings(Context c) { return openSettings(c, Intent.ACTION_POWER_USAGE_SUMMARY); }
    public static String openStorageSettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS); }
    public static String openAccessibility(Context c) { return openSettings(c, android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS); }
    public static String openLocationSettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS); }
    public static String openAppSettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_APPLICATION_SETTINGS); }
    public static String openSoundSettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_SOUND_SETTINGS); }
    public static String openDisplaySettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_DISPLAY_SETTINGS); }
    public static String openDateTime(Context c) { return openSettings(c, android.provider.Settings.ACTION_DATE_SETTINGS); }
    public static String openWriteSettings(Context c) { return openSettings(c, android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS); }

    // ================================================================ СКРИНШОТ-СЕРВИС

    public static String stopRecording(Context c) {
        try {
            c.stopService(new Intent(c, ScreenCapService.class));
            return null;
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }

    // ================================================================ ЭКСПОРТ НАСТРОЕК

    public static String exportConfig(Context c) {
        try {
            Config cfg = Config.get(c);
            org.json.JSONObject j = new org.json.JSONObject();
            j.put("token", cfg.token);
            j.put("admin", cfg.adminId());
            j.put("macros", Config.macros(c));
            j.put("schedule", Config.schedule(c));
            j.put("triggers", Config.triggers(c));
            byte[] data = j.toString(2).getBytes("UTF-8");
            Act.sendDoc(data, "pulse-config.json", "📤 <b>Настройки Pulse</b>");
            return null;
        } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
}
